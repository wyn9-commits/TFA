# Security Control Mapping — Enterprise Governance Review

Maps each requirement from the POC security review (RITM0607876) and the
Restricted data classification to its implementation in this codebase and
infrastructure. Intended as the primary technical evidence pack for the
**separate enterprise governance review** (the POC approval was explicitly
scoped and time-bound and does not carry over).

## Where the evidence lives

Evidence is split across two places, and the review needs both:

- **Code controls** — in this repository. The `Where` column gives the file.
- **Infrastructure controls** — in the organisation's Terraform, which
  provisions the resources and is **not in this repository**. For those
  rows the `Where` column names the Terraform property that must hold the
  stated value. `infra/README.md` §5 lists them in one place.

This repository cannot attest to an infrastructure control. Before the
review, someone with read access to the Terraform (or to the resources
themselves) must confirm each infrastructure row below. `scripts/preflight.py`
verifies a subset from the outside — that the data plane rejects the public
network, that SQL accepts token auth — but a passing preflight is not a
substitute for reading the Terraform.

| # | Requirement (from POC review / Restricted controls) | Enterprise implementation | Where |
|---|---|---|---|
| 1 | POC was internet-facing via DMZ; enterprise must not be | **No public data plane.** Every PaaS service is reachable only through private endpoints in the platform VNet; the Function App is VNet-integrated. The Power Apps UI reaches data via Dataverse/connector paths, not a public web app. | **Terraform:** `public_network_access_enabled = false` and a private endpoint on every resource; `network_rules { default_action = "Deny" }` on Storage; VNet integration on the Function App |
| 2 | Users authenticated via Azure AD | **People:** App Service Authentication (Entra ID, configured in the infra tfvars `auth_settings`) signs every user in before a request reaches the app; the app then enforces the `ALLOWED_EMAILS` / group allow-list on **every** route (403 otherwise) and trusts the identity headers only when App Service reports auth is on. **Workload:** one UAMI with data-plane roles for Blob (shared keys off) and, by default, Azure OpenAI. **Exceptions, stated plainly:** the infra provisions SQL with a `SQLAdmin` login whose credentials sit in Key Vault (`mssql_server_username` / `mssql_server_password`) and reach the app as Key Vault references — never in code or the repo; an Azure OpenAI key is supported only if one is issued. Both fall back to Entra tokens when unset. | **Code:** `tfa_web/auth.py`, `storage/repositories.py (sql_connector)`, `llm/provider.py`, `config.get_credential`. **Terraform (infra repo):** App Service `auth_settings`; Storage `shared_access_key_enabled = false`; Key Vault secrets. **Tests:** `tests/test_infra_fit.py` (allow-list, header trust, refuse-to-start) |
| 3 | Data encrypted at rest and in transit | TLS 1.2 minimum on every service; platform-managed encryption at rest by default; customer-managed keys for prod per Restricted controls. | **Terraform:** `min_tls_version = "TLS1_2"` / `https_traffic_only_enabled = true` on Storage, `minimum_tls_version = "1.2"` on the Function App; `customer_managed_key` on Storage and SQL TDE for prod |
| 4 | Data classification: Restricted — all applicable controls | Immutable raw container (SharePoint deletions are flagged, never propagated), audit logging on SQL, diagnostic settings to Log Analytics, redaction-by-default tracing, review-gated persistence of uncertain extractions. | **Code:** `observability/tracing.py` (redaction), `extraction/validators.py` (review gate), `ingestion/sharepoint.py` (deletions flagged). **Terraform:** blob versioning + 30-day delete and container-delete retention; `azurerm_mssql_server_extended_auditing_policy`; diagnostic settings on every resource |
| 5 | Third party involved; SOC 2 Type II must be collected | Third parties in the enterprise design: LangSmith (only if used; self-hosted-in-VNet is the default recommendation, which removes the data flow entirely) and the model providers via Microsoft Foundry (covered by Microsoft's compliance inheritance; for Claude, use the **Azure-hosted** deployments so data stays on Azure end-to-end). Collect: Anthropic SOC 2 Type II if Anthropic-hosted Claude is ever enabled; LangChain Inc. SOC 2 Type II if LangSmith Cloud is ever enabled. | `docs/DEPLOYMENT.md`, `observability/tracing.py` |
| 6 | Application uses API calls to fetch required data | Microsoft Graph (`Sites.Selected`, single-site grant), Azure OpenAI, SQL and Storage, all over the infra's private networking. Secrets, where the infra uses them (SQL login), come from Key Vault references; none are in code, the image or the repo. | `ingestion/sharepoint.py`, `llm/provider.py`, `storage/repositories.py` |
| 7 | Solution involves changes/developments in SAP | Isolated behind the `RateContext` seam: the SAP negotiated-rate feed replaces the JSON seed without touching extraction code. SAP integration itself ships as its own reviewed change. | `extraction/pipeline.py` (`RateContext`) |
| 8 | Data types: Excel, PDF, PNG, JPEG | All four routed: PDF through its text layer + page images to the vision model, PNG/JPEG as images (no Document Intelligence in the infra; used automatically if an endpoint is configured); Excel through the workbook reader. Unsupported types fail closed with a status record. | `extraction/pipeline.py (type dispatch), extraction/pdf_layout.py, extraction/excel_reader.py`, `domain/errors.py` |
| 9 | Data storage: folio fields (hotel, dates, guest, charges…) | Single-registry schema (`SQL_COLUMNS`) generates the SQL DDL, so the stored fields are exactly the reviewed fields; guest names are the only personal data stored, minimised to what reconciliation requires. | `schemas.py`, `scripts/generate_sql_ddl.py` |
| 10 | SIEM: Splunk | All resources emit diagnostic settings to Log Analytics; ingestion to Splunk uses the organisation's existing LAW → Event Hub → Splunk add-on path (no new pattern introduced). | **Terraform:** `azurerm_monitor_diagnostic_setting` on every resource to the shared workspace. `docs/DEPLOYMENT.md` for the Splunk path |
| 11 | AI/prompt governance (new for enterprise) | Prompts are version-controlled code; extraction is schema-constrained (no free-form generation); model output never does arithmetic; uncertain output is human-review-gated; **cross-model verification** (`extraction/verify.py`) has a second model from a different family re-read uncertain documents and routes disagreement to review; eval harness (`evals/local_eval.py`) gates every build on `money_exact` and scores real goldens against the model on demand; model swaps are config-only and auditable. | `extraction/llm_extractor.py`, `extraction/validators.py`, `evals/` |

All code paths are relative to `src/tfa_core/`.

## Residual items for the review to decide
1. **CMK scope** — a decision on key-rotation ownership is needed before CMK
   is a property of the Storage account and SQL database in the infra Terraform (TDE on SQL); confirm the key type there.
2. **LangSmith hosting** — self-hosted in VNet (recommended) vs. cloud with
   SOC 2 evidence + DPA.
3. **Serrala/FS² AP documents** — process, skip, or use as cross-check
   against SAP-posted amounts (they are classified before extraction, so any
   of the three is a config choice).
4. **Retention** — raw-container retention for Restricted data beyond the
   30-day soft-delete window.
5. **Terraform attestation** — who signs off that the infrastructure rows
   above hold in each environment, and how that is re-checked after a
   Terraform change. This repository can only state the requirement.
