# Mapping the Terraform resources to this app, from Azure DevOps only

For when you cannot open the Azure portal, cannot run `az` against the
subscription, and your only view of the infrastructure is the Terraform
pipeline in Azure DevOps. That is enough. Everything the application needs is
a resource *name*, and Terraform prints every name it manages.

Nothing in this guide creates a resource. If something turns out to be
missing, the fix is a change in the Terraform repo by whoever owns it, with
`infra/README.md` as the request.

## 1. Get the text out of ADO

Three places, in order of how much they tell you. You need the first; the
others fill gaps.

**a. The apply log — the one that matters.**
Pipelines → the infra pipeline → the most recent run that reached *apply*
for your environment → open the job → the step that runs `terraform apply`
(or `terraform plan` on an existing state — both work, because every managed
resource is listed with its id either way). Use the **View raw log** button
(top right of the log pane) rather than the formatted view, and save the
whole thing as `apply.log`. Resource ids are not secrets; if the step output
contains a masked `***`, that is ADO redacting a sensitive output, and you do
not need it.

**b. Terraform outputs, if the pipeline has a step for them.**
Same run, a step named something like *terraform output*. Copy its text as
`outputs.txt`, or if the step publishes an artifact, download the JSON.

**c. The Terraform source, from Repos.**
Repos → the infra repository → the environment's folder. The files that
matter are the ones defining `azurerm_storage_account`, `azurerm_mssql_*`,
`azurerm_cosmosdb_*`, `azurerm_cognitive_*`, `azurerm_function_app_*`,
`azurerm_role_assignment`, `azurerm_cosmosdb_sql_role_assignment`,
`azurerm_eventgrid_*` and `azurerm_private_endpoint`. You need these only to
answer the questions the script cannot answer from names alone (see §3).

## 2. Run the mapper

```bash
python scripts/map_terraform.py apply.log            # report only
python scripts/map_terraform.py apply.log outputs.txt --write   # also write .env
```

It prints every resource it recognised, a checklist against the contract in
`infra/README.md`, a proposed `.env`, the Function App name to put in
`azure-pipelines.yml`, and the identity name to pass to
`scripts/generate_sql_ddl.py`.

Read the checklist before the `.env`. A `✗` means that resource did not
appear in the text at all. A `?` means the script saw something it cannot
judge from a name — a role assignment it cannot tie to the group, an endpoint
host it had to guess — and tells you what to confirm.

## 3. What the script cannot know from names, and where to look

| Question | Where in the Terraform source |
|---|---|
| Is the OpenAI endpoint `<name>.openai.azure.com` or `<name>.cognitiveservices.azure.com`? | `azurerm_cognitive_account` for Foundry: `kind` and `custom_subdomain_name`. Kind `OpenAI` → `.openai.azure.com`; kind `AIServices` → usually `.cognitiveservices.azure.com`. Preflight tries the one in `.env` and tells you if it is wrong |
| Does the Entra group have roles, or only the UAMI? | `azurerm_role_assignment` blocks: look at `principal_id`. If every one points at the identity's `principal_id` and none at a group object id, people cannot run locally until that changes |
| Is the Cosmos role a real data-plane role? | It must be `azurerm_cosmosdb_sql_role_assignment` with role definition id ending `...0002`. An `azurerm_role_assignment` on the Cosmos account is an ARM role and does nothing for the app |
| Does the Event Grid subscription exist and point at the right thing? | `azurerm_eventgrid_system_topic_event_subscription` (or `azurerm_eventgrid_event_subscription`): `included_event_types` must contain `Microsoft.Storage.BlobCreated`, `subject_filter.subject_begins_with` must be `/blobServices/default/containers/travel-folios/`, and the destination must be the `enqueue_folio` function |
| Are the app settings on the Function App? | `azurerm_function_app_flex_consumption` (or `azurerm_linux_function_app`): the `app_settings` map. Compare its keys to `infra/README.md` §3. The deployment name there must match `TFA_LLM_DEPLOYMENT` in the mapper's output |
| Is public access really off? | `public_network_access_enabled = false` on each resource; if it is absent, the provider default is `true` |

## 4. Then

```bash
# on the VPN
az login
python scripts/preflight.py
```

Preflight is the only verification available to you, since you cannot look
at the resources directly. It reaches each one as you and classifies every
failure; `RUN.md` Part 7 explains the classes.

## 5. Deploying

You have no rights to publish to the Function App yourself, so the
application pipeline is the deployment path:

1. Set `appServiceName` in `azure-pipelines.yml` to the name the
   mapper printed.
2. Confirm the `azureServiceConnection` parameter names a service connection
   you are allowed to use. If not, the ADO project administrator grants
   *User* on that connection to your account or group.
3. Create the pipeline in ADO from that YAML, and create the ADO environment
   `tfa-dev` (or whichever `environment` parameter you use) with its approval.
4. Run it. Tests → package → deploy. The Function App keeps its existing app
   settings and identity; the pipeline only replaces code.

If the pipeline's deploy step fails with an authorisation error, the service
connection's own identity lacks *Website Contributor* on the Function App.
That is a Terraform change (a role assignment for the service connection's
service principal), not something anyone clicks.

## 6. What to send if you want a second pair of eyes

The mapper's full output, and the `?` rows' answers from §3. Not the
`.tfstate`, which can contain things the app never uses but a reviewer should
not see; and not the `.env` with values filled in, since it names internal
hosts — the mapper output already shows them in a form that is fine to share
inside the organisation.
