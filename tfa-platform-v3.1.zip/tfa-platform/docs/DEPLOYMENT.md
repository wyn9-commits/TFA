# Deployment Guide

The infra repo's Terraform provisions the infrastructure, and it already
exists. This repository deploys **code only**. `infra/README.md` lists what
the app uses from that infra. This guide gives the order of operations.

You get access through an Entra group and through Azure DevOps pipelines.
Nothing here needs portal access or rights on a subscription, and nothing
here creates an Azure resource.

## Order of operations (per environment)

1. **Fill `.env` and run preflight from the laptop.** You need the VPN or the
   jump host, because the endpoints are private.
   - Copy `.env.template` to `.env` and fill it in. The setting names are the
     legacy app's. The values come from the infra tfvars or the ADO infra
     pipeline log (`python scripts/map_terraform.py apply.log --write`).
     The SQL login comes from Key Vault (`mssql_server_username` and
     `mssql_server_password`).
   - Run:
     ```bash
     az login
     python scripts/preflight.py
     ```
     Preflight labels each failure NETWORK, LOGIN, AUTH, CONFIG or SCHEMA and
     says who fixes it. It also confirms the paths the app will take:
     - reading: PDF text plus images, because there is no Document Intelligence
     - status: kept in SQL, because there is no Cosmos
     - SQL sign-in: the Key Vault login
     - model: gpt-4o

     Don't go further while a NETWORK or AUTH failure is open.

2. **Database.** The app creates its two status tables on first start. If
   the database already holds v2 data, deduplicate it first with
   `db/migrations/001_dedupe_incident_2025_08.sql`, on a restored copy first.
   To see or apply all the DDL yourself:
   `PYTHONPATH=src python scripts/generate_sql_ddl.py > migration.sql`.

3. **Smoke test from the laptop, against the real resources:**
   ```bash
   python start.py --azure
   ```
   1. Upload one real folio on the Upload tab.
   2. Press *Process now* on Home.
   3. Read the row on View Folios.

   The rows are keyed on a content-addressed `document_id`, so uploading the
   same file again replaces its rows instead of duplicating them.

   Then score your labelled goldens against gpt-4o:
   `python -m evals.local_eval --azure`.

4. **SharePoint, optional, one-time admin step.** Grant the app's managed
   identity the Graph `Sites.Selected` application permission, scoped to the
   TFA site only:
   ```
   POST https://graph.microsoft.com/v1.0/sites/{site-id}/permissions
   { "roles": ["read"],
     "grantedToIdentities": [ { "application": {
         "id": "<managed-identity-client-id>", "displayName": "tfa-platform" } } ] }
   ```
   Then put `TFA_SHAREPOINT_SITE_ID` and `TFA_SHAREPOINT_DRIVE_ID` in the
   App Service settings. Add them to the infra tfvars `app_settings` so
   Terraform keeps them.

5. **Deploy: run `azure-pipelines.yml` in ADO.**
   - **Test:** unit tests, then the eval gate (`money_exact` ≥ 0.95).
   - **Build:** builds the image and pushes `$(Build.BuildId)` and
     `latest-dev` to `hdsdscmndevscuscr.azurecr.io/travel-folio-analysis-app`.
   - **Deploy:** restarts the App Service so it pulls `latest-dev`, then
     waits for `/health` to return 200.

   The image tag set on the app never changes, so it never drifts from
   Terraform.

6. **Check the deployed app.**
   - Open it through Front Door. App Service signs you in.
   - If your email is in `ALLOWED_EMAILS`, you get the dashboard. Otherwise
     you get *Access denied*.
   - The Home tab shows the mode line: `dev — gpt-4o — PDF text + page
     images — status in SQL — SQL via sql-login`.

## Observability

- Application Insights. Its connection string is in Key Vault as
  `app_insights_connection_string`, and the infra has a web test on `/health`.
- Splunk: through the organisation's existing Log Analytics ingestion. This
  app adds no new ingestion pattern.
- Optional LLM-step tracing: `TFA_LANGSMITH_ENABLED=true`. Redaction is on
  by default.

## Operational runbook (day 2)

| Symptom | Where to look | Action |
|---|---|---|
| Preflight: NETWORK | your connection | Connect to the VPN or jump host. No role change will help. |
| Preflight: AUTH on blob or OpenAI | the role named in the report | Ask the group administrator for that data-plane role. |
| Preflight: SQL login failed | Key Vault secret values | The `.env` / app setting does not match `mssql_server_password`. It may have been rotated. |
| Model returns 400 mentioning the schema | Home → document detail | The API version is too old for structured outputs. Set `AZURE_OPENAI_STARTBURST_API_VERSION` to 2024-10-21 or later. |
| Document stuck "queued" | `tfa_processing_status` | Press *Process now* on Home. Check that the app has only one gunicorn worker. |
| Nothing arrives from SharePoint | Home → SharePoint line; `tfa_kv` row `delta-link` | Check the site and drive IDs and the Graph permission. Deleting the `delta-link` row forces a full re-scan, which is safe because content hashes prevent re-ingest. |
| `needs_review` growing | `vw_needs_review` | Triage weekly. Each correction is either a prompt or schema gap (fix it and add a golden) or genuinely ambiguous (correctly routed). |
| Deployed but old version showing | ADO Deploy stage log | If the service connection can't see the app, it skips the restart. Restart the app, or turn on continuous deployment in the infra tfvars. |
| Model deprecation notice | infra tfvars | Change the deployment in the infra repo, then `AZURE_OPENAI_STARTBURST_MODEL_NAME`. Re-run `evals.local_eval --azure` before promoting. |
