NOTE: place colombia_wgt000032.pdf (from SharePoint) next to this file.


SYNTHETIC GOLDENS (co_estelar_*, co_hilton_*, ar_libertador_*, mx_camino_*,
ec_wings_*): generated documents whose ground truth is known by construction.
They exercise the harness and gate regressions in the parser and validators.
They say NOTHING about accuracy on real folios. Label real documents here —
20 to 50 across the four countries — and run `python -m evals.local_eval
--azure`; that number is the one to put in front of anyone.
