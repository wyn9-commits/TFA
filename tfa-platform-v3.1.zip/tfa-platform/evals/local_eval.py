"""Score the goldens with no LangSmith and, by default, no Azure.

    python -m evals.local_eval                      # local rules on the goldens
    python -m evals.local_eval --azure              # the real DI + model stack
    python -m evals.local_eval --min-money-exact 0.9   # exit 1 below the bar (CI)

The number that matters is `money_exact`: the share of labelled money values
read to the cent. Everything else is diagnostic. Until this has been run with
`--azure` over real documents, the platform's accuracy is an expectation,
not a measurement — and that is as true of this harness as of any other.

The local path exists so the harness itself is exercised on every commit and
so a change to the parser or the validators shows up as a number, not a
feeling. Its scores are for the rule-based extractor and say nothing about
the model.
"""

from __future__ import annotations

import argparse
import json
import logging
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
sys.path.insert(0, str(ROOT))

from evals.evaluators import (doc_type_correct, field_accuracy, money_exact,  # noqa: E402
                              review_routing, sum_check)

GOLDEN_DIR = Path(__file__).parent / "golden"
EVALUATORS = (money_exact, sum_check, doc_type_correct, field_accuracy, review_routing)


def golden_pairs(search: list[Path]) -> list[tuple[Path, dict]]:
    """A golden is `<stem>.expected.json` plus a document `<stem>.<ext>` found
    in the golden dir or any of the extra search dirs."""
    pairs = []
    for exp in sorted(GOLDEN_DIR.glob("*.expected.json")):
        stem = exp.name[: -len(".expected.json")]
        doc = None
        for d in [GOLDEN_DIR, *search]:
            for ext in (".pdf", ".png", ".jpg", ".jpeg", ".xlsx"):
                if (d / f"{stem}{ext}").exists():
                    doc = d / f"{stem}{ext}"
                    break
            if doc:
                break
        if doc is None:
            logging.warning("golden %s has no document beside it; skipped", stem)
            continue
        pairs.append((doc, json.loads(exp.read_text(encoding="utf-8"))))
    return pairs


def _local_engine():
    from local.adapters import LocalLayoutExtractor, LocalStructuredLLM
    from tfa_core.extraction.llm_extractor import LLMExtractor
    return LocalLayoutExtractor(), LLMExtractor(LocalStructuredLLM(), max_attempts=3, max_output_tokens=8000)


def _azure_engine():
    # Same reading path and model the deployed app uses: PDF text + page
    # images unless Document Intelligence is configured, then the model.
    from tfa_core.config import get_credential, get_settings
    from tfa_core.extraction.pipeline import build_extractor, build_layout
    s, cred = get_settings(), get_credential()
    return build_layout(s, cred), build_extractor(s, cred)


def run_one(layout_ex, engine, doc: Path) -> dict:
    from tfa_core.extraction.llm_extractor import ExtractionFailed
    content = doc.read_bytes()
    name = doc.name.lower()
    if name.endswith((".xlsx", ".xlsm", ".xls")):
        from tfa_core.extraction.excel_reader import analyze_excel
        layout = analyze_excel(content, doc.name)
    elif name.endswith(".pdf"):
        layout = layout_ex.analyze_pdf(content, doc.name)
    else:
        layout = layout_ex.analyze_image(content, doc.name, "image/png" if name.endswith(".png") else "image/jpeg")
    try:
        outcome = engine.extract(layout, doc.name)
    except ExtractionFailed as exc:
        return {"_failed": str(exc), "needs_review": True, "attempts": 0}
    out = outcome.extraction.model_dump(mode="json")
    out["needs_review"] = outcome.needs_review
    out["attempts"] = outcome.attempts
    return out


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--azure", action="store_true", help="use the configured Azure OpenAI model (the deployed reading path)")
    ap.add_argument("--docs", type=Path, action="append", default=[], help="extra dir(s) to find golden documents in")
    ap.add_argument("--min-money-exact", type=float, default=None, help="exit 1 if the mean falls below this")
    ap.add_argument("--json", type=Path, help="write per-document results here")
    ap.add_argument("-v", action="store_true")
    args = ap.parse_args()
    logging.basicConfig(level=logging.INFO if args.v else logging.WARNING, format="%(levelname)s %(message)s")
    for noisy in ("tfa_core", "azure"):
        if not args.v:
            logging.getLogger(noisy).setLevel(logging.ERROR)

    pairs = golden_pairs(args.docs + [ROOT / "local" / "inbox"])
    if not pairs:
        print("No goldens with documents. Label some: evals/golden/README.txt")
        return 1

    layout_ex, engine = _azure_engine() if args.azure else _local_engine()
    mode = "Azure (configured model)" if args.azure else "local rules (no model)"
    print(f"\nEvaluating {len(pairs)} golden(s) with {mode}\n")

    rows, totals = [], {e.__name__: [] for e in EVALUATORS}
    hdr = f"{'document':<34}" + "".join(f"{e.__name__:>16}" for e in EVALUATORS)
    print(hdr); print("-" * len(hdr))
    for doc, expected in pairs:
        out = run_one(layout_ex, engine, doc)
        scores = {}
        for ev in EVALUATORS:
            try:
                r = ev(out, expected)
                scores[ev.__name__] = r
                totals[ev.__name__].append(float(r.get("score") or 0.0))
            except Exception as exc:                        # one evaluator must not sink the run
                scores[ev.__name__] = {"score": 0.0, "comment": f"evaluator error: {exc}"}
                totals[ev.__name__].append(0.0)
        print(f"{doc.name[:33]:<34}" + "".join(f"{scores[e.__name__]['score']:>16.2f}" for e in EVALUATORS))
        if args.v:
            for e in EVALUATORS:
                print(f"    {e.__name__}: {scores[e.__name__].get('comment', '')}")
        rows.append({"document": doc.name, "scores": {k: v["score"] for k, v in scores.items()},
                     "comments": {k: v.get("comment") for k, v in scores.items()},
                     "failed": out.get("_failed")})

    print("-" * len(hdr))
    means = {k: (sum(v) / len(v) if v else 0.0) for k, v in totals.items()}
    print(f"{'mean':<34}" + "".join(f"{means[e.__name__]:>16.2f}" for e in EVALUATORS))
    print(f"\nmoney_exact = {means['money_exact']:.3f} over {len(pairs)} document(s), {mode}")

    if args.json:
        args.json.write_text(json.dumps({"mode": mode, "means": means, "documents": rows}, indent=2))
        print(f"wrote {args.json}")

    if args.min_money_exact is not None and means["money_exact"] < args.min_money_exact:
        print(f"\nFAIL: money_exact {means['money_exact']:.3f} < {args.min_money_exact}")
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
