#!/usr/bin/env python3
"""Run the TFA pipeline on a laptop. No Azure subscription or resource group.

    python local/run_local.py                 # process everything in local/inbox
    python local/run_local.py path/to.pdf     # process one document
    python local/run_local.py --show          # print what is stored

The production pipeline, validators, reconciliation and record builder all run
unchanged. Only the five adapters at the edges are local ones — see
`local/adapters.py`. That substitution is the whole reason the ports exist.

Set TFA_LLM_ENDPOINT, TFA_LLM_DEPLOYMENT and a working `az login` to route
extraction through your existing Azure OpenAI resource instead of the local
parser. You do not need a resource group of your own to call a resource that
already exists; you need the role on it.
"""

from __future__ import annotations

import argparse
import logging
import os
import sys
from decimal import Decimal
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
sys.path.insert(0, str(ROOT))

from local.adapters import (  # noqa: E402
    LocalBlobStore, LocalLayoutExtractor, LocalStructuredLLM,
    PassthroughAzureLLM, SqliteFolioStore, SqliteStatusStore, load_rate_context,
)

def load_env() -> None:
    """Read local/.env if present. Values already in the environment win."""
    env = ROOT / "local" / ".env"
    if not env.exists():
        return
    for line in env.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if line and not line.startswith("#") and "=" in line:
            k, _, v = line.partition("=")
            os.environ.setdefault(k.strip(), v.strip().strip('"').strip("'"))


INBOX = ROOT / "local" / "inbox"
DB = ROOT / "local" / "tfa_local.db"
CONTAINER = "travel-folios"

BOLD, DIM, GREEN, RED, YELLOW, RESET = (
    "\033[1m", "\033[2m", "\033[32m", "\033[31m", "\033[33m", "\033[0m")


class LocalSettings:
    """The subset of Settings the pipeline actually reads.

    Built here rather than via `get_settings()` because that requires seven
    Azure endpoints to be present before it will construct at all, which is
    precisely the barrier this runner removes.
    """
    environment = "local"
    raw_container = CONTAINER
    sql_table = "folio_lines"
    llm_extraction_max_attempts = 3
    llm_max_output_tokens = 8000
    extraction_engine = "loop"
    render_dpi = 150
    max_pages_per_doc = 20


def build_local_pipeline():
    """Local composition root. Mirrors `tfa_core.container.build_pipeline`."""
    from tfa_core.extraction.llm_extractor import LLMExtractor
    from tfa_core.extraction.pipeline import FolioPipeline

    settings = LocalSettings()
    local_llm = LocalStructuredLLM()
    llm, mode = local_llm, "local rules"

    def _env(*names: str, default: str = "") -> str:
        for n in names:
            if os.environ.get(n, "").strip():
                return os.environ[n].strip()
        return default

    endpoint = _env("TFA_LLM_ENDPOINT", "AZURE_OPENAI_STARTBURST_END_POINT")
    deployment = _env("TFA_LLM_DEPLOYMENT", "AZURE_OPENAI_STARTBURST_MODEL_NAME")
    api_version = _env("TFA_LLM_API_VERSION", "AZURE_OPENAI_STARTBURST_API_VERSION", default="2024-10-21")
    api_key = _env("TFA_LLM_API_KEY", "AZURE_OPENAI_STARTBURST_API_KEY") or None
    if endpoint and deployment:
        try:
            from azure.identity import DefaultAzureCredential
            from tfa_core.llm.provider import build_llm

            inner = build_llm(
                os.environ.get("TFA_LLM_PROVIDER", "azure_openai"),
                endpoint, deployment, api_version,
                None if api_key else DefaultAzureCredential(), api_key=api_key,
            )
            llm = PassthroughAzureLLM(inner, local_llm)
            how = "API key" if api_key else "az login"
            mode = f"Azure OpenAI ({deployment}) via {how}, local rules on failure"
        except Exception as exc:
            print(f"{YELLOW}Azure OpenAI unavailable, using local rules: {exc}{RESET}")

    analyzer = LocalLayoutExtractor(max_pages=settings.max_pages_per_doc)
    store, store_mode = build_store(settings.sql_table)

    pipeline = FolioPipeline(
        settings=settings,
        blobs=LocalBlobStore(ROOT / "local" / "blob"),
        layout=analyzer,
        extractor=LLMExtractor(
            llm,
            max_attempts=settings.llm_extraction_max_attempts,
            max_output_tokens=settings.llm_max_output_tokens,
        ),
        sql=store,
        status=SqliteStatusStore(DB),
    )
    return pipeline, store, mode, store_mode


def build_store(table: str):
    return SqliteFolioStore(DB, table), f"SQLite {DB.name}"


def money(v) -> str:
    return "—" if v in (None, "") else f"{Decimal(str(v)):,.2f}"


def process(paths: list[Path], identifier: str) -> int:
    from tfa_core.extraction.pipeline import WorkItem

    pipeline, store, mode, store_mode = build_local_pipeline()
    blobs = LocalBlobStore(ROOT / "local" / "blob")
    # Prefer a local rate card when one is present, so the sample documents
    # produce a real variance. seed/ holds two example properties that match
    # none of them, and an all-zero variance column reads as a broken
    # reconciliation rather than as missing reference data.
    local_rates = ROOT / "local" / "negotiated_rates.local.json"
    rates_file = local_rates if local_rates.exists() else ROOT / "seed" / "negotiated_rates.json"
    rates = load_rate_context(rates_file, ROOT / "seed" / "fx.json")

    print(f"\n{BOLD}Extraction{RESET}  {mode}")
    print(f"{BOLD}Database{RESET}    {store_mode}")
    print(f"{BOLD}Rates{RESET}       {rates_file.relative_to(ROOT)} "
          f"{DIM}(example data — replace before trusting any variance){RESET}\n")

    failures = 0
    for path in paths:
        blob_path = f"{identifier}-local/{path.name}"
        blobs.upload(CONTAINER, blob_path, path.read_bytes(), overwrite=True)
        item = WorkItem(
            container=CONTAINER, blob_path=blob_path, identifier=identifier,
            uploading_person_name="local", file_name=path.name,
        )
        try:
            status = pipeline.process(item, rates)
        except Exception as exc:
            print(f"  {RED}✗{RESET} {path.name}  {type(exc).__name__}: {exc}")
            failures += 1
            continue

        colour = {"succeeded": GREEN, "needs_review": YELLOW}.get(status, RED)
        rows = [r for r in store.rows() if r.get("file_name") == path.name]
        first = rows[0] if rows else {}
        # Document-level total, denormalised onto every line (see the
        # FolioRecord docstring: one row = one service line). Summing it
        # across rows multiplies the variance by the line count.
        variance = Decimal(first.get("usd_total_amount_differ") or 0)
        flagged = any(r.get("issue_found") == "Yes" for r in rows)

        print(f"  {colour}{status:<13}{RESET} {path.name}")
        print(f"      {first.get('folio_hotel_name') or '—'}"
              f"   {first.get('country') or '—'}"
              f"   {first.get('currency') or '—'}   {len(rows)} line(s)")
        print(f"      per night  {money(first.get('usd_per_day_price'))} USD"
              f"   negotiated {money(first.get('negotiated_rate'))} USD")
        print(f"      variance   {(RED if flagged else DIM)}{money(variance)} USD{RESET}"
              f"   {'overcharge found' if flagged else 'within agreement'}")
        if first.get("extraction_warnings"):
            print(f"      {DIM}{first['extraction_warnings']}{RESET}")

    return failures


def show() -> int:
    store, _ = build_store("folio_lines")
    rows = store.rows()
    if not rows:
        print("Nothing stored yet. Run the pipeline first.")
        return 0
    print(f"{BOLD}{'file':<34}{'hotel':<26}{'cur':<5}"
          f"{'total':>14}{'variance USD':>15}{RESET}")
    for r in rows:
        print(f"{(r.get('file_name') or '')[:33]:<34}"
              f"{(r.get('folio_hotel_name') or '')[:25]:<26}"
              f"{(r.get('currency') or ''):<5}"
              f"{money(r.get('total_amount')):>14}"
              f"{money(r.get('usd_total_amount_differ')):>15}")
    return 0


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("documents", nargs="*", type=Path)
    ap.add_argument("--identifier", default="local_pilot")
    ap.add_argument("--show", action="store_true", help="print stored rows and exit")
    ap.add_argument("--verbose", action="store_true")
    args = ap.parse_args()

    load_env()
    logging.basicConfig(
        level=logging.INFO if args.verbose else logging.WARNING,
        format=f"{DIM}%(name)s: %(message)s{RESET}")

    if args.show:
        return show()

    INBOX.mkdir(parents=True, exist_ok=True)
    paths = args.documents or sorted(
        p for p in INBOX.rglob("*") if p.suffix.lower() in {".pdf", ".png", ".jpg", ".jpeg"}
    )
    if not paths:
        print(f"No documents. Put PDFs in {INBOX} or pass a path.")
        return 1

    return 1 if process(paths, args.identifier) else 0


if __name__ == "__main__":
    raise SystemExit(main())
