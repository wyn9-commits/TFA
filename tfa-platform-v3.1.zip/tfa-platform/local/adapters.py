"""Local implementations of the domain ports.

These exist so the pipeline in `tfa_core` can run on a laptop with no Azure
subscription, resource group, or credential. Every one of them satisfies a
Protocol in `tfa_core.domain.ports`, so the domain and the pipeline are the
production code — only the edges are swapped.

    BlobStore        -> a folder
    DocumentAnalyzer -> PyMuPDF text, no OCR
    StructuredLLM    -> country-aware rules, or Azure OpenAI when configured
    FolioWriteStore  -> SQLite
    StatusStore      -> SQLite

Nothing here belongs in a deployed build. It is the development edge of the
hexagon, which is the reason the ports exist.
"""

from __future__ import annotations

import json
import re
import sqlite3
import unicodedata
from decimal import Decimal
from pathlib import Path
from typing import Any, Iterator, Optional

ROOT = Path(__file__).resolve().parents[1]

# --------------------------------------------------------------------------- #
# Storage
# --------------------------------------------------------------------------- #


class LocalBlobStore:
    """Satisfies BlobStore against a directory tree."""

    def __init__(self, root: Path):
        self._root = Path(root)
        self._root.mkdir(parents=True, exist_ok=True)

    def _path(self, container: str, blob_path: str) -> Path:
        return self._root / container / blob_path

    def download(self, container: str, blob_path: str) -> bytes:
        return self._path(container, blob_path).read_bytes()

    def stream(self, container: str, blob_path: str,
               chunk_size: int = 1 << 20) -> Iterator[bytes]:
        with self._path(container, blob_path).open("rb") as fh:
            while chunk := fh.read(chunk_size):
                yield chunk

    def upload(self, container: str, blob_path: str, data: bytes,
               overwrite: bool = True) -> None:
        target = self._path(container, blob_path)
        if target.exists() and not overwrite:
            raise FileExistsError(blob_path)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)

    def version(self, container: str, blob_path: str) -> str:
        """Deliberately the modification time, not a hash.

        INCIDENT-2025-08 came from storage metadata being used as document
        identity. The pipeline hashes content itself; this value is only ever
        a change hint, and the name must not suggest otherwise.
        """
        return str(self._path(container, blob_path).stat().st_mtime_ns)


# --------------------------------------------------------------------------- #
# Document analysis
# --------------------------------------------------------------------------- #


class LocalLayoutExtractor:
    """Stands in for Document Intelligence using the embedded PDF text layer.

    Exposes `analyze_pdf` / `analyze_image` because `FolioPipeline` calls those
    directly, and `analyze` for the DocumentAnalyzer port.

    The limitation is worth stating plainly: there is no OCR here. A born-digital
    e-invoice reads perfectly; a scanned or photographed folio returns little or
    nothing, and that is the case Document Intelligence exists to handle.
    """

    def __init__(self, max_pages: int = 20):
        self._max_pages = max_pages

    def analyze_pdf(self, pdf_bytes: bytes, filename: str):
        from tfa_core.extraction.document_intelligence import DocumentLayout

        try:
            import fitz  # PyMuPDF
        except ImportError as exc:
            raise RuntimeError("PyMuPDF is required for local PDF reading") from exc

        text_parts: list[str] = []
        with fitz.open(stream=pdf_bytes, filetype="pdf") as doc:
            pages = min(doc.page_count, self._max_pages)
            for i in range(pages):
                text_parts.append(doc[i].get_text("text"))
            page_count = doc.page_count

        text = "\n".join(text_parts)
        return DocumentLayout(
            markdown_text=text,
            page_count=page_count,
            page_images_b64=[],
            languages=[],
            # No OCR ran, so there is no measured confidence. Reporting 1.0
            # would claim a certainty nothing established.
            ocr_confidence_floor=1.0 if text.strip() else 0.0,
        )

    def analyze_image(self, image_bytes: bytes, filename: str, media_type: str):
        from tfa_core.extraction.document_intelligence import DocumentLayout

        return DocumentLayout(
            markdown_text="", page_count=1, page_images_b64=[],
            languages=[], ocr_confidence_floor=0.0,
        )

    def analyze(self, content: bytes, filename: str):
        if filename.lower().endswith(".pdf"):
            return self.analyze_pdf(content, filename)
        return self.analyze_image(content, filename, "image/png")


# --------------------------------------------------------------------------- #
# Extraction
# --------------------------------------------------------------------------- #

MONEY = r"[\d\.,]+"
ISO_DATE = r"\d{2}[/-]\d{2}[/-]\d{4}"

COUNTRY_MARKERS = [
    ("Colombia", (r"\bDIAN\b", r"\bCUFE\b")),
    ("Argentina", (r"FACTURA\s+B\b", r"C\.?U\.?I\.?T\.?", r"\bAFIP\b")),
    ("Mexico", (r"\bCFDI\b", r"\bRFC\b")),
    ("Ecuador", (r"\bR\.?U\.?C\.?\b", r"\bSRI\b")),
]
CURRENCY_BY_COUNTRY = {
    "Colombia": "COP", "Argentina": "ARS", "Mexico": "MXN", "Ecuador": "USD",
}


def _amount(raw: str) -> Decimal:
    """Normalise a localised money string.

    '.' is the thousands separator and ',' the decimal separator in these
    markets — the reverse of the US convention. Reading it the US way changes
    a total by three orders of magnitude and nothing downstream will notice.
    """
    s = raw.strip().replace(" ", "").replace("$", "")
    if "," in s and "." in s:
        s = (s.replace(".", "").replace(",", ".")
             if s.rfind(",") > s.rfind(".") else s.replace(",", ""))
    elif "," in s:
        s = s.replace(",", ".") if len(s.split(",")[-1]) <= 2 else s.replace(",", "")
    return Decimal(s or "0")


def _iso(d: Optional[str]) -> Optional[str]:
    if not d:
        return None
    m = re.match(r"(\d{2})[/-](\d{2})[/-](\d{4})", d)
    return f"{m.group(3)}-{m.group(2)}-{m.group(1)}" if m else None


def _find(text: str, pattern: str) -> Optional[str]:
    m = re.search(pattern, text, re.I | re.M)
    return m.group(1).strip() if m else None


class LocalStructuredLLM:
    """Satisfies StructuredLLM with rules instead of a model.

    Returns a dict shaped like `FolioExtraction`. The pipeline's own schema
    validation and consistency checks then run exactly as they do in
    production — which is the point: the validators are what is being
    exercised, not this parser.

    It recognises the four layouts the project has samples for. Anything else
    produces a thin extraction that the validators route to review, which is
    the correct outcome for a format nobody has taught it yet.
    """

    def extract(self, system_prompt: str, user_parts: list[dict[str, Any]],
                json_schema: dict[str, Any], schema_name: str,
                max_output_tokens: int) -> dict[str, Any]:
        text = "\n".join(p.get("text", "") for p in user_parts if p.get("type") == "text")
        text = text.split("OCR_MARKDOWN:", 1)[-1]
        return self._parse(text)

    def _parse(self, text: str) -> dict[str, Any]:
        upper = text.upper()
        country = next(
            (name for name, pats in COUNTRY_MARKERS
             if any(re.search(p, upper) for p in pats)),
            None,
        )
        currency = (
            _find(text, r"Moneda\s*[:\-]?\s*([A-Z]{3})")
            or CURRENCY_BY_COUNTRY.get(country or "", "USD")
        )

        is_air = bool(re.search(r"Boleto\s+A[ée]reo|Air\s+Ticket|Wings|Fare\b", text, re.I))
        vendor = (
            _find(text, r"^\s*(?:Hotel|Hospedaje)\s*[:\-]\s*(.+)$")
            or _find(text, r"^\s*Vendor\s*[:\-]\s*(.+)$")
            or _find(text, r"^([A-Z][A-Z \.\&]{6,})$")
            or "UNKNOWN"
        ).strip()

        nightly, ancillary = self._charges(text, is_air)
        stay_dates = sorted(d for d in (n.get("stay_date") for n in nightly) if d)
        folio_date = _iso(_find(text, rf"(?:Fecha|Date)\s*[:\-]?\s*({ISO_DATE})"))
        checkin = stay_dates[0] if stay_dates else folio_date
        checkout = stay_dates[-1] if stay_dates else folio_date

        # Colombia, Mexico and Ecuador add IVA on top of the charge lines, so
        # it is a real ancillary line. Omitting it makes the lines under-sum
        # against the printed total and the pipeline's cross-foot validator
        # rejects the document — correctly. Argentina is the exception: its
        # IVA is already inside the prices and belongs in
        # informational_tax_amount, never here, or the tax is counted twice.
        if country != "Argentina":
            additive = self._additive_tax(text)
            if additive is not None and not any(
                a["category"] == "tax" for a in ancillary
            ):
                ancillary.append({
                    "description": "IVA",
                    "english_description": "VAT",
                    "amount": str(additive),
                    "category": "tax",
                })

        return {
            "document_type": "air_ticket_invoice" if is_air else "hotel_folio",
            "hotel_name": vendor,
            "country": country,
            "currency": currency,
            # The number follows an explicit "No/N°/#/:" marker. Without
            # requiring the marker, "FACTURA ELECTRONICA" matched the word
            # after FACTURA and every Colombian invoice number came out as
            # "ELECTRONICA".
            "invoice_number": _find(
                text, r"(?:Factura|Invoice|Folio|Comprobante)\s*(?:No\.?|N[°º]|Nro\.?|#)\s*[:\-]?\s*([A-Z0-9][A-Z0-9\-]{3,})")
                              or _find(text, r"^\s*(?:Factura|Invoice|Folio)\s*:\s*([A-Z0-9][A-Z0-9\-]{3,})\s*$"),
            "e_invoice_id": _find(text, r"CUFE\s*[:\-]?\s*([A-Za-z0-9]{8,})"),
            "supplier_tax_id": _find(text, r"(?:NIT|C\.?U\.?I\.?T\.?|R\.?U\.?C\.?|RFC)\s*[:\-]?\s*([\d\.\-A-Z]{6,})"),
            "folio_date": _iso(_find(text, rf"(?:Fecha|Date)\s*[:\-]?\s*({ISO_DATE})")),
            # Check-in/out from the dated room lines when the folio has them;
            # otherwise the folio date stands in for both. Without a checkout
            # the pipeline cannot derive year_month, and every date filter in
            # the UI goes dark.
            "checkin_date": checkin,
            "checkout_date": checkout,
            "nightly_charges": nightly,
            "ancillary_charges": ancillary,
            "total_amount": str(self._total(text)) if self._total(text) is not None else None,
            "informational_tax_amount": self._included_tax(text, country),
            "low_confidence_fields": ["hotel_name"] if vendor == "UNKNOWN" else [],
        }

    def _charges(self, text: str, is_air: bool) -> tuple[list[dict], list[dict]]:
        nightly: list[dict] = []
        ancillary: list[dict] = []

        # Nights collapsed onto one line: "Alojamiento 3 noches x 198.500,00".
        # `amount` is the line TOTAL per the schema, so the printed per-night
        # figure is multiplied out rather than stored as-is.
        for m in re.finditer(
            rf"(Alojamiento|Hospedaje|Room\s+charge)[^\n]*?(\d+)\s*(?:noches?|nights?)[^\n\d]*({MONEY})",
            text, re.I,
        ):
            nights = int(m.group(2))
            per_night = _amount(m.group(3))
            nightly.append({
                "stay_date": None,
                "description": m.group(0).strip(),
                "english_description": f"Accommodation, {nights} nights",
                "amount": str(per_night * nights),
                "nights": nights,
            })

        # One dated line per charge.
        for m in re.finditer(rf"^({ISO_DATE})\s+(.{{3,70}}?)\s+({MONEY})\s*$", text, re.M):
            date_s, desc, amt = m.group(1), m.group(2).strip(), _amount(m.group(3))
            category = self._category(desc)
            if category == "room" and not any(
                n.get("description") == desc for n in nightly
            ):
                nightly.append({
                    "stay_date": _iso(date_s),
                    "description": desc,
                    "english_description": desc,
                    "amount": str(amt),
                    "nights": 1,
                })
            elif category != "room":
                ancillary.append({
                    "description": desc,
                    "english_description": desc,
                    "amount": str(amt),
                    "category": category,
                })

        if is_air and not nightly and not ancillary:
            for m in re.finditer(rf"(Fare|Tarifa)[^\n\d]*({MONEY})", text, re.I):
                ancillary.append({
                    "description": m.group(0).strip(),
                    "english_description": "Air fare",
                    "amount": str(_amount(m.group(2))),
                    "category": "airfare",
                })
            for m in re.finditer(rf"(service fee|admin[^\n\d]*)[^\n\d]*({MONEY})", text, re.I):
                ancillary.append({
                    "description": m.group(0).strip(),
                    "english_description": "Service fee",
                    "amount": str(_amount(m.group(2))),
                    "category": "admin_fee",
                })

        return nightly, ancillary

    @staticmethod
    def _category(description: str) -> str:
        """Order matters.

        'Restaurante cargo a habitacion' contains the word for room. Testing
        the room pattern first prices a dinner as a night, which produces a
        large credit that does not exist.
        """
        d = description.lower()
        if re.search(r"desayuno|breakfast|restaurant|comida|cena|minibar", d):
            return "food_beverage"
        if re.search(r"parqueadero|parking|estacionamiento", d):
            return "parking"
        if re.search(r"\biva\b|impuesto|\btax\b", d):
            return "tax"
        if re.search(r"habitaci|room|alojamiento|hospedaje|noche|night", d):
            return "room"
        return "other"

    @staticmethod
    def _total(text: str) -> Optional[Decimal]:
        # The lookbehind matters: "Subtotal" contains "total", and without it
        # the grand total reads as the pre-tax figure.
        raw = _find(
            text,
            rf"^.*(?<![A-Za-z])(?:Total\s+a\s+pagar|Importe\s+total|Grand\s+Total|Total)[^\n]*?\$?\s*({MONEY})\s*$",
        )
        return _amount(raw) if raw else None

    @staticmethod
    def _additive_tax(text: str) -> Optional[Decimal]:
        """IVA charged on top of the lines, as an amount.

        Anchored to end of line and taking the last token, because the label
        itself contains a number: "IVA (19%) 418.950,00" otherwise reads as 19.
        """
        raw = _find(text, rf"^.*(?:IVA|I\.V\.A\.|Impuesto)[^\n]*?\$?\s*({MONEY})\s*$")
        return _amount(raw) if raw else None

    @staticmethod
    def _included_tax(text: str, country: Optional[str]) -> Optional[str]:
        """Argentine Factura B prints IVA that is already inside the charges.

        The schema wants it in `informational_tax_amount`, never as an
        ancillary line — recording it as a charge double-counts the tax.
        """
        if country != "Argentina":
            return None
        raw = _find(text, rf"^.*I\.?V\.?A\.?[^\n]*?({MONEY})\s*$")
        return str(_amount(raw)) if raw else None


class PassthroughAzureLLM:
    """Uses the real Azure OpenAI adapter when an endpoint is configured.

    Falls back to the local parser on any failure so a missing role assignment
    or an expired key degrades the run instead of ending it.
    """

    def __init__(self, inner, fallback: LocalStructuredLLM):
        self._inner = inner
        self._fallback = fallback
        self.used_fallback = False
        self.first_error: Optional[str] = None

    def extract(self, **kwargs) -> dict[str, Any]:
        try:
            return self._inner.extract(**kwargs)
        except Exception as exc:
            # Say so loudly the first time. A silent fallback means someone
            # reads local rule output as model output, which is a worse
            # failure than stopping would have been.
            if not self.used_fallback:
                self.first_error = f"{type(exc).__name__}: {exc}"
                print(
                    f"\033[33mModel call failed — every document in this run is "
                    f"being extracted by the LOCAL RULES, not the model.\033[0m\n"
                    f"  {self.first_error}"
                )
            self.used_fallback = True
            return self._fallback.extract(**kwargs)


# --------------------------------------------------------------------------- #
# Persistence
# --------------------------------------------------------------------------- #


class SqliteFolioStore:
    """Satisfies the write store as `FolioPipeline` actually calls it.

    Note the signature: `upsert_document(document_id, records)`, positional.
    That is what `ingest.py` calls, and it is NOT what the `FolioWriteStore`
    Protocol in ports.py declares — the Protocol says keyword-only
    `header=`/`lines=`. The two concrete Azure adapters disagree with each
    other on this too. Matching the call site is the only way this runs.
    """

    def __init__(self, db_path: Path, table: str = "folio_lines"):
        self._path = Path(db_path)
        self._path.parent.mkdir(parents=True, exist_ok=True)
        self._table = table
        self._init()

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self._path)
        conn.row_factory = sqlite3.Row
        return conn

    def _init(self) -> None:
        from tfa_core.schemas import SQL_COLUMNS

        cols = ", ".join(f'"{c}" TEXT' for c in SQL_COLUMNS)
        with self._connect() as conn:
            conn.execute(
                f'CREATE TABLE IF NOT EXISTS {self._table} '
                f'("document_id" TEXT, {cols})'
            )
            conn.execute(
                f'CREATE INDEX IF NOT EXISTS idx_doc ON {self._table} ("document_id")'
            )

    def upsert_document(self, document_id: str, records: list) -> int:
        """Delete-then-insert in one transaction, keyed by document_id.

        This is the behaviour that makes redelivery safe. Re-running the same
        document replaces its rows rather than adding a second set, which is
        what inflated the reconciliation totals in INCIDENT-2025-08.
        """
        from tfa_core.schemas import SQL_COLUMNS
        from tfa_core.storage.repositories import FolioSqlRepository

        cols = ["document_id"] + list(SQL_COLUMNS)
        placeholders = ", ".join("?" for _ in cols)
        collist = ", ".join(f'"{c}"' for c in cols)
        with self._connect() as conn:
            conn.execute(
                f'DELETE FROM {self._table} WHERE "document_id" = ?', (document_id,)
            )
            for rec in records:
                row = [document_id] + [
                    None if v is None else str(v)
                    for v in FolioSqlRepository._row(rec)
                ]
                conn.execute(
                    f"INSERT INTO {self._table} ({collist}) VALUES ({placeholders})", row
                )
            conn.commit()
        return len(records)

    def rows(self, document_id: Optional[str] = None) -> list[dict]:
        with self._connect() as conn:
            if document_id:
                cur = conn.execute(
                    f'SELECT * FROM {self._table} WHERE "document_id" = ?', (document_id,)
                )
            else:
                cur = conn.execute(f"SELECT * FROM {self._table}")
            return [dict(r) for r in cur.fetchall()]


class SqliteStatusStore:
    """Satisfies StatusStore. Separate table from the folio rows, as in Cosmos:
    losing processing status must never mean losing financial data."""

    def __init__(self, db_path: Path):
        self._path = Path(db_path)
        self._path.parent.mkdir(parents=True, exist_ok=True)
        with sqlite3.connect(self._path) as conn:
            conn.execute(
                "CREATE TABLE IF NOT EXISTS processing_status ("
                "document_id TEXT PRIMARY KEY, identifier TEXT, file_name TEXT, "
                "status TEXT, detail TEXT, attempts INTEGER, updated_at TEXT)"
            )

    def mark(self, *, document_id: str, identifier: str, file_name: str,
             status: str, detail: Optional[str] = None,
             attempts: Optional[int] = None) -> None:
        from datetime import datetime, timezone

        with sqlite3.connect(self._path) as conn:
            conn.execute(
                "INSERT INTO processing_status VALUES (?,?,?,?,?,?,?) "
                "ON CONFLICT(document_id) DO UPDATE SET "
                "status=excluded.status, detail=excluded.detail, "
                "attempts=excluded.attempts, updated_at=excluded.updated_at",
                (document_id, identifier, file_name, status, detail, attempts,
                 datetime.now(timezone.utc).isoformat()),
            )
            conn.commit()

    def get(self, document_id: str) -> Optional[dict]:
        with sqlite3.connect(self._path) as conn:
            conn.row_factory = sqlite3.Row
            cur = conn.execute(
                "SELECT * FROM processing_status WHERE document_id = ?", (document_id,)
            )
            row = cur.fetchone()
            return dict(row) if row else None

    def pending_all(self) -> list[dict]:
        with sqlite3.connect(self._path) as conn:
            conn.row_factory = sqlite3.Row
            cur = conn.execute(
                "SELECT * FROM processing_status WHERE status IN ('queued','processing') "
                "ORDER BY updated_at")
            return [dict(r) for r in cur.fetchall()]

    def recent(self, limit: int = 50) -> list[dict]:
        with sqlite3.connect(self._path) as conn:
            conn.row_factory = sqlite3.Row
            cur = conn.execute(
                "SELECT * FROM processing_status ORDER BY updated_at DESC LIMIT ?", (limit,))
            return [dict(r) for r in cur.fetchall()]


# --------------------------------------------------------------------------- #
# Reference data
# --------------------------------------------------------------------------- #


def load_rate_context(rates_file: Path, fx_file: Path):
    """Builds the RateContext from the repo's own seed JSON.

    In the cloud these are blobs; the shape is identical, so replacing
    `seed/negotiated_rates.json` with contracted rates is the only change
    needed to make local output meaningful. Without real rates every
    overcharge column comes back empty, which reads as a bug rather than as
    missing reference data.
    """
    from tfa_core.extraction.reconciliation import FxRate, NegotiatedRate, RateDirectory
    from tfa_core.extraction.pipeline import RateContext

    rates = [
        NegotiatedRate(
            hotel_name=r["hotel_name"],
            country=r.get("country"),
            nightly_rate_usd=Decimal(str(r["nightly_rate_usd"])),
        )
        for r in json.loads(Path(rates_file).read_text(encoding="utf-8"))
    ]
    fx = {
        f["currency"]: FxRate(
            currency=f["currency"], usd_per_unit=Decimal(str(f["usd_per_unit"]))
        )
        for f in json.loads(Path(fx_file).read_text(encoding="utf-8"))
    }
    return RateContext(directory=RateDirectory(rates), fx_by_currency=fx)


# --------------------------------------------------------------------------- #
# Cosmos-shaped key/value store, for SharePointSyncState on a laptop
# --------------------------------------------------------------------------- #

class SqliteKvContainer:
    """Just enough of the Cosmos container API for `SharePointSyncState`:
    `read_item(id, partition_key)` and `upsert_item(dict)`. Lets the sync
    logic be exercised end to end with no Cosmos account."""

    def __init__(self, db_path: Path):
        self._path = Path(db_path)
        with sqlite3.connect(self._path) as conn:
            conn.execute("CREATE TABLE IF NOT EXISTS kv (pk TEXT, id TEXT, body TEXT, PRIMARY KEY (pk, id))")

    def read_item(self, item: str, partition_key: str) -> dict:
        with sqlite3.connect(self._path) as conn:
            row = conn.execute("SELECT body FROM kv WHERE pk=? AND id=?", (partition_key, item)).fetchone()
        if not row:
            raise KeyError(item)
        return json.loads(row[0])

    def upsert_item(self, body: dict) -> None:
        pk = body.get("identifier", "")
        with sqlite3.connect(self._path) as conn:
            conn.execute("INSERT OR REPLACE INTO kv (pk, id, body) VALUES (?,?,?)",
                         (pk, body["id"], json.dumps(body)))
            conn.commit()
