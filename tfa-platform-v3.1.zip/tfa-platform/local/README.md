# Running TFA locally, with no Azure at all

This folder is the **no-Azure** path: SQLite, a folder for blobs, PyMuPDF for
layout, and rules instead of a model. It exists for working on the pipeline
on a plane, on a laptop that is off the VPN, or before your Entra group
membership has come through.

**If you are in the Entra group and on the VPN, you do not need this folder.**
The production composition root runs on a laptop as-is:

```bash
az login
python scripts/preflight.py        # is everything reachable and authorised?
python start.py --azure            # the web app on the real resources
```

That path uses the real adapters, the real model, real Document Intelligence
OCR, and your own identity. It is strictly better than anything below, and
what it writes is what the Function App writes. Use `local/` only when you
cannot get there.

```bash
python3 -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate
pip install -r requirements-dev.txt

PYTHONPATH=src:. pytest tests -q   # all pass
python local/run_local.py          # process everything in local/inbox
python local/run_local.py --show   # print what is stored
python local/run_local.py path/to/folio.pdf
```

Expected output on the bundled samples:

```
Libertador Buenos Aires   Argentina  158.80 vs 140.00 USD    56.40  overcharge
Estelar Bogota            Colombia   124.80 vs 115.20 USD    44.40  overcharge
Hilton Cartagena          Colombia   146.40 vs 146.40 USD     0.00  within agreement
Camino Real Villahermosa  Mexico     147.95 vs 134.75 USD    39.60  overcharge
WINGS TRAVEL MANAGEMENT   Ecuador         —          —        0.00  air invoice, no nights
```

Running it twice does not change those numbers.

## What is real and what is substituted

`FolioPipeline`, the extractor loop, `validate_extraction`, `RateDirectory`,
`build_records` and `FolioRecord` are your code, running unmodified. Only the
five edges are local:

| Port | Production | Here |
|---|---|---|
| `BlobStore` | Blob Storage | `local/blob/` folder |
| Layout | Document Intelligence | PyMuPDF text layer |
| `StructuredLLM` | Azure OpenAI | rules in `local/adapters.py` |
| write store | Azure SQL | SQLite |
| `StatusStore` | Cosmos | SQLite |

`local/run_local.py` is a parallel composition root. It does not touch
`tfa_core.container`, so nothing here affects the deployed wiring.

## Rates

`local/negotiated_rates.local.json` is used when present, otherwise
`seed/negotiated_rates.json`. **Both are invented.** The seed file holds two
properties that match none of the samples, and the local file exists only so
the variance column is non-zero. Replace it with contracted rates before any
number here means anything.

FX comes from `seed/fx.json` and is equally illustrative.

## Known limits

- **No OCR.** PyMuPDF reads the embedded text layer. Born-digital e-invoices
  read perfectly; a scanned or photographed folio returns little or nothing.
  That gap is what Document Intelligence exists to fill, and it is the main
  reason local results will not match cloud results on real documents.
- **The local parser knows four layouts** — Colombian DIAN, Argentine Factura
  B, Mexican CFDI, Ecuadorian air invoice. Anything else produces a thin
  extraction that the validators route to review, which is the right outcome
  for a format nobody has taught it.
- **The cross-foot validator is strict and will bite.** Four of the six
  samples were rejected three times each on the first attempt because the
  parser omitted additive IVA; the lines under-summed against the printed
  total and `validate_extraction` refused them. That is the validator working.
  Expect it on real documents too.
- **Argentina is the tax exception.** Factura B prices include IVA, so it goes
  in `informational_tax_amount`, never as an ancillary charge. Recording it as
  a charge counts the tax twice. Colombia, Mexico and Ecuador add it on top,
  so there it *is* a line.

## Adding a format

1. Run it, see what comes back thin.
2. Add a marker to `COUNTRY_MARKERS` and a line rule in
   `LocalStructuredLLM._charges`.
3. Better: label it into `evals/golden/` and run `python -m evals.run_eval`.
   The eval harness is the thing that turns this from a demo into a measured
   result, and it currently has one example to score.
