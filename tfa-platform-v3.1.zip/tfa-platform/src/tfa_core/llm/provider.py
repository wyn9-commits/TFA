"""tfa_core.llm.provider — model-agnostic structured extraction.

Two interchangeable providers behind one interface so the platform can move
between GPT-5.x and Claude (Sonnet 5 / Opus 5) on Microsoft Foundry without
touching pipeline code. Both are authenticated with Entra ID tokens from the
workload's Managed Identity — no API keys.

Accuracy features:
- Azure OpenAI path uses native structured outputs (json_schema, strict=True)
  so the response is guaranteed schema-shaped before we even validate it.
- Anthropic path uses forced tool_choice with the schema as the tool's
  input_schema — the Messages-API equivalent of strict structured output.
- Both paths run at deterministic settings appropriate to the model family.
"""
from __future__ import annotations

import json
import logging
from abc import ABC, abstractmethod
from typing import Any, Optional

import httpx

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from azure.core.credentials import TokenCredential

logger = logging.getLogger(__name__)

_COGNITIVE_SCOPE = "https://cognitiveservices.azure.com/.default"


class StructuredLLM(ABC):
    """Send (system, user-parts) and get back a dict guaranteed to parse as JSON."""

    @abstractmethod
    def extract(
        self,
        system_prompt: str,
        user_parts: list[dict[str, Any]],
        json_schema: dict[str, Any],
        schema_name: str,
        max_output_tokens: int,
    ) -> dict[str, Any]:
        ...


def _bearer(credential: "TokenCredential") -> dict[str, str]:
    token = credential.get_token(_COGNITIVE_SCOPE)
    return {"Authorization": f"Bearer {token.token}"}


# --------------------------------------------------------------------------- #
# Strict structured-output schema
# --------------------------------------------------------------------------- #

# Keywords Azure OpenAI strict mode does not accept (its docs list format,
# pattern and the length/size bounds as unsupported). Pydantic re-checks all
# of them after the call, so nothing is lost.
_STRIP = {"default", "title", "minimum", "maximum", "exclusiveMinimum", "exclusiveMaximum",
          "minLength", "maxLength", "pattern", "format", "minItems", "maxItems",
          "multipleOf", "uniqueItems", "examples"}


def to_strict_schema(schema: dict[str, Any]) -> dict[str, Any]:
    """Make a Pydantic JSON schema acceptable to OpenAI strict structured outputs.

    Strict mode rejects a schema unless every object lists ALL its properties
    as required, sets additionalProperties false, and avoids keywords such as
    `default`. Pydantic emits optional fields as not-required with a default,
    and enums as `$ref` with a sibling description — so the schema as
    generated would be refused with a 400 on the first real call. This
    rewrites it: `$ref`s are inlined, every property becomes required
    (optional ones are already nullable via anyOf-null), constraints are
    dropped (Pydantic still enforces them after the call, and a violation
    goes back to the model through the repair loop), and money fields typed
    number-or-string are narrowed to number so "1.234,56" cannot come back
    as a string.
    """
    defs = schema.get("$defs", {})

    def walk(node):
        if isinstance(node, list):
            return [walk(n) for n in node]
        if not isinstance(node, dict):
            return node
        if "$ref" in node:
            target = defs[node["$ref"].split("/")[-1]]
            merged = {**target, **{k: v for k, v in node.items() if k != "$ref"}}
            return walk(merged)
        out = {}
        for k, v in node.items():
            if k == "properties" and isinstance(v, dict):
                # Field names, not keywords: a field called "format" or
                # "title" must survive.
                out[k] = {name: walk(sub) for name, sub in v.items()}
            elif k not in _STRIP and k != "$defs":
                out[k] = walk(v)
        if "anyOf" in out:
            types = [o.get("type") for o in out["anyOf"] if isinstance(o, dict)]
            if "number" in types and "string" in types:
                out["anyOf"] = [o for o in out["anyOf"] if o.get("type") != "string"]
            if len(out["anyOf"]) == 1:
                only = out.pop("anyOf")[0]
                out = {**only, **out}
        if out.get("type") == "object" and "properties" in out:
            out["required"] = list(out["properties"].keys())
            out["additionalProperties"] = False
        return out

    return walk(schema)


def _uses_completion_tokens(deployment: str) -> bool:
    """Reasoning models (o-series, gpt-5.x) take max_completion_tokens and no
    temperature; gpt-4o-class models take max_tokens and temperature."""
    d = deployment.lower()
    return d.startswith(("o1", "o3", "o4", "gpt-5"))


class AzureOpenAIStructuredLLM(StructuredLLM):
    """Azure OpenAI (gpt-4o today, gpt-5.x when deployed) via chat completions
    with strict json_schema structured outputs."""

    def __init__(self, endpoint: str, deployment: str, api_version: str,
                 credential: "TokenCredential", timeout_s: float = 300.0,
                 api_key: Optional[str] = None):
        self._url = (
            f"{endpoint.rstrip('/')}/openai/deployments/{deployment}"
            f"/chat/completions?api-version={api_version}"
        )
        self._deployment = deployment
        self._credential = credential
        self._api_key = api_key
        self._timeout = timeout_s

    def _headers(self) -> dict[str, str]:
        if self._api_key:
            return {"api-key": self._api_key}
        return _bearer(self._credential)

    def extract(self, system_prompt, user_parts, json_schema, schema_name,
                max_output_tokens) -> dict[str, Any]:
        body: dict[str, Any] = {
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_parts},
            ],
            "response_format": {
                "type": "json_schema",
                "json_schema": {"name": schema_name, "strict": True,
                                "schema": to_strict_schema(json_schema)},
            },
        }
        if _uses_completion_tokens(self._deployment):
            body["max_completion_tokens"] = max_output_tokens
        else:
            body["max_tokens"] = min(max_output_tokens, 16384)   # gpt-4o output ceiling
            body["temperature"] = 0
        with httpx.Client(timeout=self._timeout) as client:
            resp = client.post(self._url, headers=self._headers(), json=body)
        if resp.status_code >= 400:
            # Surface Azure's own message: "DeploymentNotFound", content
            # filter, schema rejection — the repair loop and the status
            # detail both need the reason, not just the code.
            raise RuntimeError(f"Azure OpenAI {resp.status_code}: {resp.text[:500]}")
        data = resp.json()
        choice = data["choices"][0]
        if choice.get("finish_reason") == "length":
            raise RuntimeError("model output was cut off at the token limit")
        content = choice["message"].get("content")
        if not content:
            refusal = choice["message"].get("refusal") or choice.get("finish_reason")
            raise RuntimeError(f"model returned no content ({refusal})")
        return json.loads(content)


class AnthropicFoundryStructuredLLM(StructuredLLM):
    """Claude on Foundry via the Anthropic Messages API with forced tool use.

    Foundry's Azure-hosted Claude deployments expose /anthropic/v1/messages.
    We register a single tool whose input_schema is our extraction schema and
    force the model to call it — the returned tool_use input block is the
    structured result.
    """

    ANTHROPIC_VERSION = "2023-06-01"

    def __init__(self, endpoint: str, deployment: str, credential: "TokenCredential",
                 timeout_s: float = 300.0):
        self._url = f"{endpoint.rstrip('/')}/anthropic/v1/messages"
        self._model = deployment
        self._credential = credential
        self._timeout = timeout_s

    @staticmethod
    def _to_anthropic_parts(user_parts: list[dict[str, Any]]) -> list[dict[str, Any]]:
        out: list[dict[str, Any]] = []
        for part in user_parts:
            if part.get("type") == "text":
                out.append({"type": "text", "text": part["text"]})
            elif part.get("type") == "image_url":
                url = part["image_url"]["url"]
                # data:image/png;base64,<payload>
                header, payload = url.split(",", 1)
                media_type = header.split(";")[0].removeprefix("data:")
                out.append({
                    "type": "image",
                    "source": {"type": "base64", "media_type": media_type, "data": payload},
                })
        return out

    def extract(self, system_prompt, user_parts, json_schema, schema_name,
                max_output_tokens) -> dict[str, Any]:
        body = {
            "model": self._model,
            "max_tokens": max_output_tokens,
            "system": system_prompt,
            "messages": [{"role": "user", "content": self._to_anthropic_parts(user_parts)}],
            "tools": [{
                "name": schema_name,
                "description": "Record the structured extraction result.",
                "input_schema": json_schema,
            }],
            "tool_choice": {"type": "tool", "name": schema_name},
        }
        headers = _bearer(self._credential) | {"anthropic-version": self.ANTHROPIC_VERSION}
        with httpx.Client(timeout=self._timeout) as client:
            resp = client.post(self._url, headers=headers, json=body)
        resp.raise_for_status()
        data = resp.json()
        for block in data.get("content", []):
            if block.get("type") == "tool_use" and block.get("name") == schema_name:
                return block["input"]
        raise ValueError("Model response contained no tool_use block with the extraction schema.")


def build_llm(provider: str, endpoint: str, deployment: str, api_version: str,
              credential: "TokenCredential", api_key: Optional[str] = None) -> StructuredLLM:
    if provider == "azure_openai":
        return AzureOpenAIStructuredLLM(endpoint, deployment, api_version, credential,
                                        api_key=api_key)
    if provider == "anthropic_foundry":
        return AnthropicFoundryStructuredLLM(endpoint, deployment, credential)
    raise ValueError(f"Unknown llm_provider: {provider}")
