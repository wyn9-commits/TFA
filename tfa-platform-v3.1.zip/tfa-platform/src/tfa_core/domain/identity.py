"""How a document is identified. A business rule, not a storage detail.

"The same bytes for the same file in the same batch are the same document."
That invariant governs idempotency and, through it, whether reconciliation
totals are right.

The previous implementation keyed identity on the blob's content_md5 — which
the SDK only populates when the uploader supplies it, and ours did not — and
fell back to the ETag, which changes on every write including an overwrite
with byte-identical content. Re-processing therefore inserted a second set of
rows instead of replacing the first. Three re-runs: three rows, three times
the reported overcharge, against a hotel, in a recovery claim.

Identity now comes from the bytes themselves. Nothing else.
"""
from __future__ import annotations

import hashlib


def content_hash(content: bytes) -> str:
    """SHA-256 of the document bytes. Never storage metadata."""
    return hashlib.sha256(content).hexdigest()


def compute_document_id(identifier: str, file_name: str, content_sha256: str) -> str:
    """THE single definition of a document's identity: 32 hex chars."""
    return hashlib.sha256(
        f"{identifier}/{file_name}/{content_sha256}".encode()
    ).hexdigest()[:32]
