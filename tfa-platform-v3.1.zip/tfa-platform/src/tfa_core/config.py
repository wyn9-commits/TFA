"""tfa_core.config — typed settings, fail-fast at startup.

Fitted to the infrastructure that actually exists (infra-hds-ds-travel-folio-
analysis, Terraform): App Service + ACR, Blob (`travel-folios`, shared key
off), Azure SQL, Azure OpenAI (`travel-res`, gpt-4o), Key Vault, App Insights.
No Document Intelligence, no storage queue, and Cosmos only if enabled.

Every setting accepts its `TFA_` name AND the legacy app's name, because the
Terraform configures the App Service with the legacy names (ALLOWED_EMAILS,
SQL_SERVER, AZURE_OPENAI_STARTBURST_*, ...). Nothing has to be renamed in the
infra repo for this app to start.

Authentication prefers the managed identity (Entra tokens for Blob, OpenAI
and SQL). Where the infra provides only a username/password or a key — the
SQL credentials in Key Vault, the OpenAI key — those are accepted too, read
from app settings that should be Key Vault references.
"""
from __future__ import annotations

from functools import lru_cache
from typing import Literal, Optional

from azure.identity import DefaultAzureCredential
from pydantic import AliasChoices, Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="TFA_", case_sensitive=False)

    environment: Literal["local", "dev", "test", "prod"] = Field(
        "dev", validation_alias=AliasChoices("TFA_ENVIRONMENT", "FLASK_ENV_NAME", "ENVIRONMENT"))

    # --- Storage -----------------------------------------------------------
    storage_account_url: str = Field(
        ..., description="https://<acct>.blob.core.windows.net",
        validation_alias=AliasChoices("TFA_STORAGE_ACCOUNT_URL", "AZURE_STORAGE_ACCOUNT_URL"))
    raw_container: str = Field("travel-folios", validation_alias=AliasChoices("TFA_RAW_CONTAINER", "AZURE_UPLOAD_CONTAINER_NAME"))
    # Queue: the Terraform has enable_queue = false. Only the optional Function
    # App path uses a queue; the web app's in-process processor does not.
    queue_account_url: Optional[str] = Field(None, validation_alias=AliasChoices("TFA_QUEUE_ACCOUNT_URL"))
    work_queue: str = "folio-extract"
    poison_queue: str = "folio-extract-poison"

    # --- Reading the document ----------------------------------------------
    # The Terraform template has no Document Intelligence (no FormRecognizer
    # kind). Without it, pages are read from the PDF's own text layer plus
    # page images sent to the multimodal model. If a DI endpoint is ever
    # configured, it is used instead and adds OCR confidence.
    docintel_endpoint: Optional[str] = Field(None, validation_alias=AliasChoices("TFA_DOCINTEL_ENDPOINT"))
    docintel_model: str = "prebuilt-layout"
    layout_engine: Literal["auto", "docintel", "pdf_vision"] = "auto"

    # --- LLM (Azure OpenAI: travel-res, gpt-4o) -----------------------------
    llm_provider: Literal["azure_openai", "anthropic_foundry"] = "azure_openai"
    llm_endpoint: str = Field(..., validation_alias=AliasChoices("TFA_LLM_ENDPOINT", "AZURE_OPENAI_STARTBURST_END_POINT", "AZURE_OPENAI_ENDPOINT"))
    llm_deployment: str = Field("gpt-4o", validation_alias=AliasChoices("TFA_LLM_DEPLOYMENT", "AZURE_OPENAI_STARTBURST_MODEL_NAME", "AZURE_OPENAI_DEPLOYMENT"))
    llm_api_version: str = Field("2024-10-21", validation_alias=AliasChoices("TFA_LLM_API_VERSION", "AZURE_OPENAI_STARTBURST_API_VERSION"))
    # Optional. Empty = Entra token via the managed identity (it holds
    # Cognitive Services OpenAI User). Set only if the infra supplies a key.
    llm_api_key: Optional[str] = Field(None, validation_alias=AliasChoices("TFA_LLM_API_KEY", "AZURE_OPENAI_STARTBURST_API_KEY"))
    llm_max_output_tokens: int = 16000
    llm_extraction_max_attempts: int = 3
    llm_translation_deployment: Optional[str] = None
    extraction_engine: Literal["loop", "graph"] = "loop"

    # Cross-model verification. When set, a second model re-reads any document
    # the first model was not sure about; the two must agree on the money
    # fields or the document goes to review. Needs a second deployment, which
    # the current tfvars does not define — see infra/README.md.
    llm_verify_deployment: Optional[str] = None
    llm_verify_provider: Optional[Literal["azure_openai", "anthropic_foundry"]] = None
    llm_verify_endpoint: Optional[str] = None
    llm_verify_always: bool = False
    llm_verify_tolerance: float = 0.01

    # --- SQL ---------------------------------------------------------------
    sql_server: str = Field(..., validation_alias=AliasChoices("TFA_SQL_SERVER", "SQL_SERVER"))
    sql_database: str = Field(..., validation_alias=AliasChoices("TFA_SQL_DATABASE", "SQL_DATABASE"))
    sql_table: str = "tfa_folio_lines"
    # The Terraform keeps mssql_server_username / mssql_server_password in Key
    # Vault. If these are set (as Key Vault references), SQL uses them; if
    # not, it uses an Entra token from the managed identity.
    sql_username: Optional[str] = Field(None, validation_alias=AliasChoices("TFA_SQL_USERNAME", "SQL_USERNAME"))
    sql_password: Optional[str] = Field(None, validation_alias=AliasChoices("TFA_SQL_PASSWORD", "SQL_PASSWORD"))

    # --- Processing status --------------------------------------------------
    # auto: Cosmos if an endpoint is set, otherwise two small tables in the
    # existing SQL database. The dev tfvars does not enable Cosmos.
    status_store: Literal["auto", "cosmos", "sql"] = "auto"
    cosmos_endpoint: Optional[str] = Field(None, validation_alias=AliasChoices("TFA_COSMOS_ENDPOINT"))
    cosmos_database: str = "tfa"
    cosmos_status_container: str = "processing_status"

    # --- SharePoint source (Microsoft Graph) --------------------------------
    sharepoint_enabled: bool = True
    sharepoint_site_id: Optional[str] = None
    sharepoint_drive_id: Optional[str] = None
    sharepoint_sync_cron: str = "0 */5 * * * *"

    # --- Behaviour ---------------------------------------------------------
    render_dpi: int = 200                          # images go to gpt-4o; 200 dpi reads 8pt print
    max_pages_per_doc: int = 25
    max_page_images: int = 8                       # images per document sent to the model
    user_assigned_client_id: Optional[str] = Field(
        None, validation_alias=AliasChoices("TFA_USER_ASSIGNED_CLIENT_ID", "USER_ASSIGNED_CLIENT_ID", "AZURE_CLIENT_ID"))

    @property
    def use_cosmos(self) -> bool:
        return self.status_store == "cosmos" or (self.status_store == "auto" and bool(self.cosmos_endpoint))

    @property
    def use_docintel(self) -> bool:
        return self.layout_engine == "docintel" or (self.layout_engine == "auto" and bool(self.docintel_endpoint))


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    return Settings()  # type: ignore[call-arg]  (env-driven)


@lru_cache(maxsize=1)
def get_credential() -> DefaultAzureCredential:
    s = get_settings()
    return DefaultAzureCredential(managed_identity_client_id=s.user_assigned_client_id)
