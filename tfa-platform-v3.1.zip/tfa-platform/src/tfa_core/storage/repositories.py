"""tfa_core.storage.repositories — persistence.

SQL: pyodbc + ODBC Driver 18. Entra token from the managed identity by
default; a username/password if the infra supplies one (the Terraform keeps
mssql_server_username / mssql_server_password in Key Vault).

Processing status: Cosmos if it exists, otherwise two small tables in the
same SQL database (tfa_processing_status, tfa_kv). Either replaces the
POC's track_folios_file.txt, which had a read-modify-write race between the
web workers.
"""
from __future__ import annotations

import logging
import struct
from datetime import datetime, timezone
from typing import Any, Optional

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    import pyodbc
    from azure.core.credentials import TokenCredential

from tfa_core.schemas import SQL_COLUMNS, FolioRecord
from tfa_core.extraction.reconciliation import derive_year_and_quarter

logger = logging.getLogger(__name__)

_SQL_SCOPE = "https://database.windows.net/.default"
_SQL_COPT_SS_ACCESS_TOKEN = 1256  # msodbcsql.h


# --------------------------------------------------------------------------- #
# SQL
# --------------------------------------------------------------------------- #

def sql_connector(server: str, database: str, credential: "TokenCredential" = None,
                  username: Optional[str] = None, password: Optional[str] = None):
    """Return a zero-argument connect() for SQL Server.

    Username/password when both are given; otherwise an Entra access token
    for `credential` (the managed identity, or `az login` on a laptop)."""
    base = (
        "Driver={ODBC Driver 18 for SQL Server};"
        f"Server=tcp:{server},1433;Database={database};"
        "Encrypt=yes;TrustServerCertificate=no;Connection Timeout=30;"
    )

    if username and password:
        conn_str = base + f"Uid={username};Pwd={{{password.replace('}', '}}')}}};"

        def connect():
            import pyodbc
            return pyodbc.connect(conn_str)
        connect.auth = "sql-login"          # type: ignore[attr-defined]
        return connect

    def connect():
        import pyodbc
        token = credential.get_token(_SQL_SCOPE).token.encode("utf-16-le")
        packed = struct.pack(f"<I{len(token)}s", len(token), token)
        return pyodbc.connect(base, attrs_before={_SQL_COPT_SS_ACCESS_TOKEN: packed})
    connect.auth = "entra-token"            # type: ignore[attr-defined]
    return connect


class FolioSqlRepository:
    def __init__(self, server: str, database: str, table: str,
                 credential: "TokenCredential" = None, *,
                 username: Optional[str] = None, password: Optional[str] = None,
                 connect=None):
        self._connect_fn = connect or sql_connector(server, database, credential, username, password)
        self._table = table

    def _connect(self) -> "pyodbc.Connection":
        return self._connect_fn()

    def upsert_document(self, document_id: str, records: list[FolioRecord]) -> int:
        """Idempotent write: delete-then-insert inside one transaction keyed by
        document_id, so queue redeliveries never duplicate rows."""
        cols = SQL_COLUMNS + ["document_id"]
        placeholders = ", ".join("?" for _ in cols)
        collist = ", ".join(cols)
        insert = f"INSERT INTO {self._table} ({collist}) VALUES ({placeholders})"
        with self._connect() as conn:
            cur = conn.cursor()
            cur.execute(f"DELETE FROM {self._table} WHERE document_id = ?", document_id)
            for rec in records:
                cur.execute(insert, self._row(rec) + [document_id])
            conn.commit()
            return len(records)

    @staticmethod
    def _row(rec: FolioRecord) -> list[Any]:
        d = rec.model_dump(mode="json")
        year, quarter = derive_year_and_quarter(rec.year_month)
        d["year"], d["year_quarter"] = year, quarter
        return [d.get(col) for col in SQL_COLUMNS]

    def ddl(self) -> str:
        """CREATE TABLE statement generated from the column registry —
        schema drift between code and DB becomes impossible to miss."""
        typemap = {
            "original_per_day_price": "DECIMAL(18,2)", "negotiated_rate": "DECIMAL(18,2)",
            "currency_multiplier_rate": "DECIMAL(18,6)", "usd_per_day_price": "DECIMAL(18,2)",
            "usd_late_early_unit_price": "DECIMAL(18,2)",
            "usd_total_overcharged_amount": "DECIMAL(18,2)",
            "usd_total_undercharged_amount": "DECIMAL(18,2)",
            "usd_total_amount_differ": "DECIMAL(18,2)",
            "number_of_days": "INT", "number_of_nights_overcharged": "INT",
            "number_of_nights_undercharged": "INT",
            "folio_date": "DATE", "checkin": "DATE", "checkout": "DATE",
            "extraction_warnings": "NVARCHAR(2000)",
        }
        cols = ",\n    ".join(
            f"[{c}] {typemap.get(c, 'NVARCHAR(400)')} NULL" for c in SQL_COLUMNS
        )
        return (
            f"CREATE TABLE {self._table} (\n"
            "    [id] BIGINT IDENTITY(1,1) PRIMARY KEY,\n"
            "    [document_id] CHAR(32) NOT NULL,\n"
            f"    {cols},\n"
            "    [ingested_at_utc] DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME()\n"
            ");\n"
            f"CREATE INDEX IX_{self._table}_document_id ON {self._table}(document_id);\n"
            f"CREATE INDEX IX_{self._table}_identifier ON {self._table}(identifier_name);\n"
            f"CREATE INDEX IX_{self._table}_year_month ON {self._table}(year_month);"
        )


# --------------------------------------------------------------------------- #
# Cosmos processing status (replaces the tracking .txt file)
# --------------------------------------------------------------------------- #

class ProcessingStatusRepository:
    """One item per document; partition key = /identifier."""

    def __init__(self, endpoint: str, database: str, container: str,
                 credential: "TokenCredential"):
        from azure.cosmos import CosmosClient, PartitionKey
        client = CosmosClient(endpoint, credential=credential)
        db = client.create_database_if_not_exists(database)
        self._container = db.create_container_if_not_exists(
            id=container, partition_key=PartitionKey(path="/identifier"),
        )

    def mark(self, *, document_id: str, identifier: str, file_name: str,
             status: str, detail: Optional[str] = None,
             attempts: Optional[int] = None) -> None:
        item = {
            "id": document_id,
            "identifier": identifier,
            "file_name": file_name,
            "status": status,           # queued | processing | succeeded | needs_review | failed
            "detail": detail,
            "attempts": attempts,
            "updated_at_utc": datetime.now(timezone.utc).isoformat(),
        }
        self._container.upsert_item(item)

    def pending_all(self) -> list[dict]:
        """Cross-partition: the web app's processor drains every batch."""
        query = "SELECT * FROM c WHERE c.status IN ('queued','processing')"
        return list(self._container.query_items(query, enable_cross_partition_query=True))

    def recent(self, limit: int = 50) -> list[dict]:
        query = f"SELECT TOP {int(limit)} * FROM c WHERE IS_DEFINED(c.status) ORDER BY c.updated_at_utc DESC"
        return list(self._container.query_items(query, enable_cross_partition_query=True))

    @property
    def container(self):
        """The raw container, for SharePointSyncState which shares it."""
        return self._container

    def pending_for_identifier(self, identifier: str) -> list[dict]:
        query = "SELECT * FROM c WHERE c.identifier = @id AND c.status IN ('queued','processing')"
        return list(self._container.query_items(
            query, parameters=[{"name": "@id", "value": identifier}],
            partition_key=identifier,
        ))


# --------------------------------------------------------------------------- #
# Blob
# --------------------------------------------------------------------------- #

class BlobRepository:
    def __init__(self, account_url: str, credential: "TokenCredential"):
        from azure.storage.blob import BlobServiceClient
        self._svc = BlobServiceClient(account_url=account_url, credential=credential)

    def download(self, container: str, blob_path: str) -> bytes:
        """Returns the content. Nothing else.

        It used to return (content, md5-or-etag) "for idempotency keys", and
        the ETag branch was the only branch ever taken. Identity is computed
        from the bytes by `tfa_core.domain.identity`; storage metadata is not
        offered to callers so it cannot become identity again by accident."""
        bc = self._svc.get_blob_client(container, blob_path)
        return bc.download_blob(max_concurrency=4).readall()

    def version(self, container: str, blob_path: str) -> str:
        """A change hint for sync logic. Deliberately not usable as identity:
        it reads properties only and never the payload."""
        return self._svc.get_blob_client(container, blob_path).get_blob_properties().etag.strip('"')

    def upload(self, container: str, blob_path: str, data: bytes,
               overwrite: bool = False) -> None:
        self._svc.get_blob_client(container, blob_path).upload_blob(
            data, overwrite=overwrite,
        )


# --------------------------------------------------------------------------- #
# Processing status in SQL (when there is no Cosmos)
# --------------------------------------------------------------------------- #

class SqlStatusRepository:
    """Same interface as ProcessingStatusRepository, two tables in the
    existing database. Portable SQL (UPDATE, then INSERT if nothing matched)
    so the same class runs on SQL Server and on SQLite in tests."""

    STATUS = "tfa_processing_status"
    KV = "tfa_kv"

    def __init__(self, connect, *, dialect: str = "mssql"):
        self._connect = connect
        self._dialect = dialect
        self._ready = False
        self._ensure()

    @classmethod
    def ddl_statements(cls, dialect: str = "mssql") -> list[tuple[str, str]]:
        text = "NVARCHAR(400)" if dialect == "mssql" else "TEXT"
        big = "NVARCHAR(MAX)" if dialect == "mssql" else "TEXT"
        return [
            (cls.STATUS, f"CREATE TABLE {cls.STATUS} (document_id VARCHAR(64) NOT NULL PRIMARY KEY, "
                          f"identifier {text}, file_name {text}, status VARCHAR(32), detail {big}, "
                          f"attempts INT, updated_at_utc VARCHAR(40))"),
            (cls.KV, f"CREATE TABLE {cls.KV} (pk VARCHAR(100) NOT NULL, id VARCHAR(200) NOT NULL, "
                      f"body {big}, PRIMARY KEY (pk, id))"),
        ]

    def _ensure(self) -> None:
        stmts = self.ddl_statements(self._dialect)
        try:
            with self._connect() as conn:
                cur = conn.cursor()
                for table, ddl in stmts:
                    if self._dialect == "mssql":
                        cur.execute(f"IF OBJECT_ID('{table}', 'U') IS NULL {ddl}")
                    else:
                        cur.execute(ddl.replace("CREATE TABLE", "CREATE TABLE IF NOT EXISTS", 1))
                conn.commit()
            self._ready = True
        except Exception as exc:
            # SQL not reachable yet (container boot) or no DDL rights. Retried
            # on the next status write; if the login may never run DDL, the
            # tables come from scripts/generate_sql_ddl.py.
            logger.warning("Could not create status tables yet (%s); will retry. "
                           "If this persists, run scripts/generate_sql_ddl.py.", exc)

    def mark(self, *, document_id: str, identifier: str, file_name: str,
             status: str, detail: Optional[str] = None,
             attempts: Optional[int] = None) -> None:
        if not self._ready:
            self._ensure()
        now = datetime.now(timezone.utc).isoformat()
        with self._connect() as conn:
            cur = conn.cursor()
            cur.execute(f"UPDATE {self.STATUS} SET identifier=?, file_name=?, status=?, detail=?, "
                        f"attempts=?, updated_at_utc=? WHERE document_id=?",
                        (identifier, file_name, status, detail, attempts, now, document_id))
            if cur.rowcount == 0:
                cur.execute(f"INSERT INTO {self.STATUS} (document_id, identifier, file_name, status, "
                            f"detail, attempts, updated_at_utc) VALUES (?,?,?,?,?,?,?)",
                            (document_id, identifier, file_name, status, detail, attempts, now))
            conn.commit()

    def _rows(self, sql: str, params=()) -> list[dict]:
        if not self._ready:
            self._ensure()
        with self._connect() as conn:
            cur = conn.cursor()
            cur.execute(sql, params)
            names = [d[0] for d in cur.description]
            return [dict(zip(names, r)) for r in cur.fetchall()]

    def get(self, document_id: str) -> Optional[dict]:
        r = self._rows(f"SELECT * FROM {self.STATUS} WHERE document_id=?", (document_id,))
        return r[0] if r else None

    def pending_all(self) -> list[dict]:
        return self._rows(f"SELECT * FROM {self.STATUS} WHERE status IN ('queued','processing') "
                          f"ORDER BY updated_at_utc")

    def recent(self, limit: int = 50) -> list[dict]:
        top = f"TOP {int(limit)} " if self._dialect == "mssql" else ""
        tail = "" if self._dialect == "mssql" else f" LIMIT {int(limit)}"
        return self._rows(f"SELECT {top}* FROM {self.STATUS} ORDER BY updated_at_utc DESC{tail}")

    @property
    def container(self) -> "SqlKvContainer":
        """Cosmos-shaped key/value store for SharePointSyncState."""
        return SqlKvContainer(self._connect, self.KV)


class SqlKvContainer:
    """read_item / upsert_item over tfa_kv — what SharePointSyncState needs."""

    def __init__(self, connect, table: str):
        self._connect, self._table = connect, table

    def read_item(self, item: str, partition_key: str) -> dict:
        import json
        with self._connect() as conn:
            cur = conn.cursor()
            cur.execute(f"SELECT body FROM {self._table} WHERE pk=? AND id=?", (partition_key, item))
            row = cur.fetchone()
        if not row:
            raise KeyError(item)
        return json.loads(row[0])

    def upsert_item(self, body: dict) -> None:
        import json
        pk, key, payload = body.get("identifier", ""), body["id"], json.dumps(body)
        with self._connect() as conn:
            cur = conn.cursor()
            cur.execute(f"UPDATE {self._table} SET body=? WHERE pk=? AND id=?", (payload, pk, key))
            if cur.rowcount == 0:
                cur.execute(f"INSERT INTO {self._table} (pk, id, body) VALUES (?,?,?)", (pk, key, payload))
            conn.commit()
