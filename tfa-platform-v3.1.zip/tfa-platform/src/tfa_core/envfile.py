"""Read a .env file without mangling secrets.

A value is taken literally when quoted. Unquoted, a comment starts only at a
'#' that follows whitespace, so a password like  p#ss  survives while
`gpt-4o   # deployment name` loses its comment. Blank values are skipped, so
an empty `SQL_PASSWORD=` means "not set", not "empty password".
"""
from __future__ import annotations

import os
import re
from pathlib import Path

_COMMENT = re.compile(r"\s+#.*$")


def parse_value(raw: str) -> str:
    v = raw.strip()
    if len(v) >= 2 and v[0] == v[-1] and v[0] in "\"'":
        return v[1:-1]
    return _COMMENT.sub("", v).strip()


def load_env_file(path: Path, *, override: bool = False) -> int:
    if not path.exists():
        return 0
    n = 0
    for line in path.read_text(encoding="utf-8-sig").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        if line.startswith("export "):
            line = line[7:]
        k, _, v = line.partition("=")
        k, v = k.strip(), parse_value(v)
        if not v:
            continue
        if override or k not in os.environ:
            os.environ[k] = v
            n += 1
    return n
