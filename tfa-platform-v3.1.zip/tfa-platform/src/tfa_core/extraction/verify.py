"""Cross-model verification of an extraction.

The validators catch an extraction that disagrees with itself: lines that do
not sum to the printed total, a checkout before a checkin. They cannot catch
an extraction that is wrong but consistent — a 1 read as a 7 in every place
it appears. A second model reading the same page can, if it is a different
model: two readers from different families rarely share a blind spot.

So: when the first model says it was unsure, or the validators warned, or the
page was a low-confidence scan, a second model reads the same layout cold —
no hint of the first answer — and the money fields are compared. Agreement
within tolerance is evidence. Disagreement routes the document to a person
with both readings attached, which is the honest outcome when two competent
readers see different numbers.

This is a gate, not a merge. The first model's extraction is what gets
persisted either way; the verifier only decides whether it needs eyes.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from decimal import Decimal
from typing import Any, Optional

from pydantic import ValidationError

from tfa_core.extraction.document_intelligence import DocumentLayout
from tfa_core.extraction.llm_extractor import SYSTEM_PROMPT, ExtractionOutcome
from tfa_core.schemas import FolioExtraction

log = logging.getLogger(__name__)

MONEY_FIELDS = ("total_amount", "informational_tax_amount", "total_amount_from_words")
UNCERTAIN_FIELDS = {"total_amount", "nightly_charges", "ancillary_charges", "currency",
                    "checkin_date", "checkout_date", "folio_date"}


@dataclass
class Verdict:
    agreed: bool
    needs_review: bool
    warnings: list[str] = field(default_factory=list)
    second: Optional[FolioExtraction] = None


def _lines_total(x: FolioExtraction) -> Decimal:
    return (sum((c.amount for c in x.nightly_charges), Decimal(0))
            + sum((c.amount for c in x.ancillary_charges), Decimal(0)))


def _differs(a: Optional[Decimal], b: Optional[Decimal], tol: float) -> bool:
    if a is None and b is None:
        return False
    if a is None or b is None:
        return True
    if a == 0 and b == 0:
        return False
    base = max(abs(a), abs(b))
    return abs(a - b) / base > Decimal(str(tol))


def should_verify(layout: DocumentLayout, outcome: ExtractionOutcome, *, always: bool) -> Optional[str]:
    """Return the reason to verify, or None."""
    if always:
        return "verification enabled for every document"
    x = outcome.extraction
    if any(f in UNCERTAIN_FIELDS for f in x.low_confidence_fields):
        return f"primary model flagged low confidence on {', '.join(sorted(set(x.low_confidence_fields) & UNCERTAIN_FIELDS))}"
    if outcome.attempts > 1:
        return f"primary model needed {outcome.attempts} attempts"
    if any("Legibility" in w or "sum" in w.lower() or "total" in w.lower() for w in outcome.warnings):
        return "validators warned about totals or legibility"
    if layout.ocr_confidence_floor < 0.85:
        return f"OCR confidence floor {layout.ocr_confidence_floor:.2f}"
    return None


class CrossModelVerifier:
    def __init__(self, llm, *, max_output_tokens: int = 16000, tolerance: float = 0.01,
                 always: bool = False):
        self._llm = llm
        self._max_tokens = max_output_tokens
        self._tol = tolerance
        self._always = always
        self._schema = FolioExtraction.model_json_schema()

    def verify(self, layout: DocumentLayout, filename: str,
               outcome: ExtractionOutcome) -> Optional[Verdict]:
        reason = should_verify(layout, outcome, always=self._always)
        if reason is None:
            return None

        parts: list[dict[str, Any]] = [{
            "type": "text",
            "text": (f"FILENAME: {filename}\nPAGES: {layout.page_count}\n"
                     f"DETECTED_LANGUAGES: {', '.join(layout.languages) or 'unknown'}\n\n"
                     f"OCR_MARKDOWN:\n{layout.markdown_text}"),
        }]
        for b64 in layout.page_images_b64:
            parts.append({"type": "image_url", "image_url": {"url": f"data:image/png;base64,{b64}"}})

        try:
            raw = self._llm.extract(system_prompt=SYSTEM_PROMPT, user_parts=parts,
                                    json_schema=self._schema, schema_name="folio_extraction",
                                    max_output_tokens=self._max_tokens)
            second = FolioExtraction.model_validate(raw)
        except (ValidationError, Exception) as exc:   # the verifier must never fail a document
            log.warning("%s: verifier could not produce a reading (%s); routing to review", filename, exc)
            return Verdict(agreed=False, needs_review=True,
                           warnings=[f"Verification attempted ({reason}) but the second model "
                                     f"returned no usable reading; please check by hand."])

        first = outcome.extraction
        diffs: list[str] = []
        for f in MONEY_FIELDS:
            a, b = getattr(first, f), getattr(second, f)
            if _differs(a, b, self._tol):
                diffs.append(f"{f}: {a} vs {b}")
        la, lb = _lines_total(first), _lines_total(second)
        if _differs(la, lb, self._tol):
            diffs.append(f"sum of charge lines: {la} vs {lb}")
        if (first.currency or "").upper() != (second.currency or "").upper():
            diffs.append(f"currency: {first.currency} vs {second.currency}")
        na, nb = sum(c.nights for c in first.nightly_charges), sum(c.nights for c in second.nightly_charges)
        if na != nb:
            diffs.append(f"nights: {na} vs {nb}")

        if diffs:
            return Verdict(agreed=False, needs_review=True, second=second,
                           warnings=[f"Verified because {reason}. Two models disagree — "
                                     + "; ".join(diffs) + ". Review before relying on these amounts."])
        return Verdict(agreed=True, needs_review=False, second=second,
                       warnings=[f"Verified because {reason}: second model agrees on all money fields."])
