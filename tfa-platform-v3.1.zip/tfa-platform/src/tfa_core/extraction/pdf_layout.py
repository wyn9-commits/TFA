"""Reading a document without Document Intelligence.

The infra template has no Document Intelligence account, so this is the
reading path in production. It gives the model two independent views of
every document:

  1. the PDF's own text layer, every page, in reading order. For the
     born-digital e-invoices that make up most of the library (DIAN, CFDI,
     AFIP, SRI) this is the exact text the issuer printed — better than OCR,
     because nothing was recognised, it was simply there.
  2. page images at 200 dpi, sent to the multimodal model (gpt-4o reads
     images), so tables, stamps, handwriting and scanned pages are seen.

The POC sent one 150-dpi image of page 1 and nothing else. This sends the
text of every page and images of up to `max_page_images` pages.

`ocr_confidence_floor` has no OCR behind it here, so it reports what is
known: the share of pages that carry a text layer. A fully scanned folio
reports 0.0, which tells the validators and the cross-model verifier that
the model was reading pixels, not text, and should be checked.
"""
from __future__ import annotations

import base64
import logging

from tfa_core.extraction.document_intelligence import DocumentLayout

logger = logging.getLogger(__name__)

_MIN_TEXT_CHARS_PER_PAGE = 40   # below this a page is treated as image-only


class PdfVisionLayout:
    def __init__(self, render_dpi: int = 200, max_pages: int = 25, max_images: int = 8):
        self._dpi = render_dpi
        self._max_pages = max_pages
        self._max_images = max_images

    def analyze_pdf(self, pdf_bytes: bytes, filename: str) -> DocumentLayout:
        import fitz  # PyMuPDF

        with fitz.open(stream=pdf_bytes, filetype="pdf") as doc:
            total = doc.page_count
            n = min(total, self._max_pages)
            texts, text_pages, image_pages = [], 0, []
            for i in range(n):
                page = doc[i]
                t = page.get_text("text") or ""
                if len(t.strip()) >= _MIN_TEXT_CHARS_PER_PAGE:
                    text_pages += 1
                else:
                    image_pages.append(i)
                texts.append(f"--- page {i + 1} ---\n{t.strip()}")

            # Images: every image-only page first (they have no text at all),
            # then the remaining pages in order, up to the cap.
            order = image_pages + [i for i in range(n) if i not in image_pages]
            images = []
            for i in order[: self._max_images]:
                pix = doc[i].get_pixmap(dpi=self._dpi)
                images.append(base64.b64encode(pix.tobytes("png")).decode("ascii"))

        if total > n:
            logger.warning("%s has %d pages; read the first %d.", filename, total, n)
        if n > self._max_images:
            logger.info("%s: %d pages, %d sent as images (text layer covers all).",
                        filename, n, self._max_images)

        floor = (text_pages / n) if n else 0.0
        return DocumentLayout(
            markdown_text="\n\n".join(texts),
            page_count=total,
            page_images_b64=images,
            languages=[],
            ocr_confidence_floor=round(floor, 2),
        )

    def analyze_image(self, image_bytes: bytes, filename: str, media_type: str) -> DocumentLayout:
        # A photo or scan: no text layer at all, the model reads the image.
        # Re-encoded as PNG because the request labels every image PNG.
        import fitz
        ext = "png" if "png" in media_type else "jpg"
        with fitz.open(stream=image_bytes, filetype=ext) as doc:
            png = doc[0].get_pixmap().tobytes("png")
        return DocumentLayout(
            markdown_text="(image document: no text layer; read from the image)",
            page_count=1,
            page_images_b64=[base64.b64encode(png).decode("ascii")],
            languages=[],
            ocr_confidence_floor=0.0,
        )
