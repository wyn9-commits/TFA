"""tfa_core.extraction.pipeline — end-to-end processing of one document.

blob event -> queue message -> THIS -> SQL row(s) + status item

Idempotent: document_id is derived from blob path + content hash, and the SQL
write is delete-then-insert on that key, so at-least-once queue delivery is
safe. Failures raise, letting the Functions host retry and eventually
dead-letter to the poison queue with the status item marked 'failed'.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Optional

from tfa_core.config import Settings, get_credential, get_settings
from tfa_core.domain.identity import compute_document_id, content_hash
from tfa_core.extraction.document_intelligence import LayoutExtractor
from tfa_core.extraction.llm_extractor import ExtractionFailed, LLMExtractor
from tfa_core.extraction.reconciliation import (
    FxRate, NegotiatedRate, RateDirectory, build_records,
)
from tfa_core.llm.provider import build_llm
from tfa_core.storage.repositories import (
    BlobRepository, FolioSqlRepository, ProcessingStatusRepository,
)

logger = logging.getLogger(__name__)

_IMAGE_SUFFIXES = (".png", ".jpg", ".jpeg")


@dataclass
class WorkItem:
    """Queue message payload."""
    container: str
    blob_path: str            # "<identifier>-<user>/<file>"
    identifier: str
    uploading_person_name: str
    file_name: str


@dataclass
class RateContext:
    """Injected per-run: negotiated rates + FX. Sourced from SQL/SAP feed."""
    directory: RateDirectory
    fx_by_currency: dict[str, FxRate]


class FolioPipeline:
    """Orchestrates one document through the domain rules.

    Collaborators arrive through the constructor. That is what lets the same
    pipeline run against SQLite and a folder on a laptop, against fakes in
    tests, and against the real services in the Function App and the web app
    — with the extraction, validation and reconciliation code identical in
    all three. `from_settings()` is the production wiring.
    """

    def __init__(self, *, settings, blobs, layout, extractor, sql, status,
                 verifier=None):
        self._settings = settings
        self._blobs = blobs
        self._layout = layout
        self._extractor = extractor
        self._sql = sql
        self._status = status
        self._verifier = verifier

    @classmethod
    def from_settings(cls, settings: Optional[Settings] = None) -> "FolioPipeline":
        """Wire against the real resources, choosing what exists."""
        s = settings or get_settings()
        cred = get_credential()
        return cls(
            settings=s,
            blobs=BlobRepository(s.storage_account_url, cred),
            layout=build_layout(s, cred),
            extractor=build_extractor(s, cred),
            sql=FolioSqlRepository(s.sql_server, s.sql_database, s.sql_table, cred,
                                   username=s.sql_username, password=s.sql_password),
            status=build_status_store(s, cred),
            verifier=build_verifier(s, cred),
        )

    def process(self, item: WorkItem, rates: RateContext) -> str:
        """Returns the resulting status string."""
        doc_key = f"{item.identifier}/{item.file_name}"
        content = self._blobs.download(item.container, item.blob_path)
        # Identity from the CONTENT, never from storage metadata; and one id
        # for every status write so a document leaves exactly one status row.
        blob_md5 = content_hash(content)
        status_id = compute_document_id(item.identifier, item.file_name, blob_md5)
        logger.info("Processing %s (%d bytes)", doc_key, len(content))

        lower = item.file_name.lower()
        if lower.endswith(".pdf"):
            layout = self._layout.analyze_pdf(content, item.file_name)
        elif lower.endswith(_IMAGE_SUFFIXES):
            media = "image/png" if lower.endswith(".png") else "image/jpeg"
            layout = self._layout.analyze_image(content, item.file_name, media)
        elif lower.endswith((".xlsx", ".xlsm", ".xls")):
            from tfa_core.extraction.excel_reader import analyze_excel
            layout = analyze_excel(content, item.file_name)
        else:
            self._status.mark(document_id=status_id, identifier=item.identifier,
                              file_name=item.file_name, status="failed",
                              detail=f"Unsupported file type: {item.file_name}")
            return "failed"

        self._status.mark(document_id=status_id, identifier=item.identifier,
                          file_name=item.file_name, status="processing")

        try:
            outcome = self._extractor.extract(layout, item.file_name)
        except ExtractionFailed as e:
            self._status.mark(document_id=status_id, identifier=item.identifier,
                              file_name=item.file_name, status="failed",
                              detail=str(e))
            raise  # let the Functions host retry / poison-queue it

        x = outcome.extraction
        if self._verifier is not None:
            # A second model reads the same document when the first was not
            # sure. Agreement on the money fields is evidence; disagreement is
            # routed to a person instead of being persisted as fact.
            verdict = self._verifier.verify(layout, item.file_name, outcome)
            if verdict is not None:
                outcome.warnings.extend(verdict.warnings)
                if verdict.needs_review:
                    outcome.needs_review = True
        is_hotel = x.document_type.value == "hotel_folio"
        rate = rates.directory.match(x.hotel_name, x.country) if is_hotel else None
        fx = rates.fx_by_currency.get(x.currency)
        warnings = list(outcome.warnings)
        if is_hotel and rate is None:
            warnings.append(f"No negotiated rate matched for '{x.hotel_name}'.")
        if fx is None and x.currency != "USD":
            warnings.append(f"No FX rate available for {x.currency}; USD fields null.")
        if x.currency == "USD" and fx is None:
            fx = FxRate(currency="USD", usd_per_unit=__import__("decimal").Decimal("1"))

        records = build_records(
            x,
            file_name=item.file_name,
            identifier_name=item.identifier,
            uploading_person_name=item.uploading_person_name,
            blob_md5=blob_md5,
            rate=rate,
            fx=fx,
            needs_review=outcome.needs_review,
            warnings=warnings,
        )
        document_id = records[0].document_id
        n = self._sql.upsert_document(document_id, records)

        status = "needs_review" if outcome.needs_review else "succeeded"
        self._status.mark(document_id=document_id, identifier=item.identifier,
                          file_name=item.file_name, status=status,
                          detail="; ".join(warnings) or None,
                          attempts=outcome.attempts)
        logger.info("%s -> %d row(s), status=%s, attempts=%d",
                    doc_key, n, status, outcome.attempts)
        return status


# --------------------------------------------------------------------------- #
# Wiring helpers — one place decides which implementation the infra supports
# --------------------------------------------------------------------------- #

def build_layout(s: Settings, cred):
    if s.use_docintel:
        return LayoutExtractor(s.docintel_endpoint, cred, s.docintel_model,
                               render_dpi=s.render_dpi, max_pages=s.max_pages_per_doc)
    from tfa_core.extraction.pdf_layout import PdfVisionLayout
    return PdfVisionLayout(render_dpi=s.render_dpi, max_pages=s.max_pages_per_doc,
                           max_images=s.max_page_images)


def build_extractor(s: Settings, cred):
    llm = build_llm(s.llm_provider, s.llm_endpoint, s.llm_deployment, s.llm_api_version,
                    cred, api_key=s.llm_api_key)
    if s.extraction_engine == "graph":
        from tfa_core.graph.extraction_graph import GraphExtractor
        return GraphExtractor(llm, max_attempts=s.llm_extraction_max_attempts,
                              max_output_tokens=s.llm_max_output_tokens)
    return LLMExtractor(llm, max_attempts=s.llm_extraction_max_attempts,
                        max_output_tokens=s.llm_max_output_tokens)


def build_verifier(s: Settings, cred):
    if not s.llm_verify_deployment:
        return None
    from tfa_core.extraction.verify import CrossModelVerifier
    second = build_llm(s.llm_verify_provider or s.llm_provider,
                       s.llm_verify_endpoint or s.llm_endpoint,
                       s.llm_verify_deployment, s.llm_api_version, cred,
                       api_key=None if s.llm_verify_endpoint else s.llm_api_key)
    return CrossModelVerifier(second, max_output_tokens=s.llm_max_output_tokens,
                              tolerance=s.llm_verify_tolerance, always=s.llm_verify_always)


def build_status_store(s: Settings, cred):
    if s.use_cosmos:
        return ProcessingStatusRepository(s.cosmos_endpoint, s.cosmos_database,
                                          s.cosmos_status_container, cred)
    from tfa_core.storage.repositories import SqlStatusRepository, sql_connector
    return SqlStatusRepository(sql_connector(s.sql_server, s.sql_database, cred,
                                             s.sql_username, s.sql_password))
