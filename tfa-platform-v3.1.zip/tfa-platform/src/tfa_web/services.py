"""What the web app does between a request and tfa_core.

Three responsibilities, each small:

  Uploads     put a file where the pipeline expects it and record that it is
              waiting. The legacy app appended a line to a .txt in a second
              container and a scheduler drained it; here the status store is
              the queue and a background thread is the drainer.

  Processing  run tfa_core's FolioPipeline over whatever is waiting. The
              pipeline is the production code; this just feeds it.

  Rates       the Negotiated Rates tab was a placeholder in the legacy app.
              Here it reads and writes the same rates/*.json blobs the worker
              consumes, so a rate uploaded in the UI is the rate the next
              document is reconciled against.

Nothing in this module imports Flask. It is called from the routes and from
the background thread and must not care which.
"""

from __future__ import annotations

import json
import logging
import threading
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from decimal import Decimal
from typing import Any, Optional

from tfa_core.domain.identity import compute_document_id, content_hash
from tfa_core.extraction.reconciliation import FxRate, NegotiatedRate, RateDirectory
from tfa_core.domain.rules import sanitize_filename, validate_identifier
from tfa_core.extraction.llm_extractor import ExtractionFailed
from tfa_core.extraction.pipeline import FolioPipeline, RateContext, WorkItem

log = logging.getLogger("tfa_web.services")

RATES_BLOB = "rates/negotiated_rates.json"
FX_BLOB = "rates/fx.json"


def person_slug(display_name: str) -> str:
    """'Ana María López' → 'Ana_Mar_a_L_pez'. Matches the legacy
    `secure_filename(person_name.replace(' ', '_'))` closely enough that
    existing blobs under the old layout still resolve."""
    from werkzeug.utils import secure_filename
    return secure_filename((display_name or "unknown_user").replace(" ", "_")) or "unknown_user"


def blob_path_for(identifier: str, person: str, filename: str) -> str:
    """The legacy layout, kept because the real container already uses it:
    `<identifier>-<person>/<filename>`. The identifier and filename are
    validated by tfa_core's rules; the person segment is slugged."""
    ident = validate_identifier(identifier)
    name = sanitize_filename(filename)
    return f"{ident}-{person_slug(person)}/{name}"


# --------------------------------------------------------------------------- #
# Rates
# --------------------------------------------------------------------------- #

@dataclass
class RateService:
    blobs: Any
    container: str

    def load_context(self) -> RateContext:
        rates = self.list_rates()
        fx = self.list_fx()
        directory = RateDirectory([
            NegotiatedRate(hotel_name=r["hotel_name"], country=r.get("country"),
                           nightly_rate_usd=Decimal(str(r["nightly_rate_usd"])))
            for r in rates
        ])
        fx_map = {
            f["currency"].upper(): FxRate(currency=f["currency"].upper(),
                                          usd_per_unit=Decimal(str(f["usd_per_unit"])))
            for f in fx
        }
        return RateContext(directory=directory, fx_by_currency=fx_map)

    def _read_json(self, path: str) -> list[dict]:
        try:
            raw = self.blobs.download(self.container, path)
        except Exception:
            return []
        try:
            data = json.loads(raw)
            return data if isinstance(data, list) else []
        except json.JSONDecodeError:
            log.warning("rate blob %s is not valid JSON", path)
            return []

    def list_rates(self) -> list[dict]:
        return self._read_json(RATES_BLOB)

    def list_fx(self) -> list[dict]:
        return self._read_json(FX_BLOB)

    def replace_rates(self, rows: list[dict], actor: str) -> int:
        """Whole-file replace. Rates are reference data edited rarely and by
        one person at a time; a merge would hide a deleted row."""
        cleaned = []
        for i, r in enumerate(rows, start=1):
            hotel = (r.get("hotel_name") or "").strip()
            rate = r.get("nightly_rate_usd")
            if not hotel:
                raise ValueError(f"row {i}: hotel_name is required")
            try:
                rate_d = Decimal(str(rate))
            except Exception:
                raise ValueError(f"row {i}: nightly_rate_usd '{rate}' is not a number")
            if rate_d <= 0:
                raise ValueError(f"row {i}: nightly_rate_usd must be positive")
            cleaned.append({
                "hotel_name": hotel,
                "country": (r.get("country") or "").strip() or None,
                "city": (r.get("city") or "").strip() or None,
                "nightly_rate_usd": f"{rate_d:.2f}",
                "valid_from": (r.get("valid_from") or "").strip() or None,
                "valid_to": (r.get("valid_to") or "").strip() or None,
            })
        payload = json.dumps(cleaned, ensure_ascii=False, indent=2).encode("utf-8")
        self.blobs.upload(self.container, RATES_BLOB, payload, overwrite=True)
        log.info("%s replaced the rate card: %d rows", actor, len(cleaned))
        return len(cleaned)

    def replace_fx(self, rows: list[dict], actor: str) -> int:
        cleaned = []
        for i, r in enumerate(rows, start=1):
            cur = (r.get("currency") or "").strip().upper()
            if len(cur) != 3:
                raise ValueError(f"row {i}: currency must be a 3-letter code")
            try:
                per_unit = Decimal(str(r.get("usd_per_unit")))
            except Exception:
                raise ValueError(f"row {i}: usd_per_unit is not a number")
            if per_unit <= 0:
                raise ValueError(f"row {i}: usd_per_unit must be positive")
            cleaned.append({"currency": cur, "usd_per_unit": f"{per_unit:.8f}"})
        payload = json.dumps(cleaned, indent=2).encode("utf-8")
        self.blobs.upload(self.container, FX_BLOB, payload, overwrite=True)
        log.info("%s replaced FX: %d rows", actor, len(cleaned))
        return len(cleaned)


def parse_rate_csv(text: str) -> list[dict]:
    """CSV with a header row. Columns are matched by name, case-insensitively,
    so a spreadsheet exported with 'Hotel Name' still works."""
    import csv
    import io

    reader = csv.DictReader(io.StringIO(text))
    if not reader.fieldnames:
        return []
    norm = {f: f.strip().lower().replace(" ", "_") for f in reader.fieldnames}
    rows = []
    for raw in reader:
        row = {norm[k]: (v or "").strip() for k, v in raw.items() if k in norm}
        if any(row.values()):
            rows.append(row)
    return rows


# --------------------------------------------------------------------------- #
# Uploads and processing
# --------------------------------------------------------------------------- #

@dataclass
class UploadResult:
    filename: str
    stored: bool
    message: str
    document_id: Optional[str] = None


@dataclass
class Processor:
    """Owns the pipeline and the queue of work. One per process.

    The legacy app scheduled its job inside the web process under two gunicorn
    workers, so the job could run twice and the two copies could race on the
    tracking file. Here each worker still has its own Processor, but the queue
    is the status store and a document is claimed by writing 'processing'
    before it is read, so two workers cannot both take it.
    """
    pipeline: FolioPipeline
    blobs: Any
    status: Any
    rates: RateService
    container: str
    interval_s: int = 60
    # SharePoint, when configured: an object with .delta()/.download() (the
    # real SharePointSource or a fake) and a sync-state store. The web app
    # syncs every `sharepoint_interval_s` from the same background thread
    # that drains the queue, so a library drop becomes a processed row with
    # no Function App and no Event Grid in between.
    sharepoint_source: Any = None
    sharepoint_state: Any = None
    sharepoint_interval_s: int = 300
    last_sync: Optional[str] = None
    last_sync_result: dict = field(default_factory=dict)
    _last_sync_at: float = field(default=0.0, repr=False)
    _thread: Optional[threading.Thread] = field(default=None, repr=False)
    _stop: threading.Event = field(default_factory=threading.Event, repr=False)
    _lock: threading.Lock = field(default_factory=threading.Lock, repr=False)
    last_run: Optional[str] = None
    last_result: dict = field(default_factory=dict)
    # document_id -> blob path, for items whose path is not the upload layout
    _queued_paths: dict = field(default_factory=dict, repr=False)

    # ---- uploads ---------------------------------------------------------

    def store_upload(self, identifier: str, person: str, filename: str,
                     content: bytes) -> UploadResult:
        try:
            path = blob_path_for(identifier, person, filename)
        except Exception as exc:
            return UploadResult(filename, False, f"Rejected: {exc}")

        sha = content_hash(content)
        document_id = compute_document_id(identifier, filename, sha)
        self.blobs.upload(self.container, path, content, overwrite=True)
        self.status.mark(document_id=document_id, identifier=identifier,
                         file_name=filename, status="queued",
                         detail=f"uploaded by {person}")
        self._queued_paths[document_id] = path
        return UploadResult(filename, True, "Stored and queued for processing", document_id)

    # ---- sharepoint ------------------------------------------------------

    @property
    def sharepoint_enabled(self) -> bool:
        return self.sharepoint_source is not None and self.sharepoint_state is not None

    def sync_sharepoint(self) -> dict:
        """One incremental pass over the library. Each new file is written to
        the raw container at `<identifier>/<name>` — the same layout the
        Function App path uses — and queued under the uploader SharePoint
        reports, so the row records who put it there."""
        if not self.sharepoint_enabled:
            return {"skipped": "sharepoint not configured"}
        from tfa_core.ingestion.sharepoint import sync_sharepoint_to_blob
        result = sync_sharepoint_to_blob(self.sharepoint_source, self.sharepoint_state,
                                         self.blobs, self.container)
        queued = 0
        for identifier, file_name, blob_path, uploader in result.ingested_items:
            try:
                content = self.blobs.download(self.container, blob_path)
            except Exception:
                log.exception("synced %s but could not read it back", blob_path)
                continue
            document_id = compute_document_id(identifier, file_name, content_hash(content))
            self.status.mark(document_id=document_id, identifier=identifier, file_name=file_name,
                             status="queued", detail=f"synced from SharePoint; uploaded by {uploader or 'unknown'}",
                             )
            self._queued_paths[document_id] = blob_path
            queued += 1
        self.last_sync = datetime.now(timezone.utc).isoformat(timespec="seconds")
        self._last_sync_at = time.monotonic()
        self.last_sync_result = {"ingested": result.ingested, "queued": queued, "skipped": result.skipped,
                                 "deleted_flagged": result.deleted_flagged, "errors": result.errors}
        return self.last_sync_result

    # ---- processing ------------------------------------------------------

    def process_pending(self) -> dict:
        """Drain everything queued. Returns counts. Safe to call from a
        request handler (the Upload tab's 'Process now') or the thread."""
        if not self._lock.acquire(blocking=False):
            return {"skipped": "already running"}
        try:
            return self._drain()
        finally:
            self._lock.release()

    def _drain(self) -> dict:
        pending = self._pending()
        counts = {"queued": len(pending), "succeeded": 0, "needs_review": 0, "failed": 0}
        if not pending:
            self.last_run = datetime.now(timezone.utc).isoformat(timespec="seconds")
            self.last_result = counts
            return counts

        rates = self.rates.load_context()
        for item in pending:
            identifier, file_name = item["identifier"], item["file_name"]
            detail = item.get("detail") or ""
            person = detail.split("uploaded by ", 1)[-1].strip() if "uploaded by " in detail else "unknown_user"
            # Uploads live at <identifier>-<person>/<file>; SharePoint syncs at
            # <identifier>/<file>. The queue remembers which; if this process
            # restarted and forgot, try both before giving up.
            blob_path = self._queued_paths.get(item["document_id"]) or self._locate(identifier, person, file_name)
            if blob_path is None:
                counts["failed"] += 1
                self.status.mark(document_id=item["document_id"], identifier=identifier,
                                 file_name=file_name, status="failed",
                                 detail="queued but the file is not in storage under either layout")
                continue
            work = WorkItem(
                container=self.container, blob_path=blob_path,
                identifier=identifier, uploading_person_name=person, file_name=file_name,
            )
            try:
                status = self.pipeline.process(work, rates)
                counts[status if status in counts else "failed"] += 1
            except ExtractionFailed as exc:
                counts["failed"] += 1
                log.warning("%s/%s: %s", identifier, file_name, exc)
            except Exception:
                counts["failed"] += 1
                log.exception("%s/%s failed", identifier, file_name)
                self.status.mark(document_id=item["document_id"], identifier=identifier,
                                 file_name=file_name, status="failed",
                                 detail="unexpected error; see application log")
        self.last_run = datetime.now(timezone.utc).isoformat(timespec="seconds")
        self.last_result = counts
        return counts

    def _locate(self, identifier: str, person: str, file_name: str) -> Optional[str]:
        for candidate in (blob_path_for(identifier, person, file_name), f"{identifier}/{file_name}"):
            try:
                self.blobs.download(self.container, candidate)
                return candidate
            except Exception:
                continue
        return None

    def _pending(self) -> list[dict]:
        pend = getattr(self.status, "pending_all", None)
        if not callable(pend):
            return []
        out = []
        for p in pend():
            if p.get("status") != "queued":
                continue
            # Cosmos items carry the document id as `id`; SQLite as `document_id`.
            p = dict(p)
            p.setdefault("document_id", p.get("id"))
            out.append(p)
        return out

    def pending_count(self) -> int:
        return len(self._pending())

    # ---- background thread -----------------------------------------------

    def start_background(self) -> None:
        if self._thread and self._thread.is_alive():
            return
        self._stop.clear()
        self._thread = threading.Thread(target=self._loop, name="tfa-processor", daemon=True)
        self._thread.start()
        log.info("background processor started, every %ss", self.interval_s)

    def stop_background(self) -> None:
        self._stop.set()

    def _loop(self) -> None:
        # First tick after a short delay so a fresh container is serving
        # requests before it starts pulling documents.
        if self._stop.wait(5):
            return
        while not self._stop.is_set():
            if self.sharepoint_enabled and time.monotonic() - self._last_sync_at >= self.sharepoint_interval_s:
                try:
                    self.sync_sharepoint()
                except Exception:
                    log.exception("SharePoint sync tick failed")
                    self._last_sync_at = time.monotonic()   # do not hammer Graph on a persistent error
            try:
                self.process_pending()
            except Exception:
                log.exception("background processing tick failed")
            if self._stop.wait(self.interval_s):
                return
