"""Entra ID sign-in for the web app, via MSAL — the same flow the legacy app
used, with the parts that were wrong fixed:

  - the allow-list is still an email list (`TFA_ALLOWED_EMAILS`), but it can
    also be a group: set `TFA_ALLOWED_GROUP_ID` and membership is read from
    the `groups` claim, so adding someone to the Entra group is enough and no
    redeploy is needed
  - the session cookie is signed with a key that must be set; the app refuses
    to start without one instead of logging an error and carrying on
  - `/health` is the only unauthenticated route

Three modes, picked in this order:

  appservice  The infra's Terraform turns on App Service Authentication
              (auth_settings with the app registration). App Service then
              signs the user in before a request ever reaches Flask and
              passes the identity in X-MS-CLIENT-PRINCIPAL-* headers. Those
              headers are trusted ONLY when App Service says auth is on
              (WEBSITE_AUTH_ENABLED=True) or TFA_AUTH_MODE=appservice; App
              Service strips client-sent copies of them, a laptop does not.
  msal        The legacy flow: the app does the OAuth code exchange itself.
  local       No sign-in, fixed developer identity.

Setting names: the legacy app's CLIENT_ID / CLIENT_SECRET / TENANT_ID /
ALLOWED_EMAILS are accepted as well as the TFA_ names.

Local mode (`TFA_ENVIRONMENT=local`) skips sign-in entirely and uses a fixed
developer identity, because there is no app registration on a laptop and
asking for one would stop every local run before it started.
"""

from __future__ import annotations

import functools
import logging
import os
import uuid
from typing import Optional

from flask import Flask, current_app, jsonify, redirect, request, session, url_for

log = logging.getLogger("tfa_web.auth")

SCOPE = ["User.Read"]
REDIRECT_PATH = "/getAToken"


def _env(*names: str) -> str:
    for n in names:
        v = os.environ.get(n)
        if v:
            return v.strip()
    return ""


def _split(v: str) -> set[str]:
    return {e.strip().lower() for e in v.replace(";", ",").split(",") if e.strip()}


class AuthConfig:
    def __init__(self, app: Flask):
        self.local = app.config.get("TFA_LOCAL", False)
        self.client_id = _env("TFA_AUTH_CLIENT_ID", "CLIENT_ID")
        self.client_secret = _env("TFA_AUTH_CLIENT_SECRET", "CLIENT_SECRET")
        self.tenant_id = _env("TFA_AUTH_TENANT_ID", "TENANT_ID")
        self.allowed_emails = _split(_env("TFA_ALLOWED_EMAILS", "ALLOWED_EMAILS"))
        self.allowed_group = _env("TFA_ALLOWED_GROUP_ID")
        if self.local:
            self.mode = "local"
        else:
            forced = _env("TFA_AUTH_MODE").lower()
            easy = _env("WEBSITE_AUTH_ENABLED").lower() == "true"
            self.mode = forced if forced in ("appservice", "msal") else ("appservice" if easy else "msal")

    @property
    def authority(self) -> str:
        return f"https://login.microsoftonline.com/{self.tenant_id}"

    def validate(self) -> None:
        if self.local:
            return
        if self.mode == "appservice":
            # App Service already restricts sign-in to the app registration;
            # the allow-list still decides who gets in, as in the legacy app.
            if not self.allowed_emails and not self.allowed_group:
                raise RuntimeError("Set ALLOWED_EMAILS (or TFA_ALLOWED_GROUP_ID); "
                                   "an app with no allow-list admits every tenant user")
            return
        missing = [k for k, v in {
            "TFA_AUTH_CLIENT_ID": self.client_id, "TFA_AUTH_CLIENT_SECRET": self.client_secret,
            "TFA_AUTH_TENANT_ID": self.tenant_id}.items() if not v]
        if missing:
            raise RuntimeError(f"Sign-in is not configured: {', '.join(missing)} not set")
        if not self.allowed_emails and not self.allowed_group:
            raise RuntimeError("Set TFA_ALLOWED_GROUP_ID or TFA_ALLOWED_EMAILS; "
                               "an app with no allow-list admits every tenant user")


def _msal_app(cfg: AuthConfig):
    import msal
    return msal.ConfidentialClientApplication(
        cfg.client_id, authority=cfg.authority, client_credential=cfg.client_secret)


def current_user() -> Optional[dict]:
    return session.get("user")


def is_authorised(cfg: AuthConfig, claims: dict) -> bool:
    if cfg.local:
        return True
    email = (claims.get("preferred_username") or claims.get("email") or "").lower()
    email = email or (claims.get("upn") or "").lower()
    if email and email in cfg.allowed_emails:
        return True
    if cfg.allowed_group:
        groups = claims.get("groups") or []
        if cfg.allowed_group in groups:
            return True
        # Large memberships overflow the token; Entra then sets this claim.
        if claims.get("_claim_names", {}).get("groups"):
            log.warning("groups claim overflowed for %s; set the app registration's "
                        "groups claim to emit the TFA group only", email)
    return False


def _principal_claims(b64: str) -> dict:
    """X-MS-CLIENT-PRINCIPAL is base64 JSON {claims:[{typ,val}]}. Flatten it,
    collecting every `groups` value, and map the long claim URIs to short names."""
    import base64
    import json
    if not b64:
        return {}
    try:
        data = json.loads(base64.b64decode(b64 + "=" * (-len(b64) % 4)))
    except Exception:
        return {}
    short = {
        "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/emailaddress": "email",
        "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/upn": "upn",
        "http://schemas.microsoft.com/identity/claims/objectidentifier": "oid",
    }
    out: dict = {"groups": []}
    for c in data.get("claims", []):
        typ, val = short.get(c.get("typ"), c.get("typ")), c.get("val")
        if typ == "groups":
            out["groups"].append(val)
        elif typ and typ not in out:
            out[typ] = val
    return out


def login_required(view):
    @functools.wraps(view)
    def wrapped(*args, **kwargs):
        if not session.get("user"):
            if request.path.startswith("/api/") or request.is_json:
                return jsonify({"error": "User not authenticated"}), 401
            return redirect(url_for("auth.login"))
        if not session.get("authorised") and request.endpoint != "ui.dashboard":
            # Signed in but not on the allow-list: the dashboard renders the
            # access-denied page; every other route — uploads, exports, rates,
            # deletes, /status — is refused, whatever its path or body type.
            return jsonify({"error": "Access denied"}), 403
        return view(*args, **kwargs)
    return wrapped


def register(app: Flask) -> AuthConfig:
    from flask import Blueprint

    cfg = AuthConfig(app)
    cfg.validate()
    bp = Blueprint("auth", __name__)

    if cfg.mode == "appservice":
        @app.before_request
        def _easy_auth_identity():
            name = request.headers.get("X-MS-CLIENT-PRINCIPAL-NAME", "")
            if not name:
                session.pop("user", None)
                session.pop("authorised", None)
                return
            if (session.get("user") or {}).get("preferred_username") == name:
                return
            claims = _principal_claims(request.headers.get("X-MS-CLIENT-PRINCIPAL", ""))
            claims.setdefault("preferred_username", name)
            session["user"] = {"name": claims.get("name") or name, "preferred_username": name}
            session["authorised"] = is_authorised(cfg, claims)
            if not session["authorised"]:
                log.warning("access denied for %s", name)

        @bp.route("/login")
        def login():
            return redirect("/.auth/login/aad?post_login_redirect_uri=/")

        @bp.route("/logout")
        def logout():
            session.clear()
            return redirect("/.auth/logout?post_logout_redirect_uri=/")

        app.register_blueprint(bp)
        return cfg

    if cfg.local:
        @app.before_request
        def _local_identity():
            if "user" not in session:
                session["user"] = {"name": "Local Developer", "preferred_username": "local@dev"}
                session["authorised"] = True

        @bp.route("/login")
        def login():
            return redirect(url_for("ui.dashboard"))

        @bp.route("/logout")
        def logout():
            session.clear()
            return redirect(url_for("ui.dashboard"))

        app.register_blueprint(bp)
        return cfg

    @bp.route("/login")
    def login():
        session["state"] = str(uuid.uuid4())
        auth_url = _msal_app(cfg).get_authorization_request_url(
            SCOPE, state=session["state"],
            redirect_uri=url_for("auth.authorized", _external=True))
        return redirect(auth_url)

    @bp.route(REDIRECT_PATH)
    def authorized():
        if request.args.get("state") != session.get("state"):
            log.warning("state mismatch on callback")
            return redirect(url_for("auth.login"))
        if "error" in request.args:
            log.warning("sign-in error: %s", request.args.get("error_description"))
            return redirect(url_for("auth.login"))
        code = request.args.get("code")
        if not code:
            return redirect(url_for("auth.login"))
        result = _msal_app(cfg).acquire_token_by_authorization_code(
            code, scopes=SCOPE, redirect_uri=url_for("auth.authorized", _external=True))
        if "error" in result:
            log.warning("token error: %s", result.get("error_description"))
            return redirect(url_for("auth.login"))
        claims = result.get("id_token_claims", {})
        session["user"] = {
            "name": claims.get("name", "User"),
            "preferred_username": claims.get("preferred_username", ""),
        }
        session["authorised"] = is_authorised(cfg, claims)
        if not session["authorised"]:
            log.warning("access denied for %s", session["user"]["preferred_username"])
        return redirect(url_for("ui.dashboard"))

    @bp.route("/logout")
    def logout():
        session.clear()
        post = url_for("auth.login", _external=True)
        return redirect(f"{cfg.authority}/oauth2/v2.0/logout?post_logout_redirect_uri={post}")

    app.register_blueprint(bp)
    return cfg
