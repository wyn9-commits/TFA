/* Folio Management — one file, no framework, same as the legacy app.
 * Every network call goes through api(); every table through renderTable().
 * Column order and headers come from the server's row keys so the UI never
 * carries its own copy of the schema — that copy is what drifted before. */

(function () {
  "use strict";

  const $ = (sel, root = document) => root.querySelector(sel);
  const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));

  // ---------- modals ----------
  const loading = $("#loadingModal");
  function busy(text) { $("#loadingText").textContent = text || "Working…"; loading.hidden = false; }
  function idle() { loading.hidden = true; }

  function confirm(title, text) {
    return new Promise((resolve) => {
      const m = $("#confirmModal");
      $("#confirmTitle").textContent = title; $("#confirmText").textContent = text;
      m.hidden = false;
      const done = (v) => { m.hidden = true; yes.onclick = no.onclick = null; resolve(v); };
      const yes = $("#confirmYes"), no = $("#confirmNo");
      yes.onclick = () => done(true); no.onclick = () => done(false);
    });
  }

  if (document.body.dataset.accessDenied === "true") $("#deniedModal").hidden = false;

  // ---------- api ----------
  async function api(path, opts = {}) {
    const r = await fetch(path, { credentials: "same-origin", ...opts });
    if (r.status === 401) { window.location.href = "/login"; throw new Error("Signed out"); }
    const ct = r.headers.get("content-type") || "";
    const body = ct.includes("json") ? await r.json() : await r.text();
    if (!r.ok) throw new Error((body && body.error) || (body && body.message) || body || `HTTP ${r.status}`);
    return body;
  }

  // ---------- header ----------
  const userBtn = $("#userButton"), userMenu = $("#userMenu");
  const name = ($(".user-name") || {}).textContent || "U";
  userBtn.textContent = name.trim().split(/\s+/).map(p => p[0]).join("").slice(0, 2).toUpperCase();
  userBtn.addEventListener("click", (e) => { e.stopPropagation(); userMenu.hidden = !userMenu.hidden; userBtn.setAttribute("aria-expanded", String(!userMenu.hidden)); });
  document.addEventListener("click", () => { userMenu.hidden = true; });

  // ---------- tabs ----------
  const tabInit = {};
  function showTab(id) {
    $$(".tab-content").forEach(t => t.classList.toggle("active", t.id === id));
    $$(".tab-link").forEach(b => b.classList.toggle("active", b.dataset.tab === id));
    if (!tabInit[id]) { tabInit[id] = true; (tabLoaders[id] || (() => {}))(); }
  }
  $$(".tab-link").forEach(b => b.addEventListener("click", () => showTab(b.dataset.tab)));

  // ---------- tables ----------
  const MONEY = new Set(["original_per_day_price", "negotiated_rate", "usd_per_day_price",
    "usd_late_early_unit_price", "usd_total_overcharged_amount", "usd_total_undercharged_amount",
    "usd_total_amount_differ", "nightly_rate_usd", "usd_per_unit"]);
  // On screen only. The Excel export carries every registry column; the
  // screen leads with what a reviewer scans for and tucks the rest behind a toggle.
  const HIDE = new Set(["document_id"]);
  const SECONDARY = new Set(["hotel_address", "booking_number", "nro_reserv", "gds_record_locator",
    "supplier_tax_id", "customer_name", "customer_tax_id", "e_invoice_id", "travel_route",
    "checkin_timestamp", "checkout_timestamp", "late_early_english_description",
    "usd_late_early_unit_price", "overcharged_days", "undercharged_days", "document_type"]);
  let showAll = false;

  function label(key) {
    return key.replace(/_/g, " ").replace(/\b(usd|gds|fx|id)\b/gi, s => s.toUpperCase())
      .replace(/^./, c => c.toUpperCase());
  }
  function fmt(key, v) {
    if (v === null || v === undefined || v === "") return "";
    if (MONEY.has(key) && !isNaN(v)) return Number(v).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    return String(v);
  }

  function renderTable(container, rows, { selectable = false, linkColumn = null, empty = "No data found." } = {}) {
    container.innerHTML = "";
    if (!rows || !rows.length) { container.innerHTML = `<p class="muted">${empty}</p>`; return; }
    const keys = Object.keys(rows[0]).filter(k => !HIDE.has(k) && (showAll || !SECONDARY.has(k)));
    const table = document.createElement("table");
    const thead = table.createTHead(); const hr = thead.insertRow();
    if (selectable) { const th = document.createElement("th"); th.innerHTML = '<input type="checkbox" class="select-all" aria-label="Select all">'; hr.appendChild(th); }
    const sort = { key: null, dir: 1 };
    keys.forEach(k => {
      const th = document.createElement("th"); th.textContent = label(k); th.dataset.key = k; th.tabIndex = 0;
      th.addEventListener("click", () => {
        sort.dir = sort.key === k ? -sort.dir : 1; sort.key = k;
        rows.sort((a, b) => {
          const x = a[k], y = b[k];
          if (x == null) return 1; if (y == null) return -1;
          const num = !isNaN(x) && !isNaN(y) && x !== "" && y !== "";
          return (num ? Number(x) - Number(y) : String(x).localeCompare(String(y), undefined, { numeric: true })) * sort.dir;
        });
        $$("th", thead).forEach(h => h.classList.remove("asc", "desc"));
        th.classList.add(sort.dir > 0 ? "asc" : "desc");
        body();
      });
      hr.appendChild(th);
    });
    const tbody = table.createTBody();
    function body() {
      tbody.innerHTML = "";
      rows.forEach(r => {
        const tr = tbody.insertRow();
        if (r.review_status === "needs_review") tr.classList.add("needs-review");
        if (r.issue_found === "Yes") tr.classList.add("issue");
        if (selectable) { const td = tr.insertCell(); td.innerHTML = `<input type="checkbox" class="row-check" value="${r.id}">`; }
        keys.forEach(k => {
          const td = tr.insertCell();
          if (k === linkColumn && r.id != null) td.innerHTML = `<a href="/download_folio/${r.id}" target="_blank" rel="noopener">${fmt(k, r[k])}</a>`;
          else td.textContent = fmt(k, r[k]);
          if (MONEY.has(k)) td.classList.add("num");
        });
      });
    }
    body();
    container.appendChild(table);
    if (selectable) {
      $(".select-all", table).addEventListener("change", (e) => { $$(".row-check", table).forEach(c => c.checked = e.target.checked); container.dispatchEvent(new Event("selection")); });
      table.addEventListener("change", (e) => { if (e.target.classList.contains("row-check")) container.dispatchEvent(new Event("selection")); });
    }
  }

  // ---------- filters ----------
  function readFilters(root) {
    const f = {};
    $$("select[data-filter]", root).forEach(s => { if (s.value) f[s.dataset.filter] = s.value; });
    return f;
  }
  function fill(select, values, keep) {
    const cur = keep ? select.value : "";
    select.innerHTML = '<option value="">All</option>';
    (values || []).forEach(v => { const o = document.createElement("option"); o.value = v; o.textContent = v; select.appendChild(o); });
    if (cur && values.includes(cur)) select.value = cur;
  }
  async function loadFilters(root) {
    const d = await api("/get_filter_options");
    const map = { identifier: d.identifiers, country: d.countries, hotel: d.hotels, year: d.years, year_quarter: d.year_quarters, year_month: d.year_months };
    $$("select[data-filter]", root).forEach(s => fill(s, map[s.dataset.filter], true));
  }
  async function getDetails(root, resultsEl, opts) {
    const f = readFilters(root);
    if (!Object.keys(f).length) { resultsEl.innerHTML = '<p class="muted error">Choose at least one filter.</p>'; return null; }
    busy("Fetching…");
    try {
      const d = await api("/get_folio_data_for_filters?" + new URLSearchParams(f));
      renderTable(resultsEl, d.data, opts);
      return { rows: d.data, query: new URLSearchParams(f).toString() };
    } catch (e) {
      resultsEl.innerHTML = `<p class="muted error">${e.message}</p>`; return null;
    } finally { idle(); }
  }

  // ---------- home ----------
  async function loadStatus() {
    try {
      const d = await api("/status");
      $("#statPending").textContent = d.pending;
      $("#statLastRun").textContent = d.last_run ? new Date(d.last_run).toLocaleString() : "not yet";
      const r = d.last_result || {};
      $("#statLastResult").textContent = Object.keys(r).length
        ? Object.entries(r).map(([k, v]) => `${k} ${v}`).join(" · ") : "–";
      const sp = d.sharepoint || {};
      $("#syncNowBtn").hidden = !sp.enabled;
      const spEl = $("#spStatus"); spEl.hidden = !sp.enabled;
      if (sp.enabled) {
        const lr = sp.last_result || {};
        spEl.textContent = sp.last_sync
          ? `SharePoint: last checked ${new Date(sp.last_sync).toLocaleString()} — ${lr.ingested ?? 0} new, ${lr.skipped ?? 0} unchanged, ${lr.errors ?? 0} errors`
          : "SharePoint: configured, not checked yet this session";
      }
      const rows = (d.items || []).map(i => ({ identifier: i.identifier, file: i.file_name, status: i.status, detail: i.detail || "", updated: (i.updated_at || i.updated_at_utc || "").replace("T", " ").slice(0, 19) }));
      renderTable($("#statusTable"), rows, { empty: "Nothing processed yet." });
    } catch (e) { $("#statusTable").innerHTML = `<p class="muted error">${e.message}</p>`; }
  }
  $("#refreshStatusBtn").addEventListener("click", loadStatus);
  $("#syncNowBtn").addEventListener("click", async () => {
    busy("Checking SharePoint…");
    try { const r = await api("/sync_now", { method: "POST" }); await loadStatus(); if (r.queued) await api("/process_now", { method: "POST" }); await loadStatus(); }
    catch (e) { alert(e.message); } finally { idle(); }
  });
  $("#processNowBtn").addEventListener("click", async () => {
    busy("Processing waiting documents…");
    try { await api("/process_now", { method: "POST" }); await loadStatus(); }
    catch (e) { alert(e.message); } finally { idle(); }
  });

  // ---------- upload ----------
  const identInput = $("#identifierInput"), identResult = $("#identifierResult");
  const fileInput = $("#fileInput"), fileList = $("#fileList"), uploadBtn = $("#uploadBtn");
  let identOk = false;
  function updateUploadBtn() { uploadBtn.disabled = !(identOk && fileInput.files.length); }
  identInput.addEventListener("input", () => { identOk = false; identResult.hidden = true; updateUploadBtn(); });
  identInput.addEventListener("blur", async () => {
    const v = identInput.value.trim(); if (!v) return;
    try {
      const d = await api("/validate_identifier", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ identifier: v }) });
      identOk = !!d.is_valid; identResult.textContent = d.message; identResult.className = "validation " + (identOk ? "ok" : "bad"); identResult.hidden = false;
    } catch (e) { identOk = false; identResult.textContent = e.message; identResult.className = "validation bad"; identResult.hidden = false; }
    updateUploadBtn();
  });
  fileInput.addEventListener("change", () => {
    const fs = Array.from(fileInput.files);
    fileList.innerHTML = fs.length ? "<ul>" + fs.map(f => `<li>${f.name} <span class="muted">${(f.size / 1024).toFixed(0)} KB</span></li>`).join("") + "</ul>" : '<p class="muted">No files selected.</p>';
    updateUploadBtn();
  });
  $("#uploadForm").addEventListener("submit", async (e) => {
    e.preventDefault();
    const fd = new FormData(); fd.append("identifier", identInput.value.trim());
    Array.from(fileInput.files).forEach(f => fd.append("filesToUpload[]", f));
    busy("Uploading…");
    const out = $("#uploadOutcome");
    try {
      const d = await api("/upload_files", { method: "POST", body: fd });
      out.className = "outcome ok"; out.innerHTML = `<p>${d.message}</p>` + "<ul>" + d.results.map(r => `<li>${r.file} — ${r.message}</li>`).join("") + "</ul>";
      identInput.value = ""; fileInput.value = ""; fileList.innerHTML = '<p class="muted">No files selected.</p>'; identOk = false; updateUploadBtn();
      tabInit.homeTab = false;
    } catch (err) { out.className = "outcome bad"; out.textContent = err.message; }
    finally { out.hidden = false; idle(); }
  });

  // ---------- rates ----------
  function toCsv(rows, cols) {
    const esc = v => { const s = v == null ? "" : String(v); return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s; };
    return [cols.join(","), ...rows.map(r => cols.map(c => esc(r[c])).join(","))].join("\n");
  }
  async function loadRates() {
    try {
      const d = await api("/rates");
      renderTable($("#ratesTable"), d.rates, { empty: "No rate card loaded. Upload one below." });
      renderTable($("#fxTable"), d.fx, { empty: "No FX rates loaded." });
      const csv = toCsv(d.rates, ["hotel_name", "country", "city", "nightly_rate_usd", "valid_from", "valid_to"]);
      $("#downloadRatesCsv").href = "data:text/csv;charset=utf-8," + encodeURIComponent(csv);
    } catch (e) { $("#ratesTable").innerHTML = `<p class="muted error">${e.message}</p>`; }
  }
  async function uploadRates(kind, input) {
    const out = $("#ratesOutcome");
    if (!input.files.length) { out.className = "outcome bad"; out.textContent = "Choose a CSV first."; out.hidden = false; return; }
    const ok = await confirm("Replace " + (kind === "fx" ? "exchange rates" : "rate card") + "?",
      "The current list is replaced entirely by the file. Rows already stored keep the rate they were reconciled with.");
    if (!ok) return;
    const fd = new FormData(); fd.append("kind", kind); fd.append("file", input.files[0]);
    busy("Saving…");
    try { const d = await api("/rates", { method: "POST", body: fd }); out.className = "outcome ok"; out.textContent = d.message; input.value = ""; await loadRates(); }
    catch (e) { out.className = "outcome bad"; out.textContent = e.message; }
    finally { out.hidden = false; idle(); }
  }
  $("#ratesForm").addEventListener("submit", (e) => { e.preventDefault(); uploadRates("rates", $("#ratesFile")); });
  $("#fxForm").addEventListener("submit", (e) => { e.preventDefault(); uploadRates("fx", $("#fxFile")); });
  $("#confirmYes").textContent = "Delete";

  // ---------- column toggle ----------
  $$(".filters").forEach(f => {
    const b = document.createElement("button"); b.type = "button"; b.className = "btn btn-secondary"; b.textContent = "All columns";
    b.addEventListener("click", () => { showAll = !showAll; b.textContent = showAll ? "Key columns" : "All columns";
      const get = f.id === "viewFilters" ? $("#viewGetBtn") : $("#deleteGetBtn"); if (get) get.click(); });
    f.appendChild(b);
  });

  // ---------- view ----------
  $("#viewGetBtn").addEventListener("click", async () => {
    const link = $("#viewDownloadLink"); link.hidden = true;
    const r = await getDetails($("#viewFilters"), $("#viewResults"), { linkColumn: "file_name" });
    if (r && r.rows.length) {
      link.href = "/download_folio_data_for_filters?" + r.query; link.hidden = false;
      const docs = new Set(r.rows.map(x => x.document_id)).size;
      const over = r.rows.filter(x => x.issue_found === "Yes").length;
      $("#viewSummary").textContent = `${r.rows.length} line(s) across ${docs} document(s); ${over} with a rate issue.`;
    } else $("#viewSummary").textContent = "";
  });

  // ---------- delete ----------
  const delResults = $("#deleteResults"), delBtn = $("#deleteSelectedBtn");
  delResults.addEventListener("selection", () => { delBtn.disabled = !$$(".row-check:checked", delResults).length; });
  $("#deleteGetBtn").addEventListener("click", async () => { delBtn.disabled = true; await getDetails($("#deleteFilters"), delResults, { selectable: true }); });
  delBtn.addEventListener("click", async () => {
    const ids = $$(".row-check:checked", delResults).map(c => Number(c.value));
    if (!ids.length) return;
    const ok = await confirm("Delete folios?", `Delete ${ids.length} selected line(s) and every other line of the same document(s)? This cannot be undone.`);
    if (!ok) return;
    busy("Deleting…");
    try {
      const d = await api("/delete_folios", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ folio_ids: ids }) });
      alert(d.message); delBtn.disabled = true;
      await loadFilters($("#deleteFilters")); await getDetails($("#deleteFilters"), delResults, { selectable: true });
      tabInit.viewTab = false;
    } catch (e) { alert(e.message); } finally { idle(); }
  });

  // ---------- tab loaders ----------
  const tabLoaders = {
    homeTab: loadStatus,
    ratesTab: loadRates,
    viewTab: () => loadFilters($("#viewFilters")).catch(e => { $("#viewResults").innerHTML = `<p class="muted error">${e.message}</p>`; }),
    deleteTab: () => loadFilters($("#deleteFilters")).catch(e => { delResults.innerHTML = `<p class="muted error">${e.message}</p>`; }),
  };
  showTab("homeTab");
})();
