"""Read side of the folio table, for the web app.

The worker writes rows; this reads them. Split from the write adapter because
the two have different consumers and different reasons to change — the
screens need filtering, distinct values, deletion by row id and an Excel
export, none of which the ingestion path should carry.

Two implementations with one interface:

    SqlServerReadStore   Azure SQL via an Entra token, for the deployed app
    SqliteReadStore      the local file, for the laptop

Both speak the same SQL dialect subset on purpose. The legacy app built its
WHERE clauses by string concatenation with `%s` placeholders; every query here
is parameterised, and the only interpolated identifier is a column name that
has been checked against the registry first.
"""

from __future__ import annotations

import io
import struct
from datetime import date
from typing import Any, Iterable, Optional, Protocol, Sequence

from tfa_core.schemas import EXCEL_DESCRIPTIONS, EXCEL_HEADERS, SQL_COLUMNS

# Which registry column each UI filter maps to. The legacy JS sends these
# exact keys, and `Hotel_property_name` there was a leftover from an older
# schema — it meant the matched hotel, which is what the dropdown shows.
FILTER_COLUMNS = {
    "identifier": "identifier_name",
    "country": "country",
    "hotel": "matched_hotel_name",
    "year_month": "year_month",
}

_SQL_SCOPE = "https://database.windows.net/.default"
_SQL_COPT_SS_ACCESS_TOKEN = 1256


def _check_column(name: str) -> str:
    if name not in SQL_COLUMNS and name != "id":
        raise ValueError(f"not a registry column: {name}")
    return name


def quarter_months(year_quarter: str) -> list[str]:
    """'2026-Q2' → ['2026-04', '2026-05', '2026-06']. Raises on bad input."""
    year, q = year_quarter.split("-Q")
    q_num = int(q)
    if not 1 <= q_num <= 4 or len(year) != 4 or not year.isdigit():
        raise ValueError(year_quarter)
    start = (q_num - 1) * 3 + 1
    return [f"{year}-{m:02d}" for m in range(start, start + 3)]


def year_quarter_of(year_month: Optional[str]) -> Optional[str]:
    if not year_month or "-" not in year_month:
        return None
    try:
        y, m = year_month.split("-")[:2]
        return f"{y}-Q{(int(m) - 1) // 3 + 1}"
    except ValueError:
        return None


class FolioReadStore(Protocol):
    def filter_options(self) -> dict[str, list[str]]: ...
    def query(self, filters: dict[str, Optional[str]]) -> list[dict[str, Any]]: ...
    def delete_rows(self, row_ids: Sequence[int]) -> int: ...
    def delete_document(self, document_id: str) -> int: ...
    def identifier_exists(self, identifier: str) -> bool: ...
    def document_id_for_row(self, row_id: int) -> Optional[str]: ...
    def file_location(self, row_id: int) -> Optional[tuple[str, str, str]]: ...
    def ping(self) -> bool: ...


# --------------------------------------------------------------------------- #
# Shared query construction
# --------------------------------------------------------------------------- #

class _BaseReadStore:
    """Everything except how to get a connection and which placeholder to use."""

    table: str
    placeholder: str = "?"

    def _connect(self):  # pragma: no cover - implemented by subclasses
        raise NotImplementedError

    def _where(self, filters: dict[str, Optional[str]]) -> tuple[str, list[Any]]:
        """Precedence for the date filters is month > quarter > year, as in the
        legacy app, because the most specific one subsumes the others."""
        clauses: list[str] = []
        params: list[Any] = []
        ph = self.placeholder

        for key, column in FILTER_COLUMNS.items():
            if key == "year_month":
                continue
            value = (filters.get(key) or "").strip()
            if value:
                clauses.append(f"[{_check_column(column)}] = {ph}")
                params.append(value)

        ym = (filters.get("year_month") or "").strip()
        yq = (filters.get("year_quarter") or "").strip()
        y = (filters.get("year") or "").strip()
        if ym:
            clauses.append(f"[year_month] = {ph}")
            params.append(ym)
        elif yq:
            try:
                months = quarter_months(yq)
            except ValueError:
                months = []
            if months:
                clauses.append(f"[year_month] IN ({', '.join([ph] * len(months))})")
                params.extend(months)
        elif y:
            prefix = "SUBSTR([year_month], 1, 4)" if self._is_sqlite() else "LEFT([year_month], 4)"
            clauses.append(f"{prefix} = {ph}")
            params.append(y)

        return (" AND ".join(clauses) if clauses else "1=1"), params

    def _is_sqlite(self) -> bool:
        return False

    # The order the registry declares, which is the order the Excel export
    # uses and the order people are used to: file, hotel, dates, money.
    # Python dicts keep insertion order and the UI renders keys in order,
    # so building the dict in this order is enough.
    _ORDER = ["id", "document_id", *SQL_COLUMNS]

    def _rows(self, cur) -> list[dict[str, Any]]:
        names = [d[0] for d in cur.description]
        out = []
        for r in cur.fetchall():
            raw = dict(zip(names, r))
            d = {k: raw[k] for k in self._ORDER if k in raw}
            d.update({k: v for k, v in raw.items() if k not in d})
            for k, v in list(d.items()):
                if isinstance(v, date):
                    d[k] = v.isoformat()
                elif hasattr(v, "quantize"):          # Decimal
                    d[k] = float(v)
            out.append(d)
        return out

    # ---- interface -------------------------------------------------------

    def filter_options(self) -> dict[str, list[str]]:
        with self._connect() as conn:
            cur = conn.cursor()

            def distinct(col: str, desc: bool = False) -> list[str]:
                _check_column(col)
                cur.execute(
                    f"SELECT DISTINCT [{col}] FROM {self.table} WHERE [{col}] IS NOT NULL "
                    f"AND [{col}] <> '' ORDER BY [{col}] {'DESC' if desc else 'ASC'}"
                )
                return [str(r[0]) for r in cur.fetchall()]

            identifiers = distinct("identifier_name")
            countries = distinct("country")
            hotels = distinct("matched_hotel_name")
            months = distinct("year_month", desc=True)

        years = sorted({m[:4] for m in months if len(m) >= 4}, reverse=True)
        quarters = sorted({q for q in (year_quarter_of(m) for m in months) if q}, reverse=True)
        return {
            "identifiers": identifiers, "countries": countries, "hotels": hotels,
            "years": years, "year_quarters": quarters, "year_months": months,
        }

    def query(self, filters: dict[str, Optional[str]]) -> list[dict[str, Any]]:
        where, params = self._where(filters)
        cols = ", ".join(f"[{c}]" for c in ["id", "document_id", *SQL_COLUMNS])
        with self._connect() as conn:
            cur = conn.cursor()
            cur.execute(f"SELECT {cols} FROM {self.table} WHERE {where} ORDER BY [id]", params)
            return self._rows(cur)

    def delete_rows(self, row_ids: Sequence[int]) -> int:
        ids = [int(i) for i in row_ids]
        if not ids:
            return 0
        ph = ", ".join([self.placeholder] * len(ids))
        with self._connect() as conn:
            cur = conn.cursor()
            cur.execute(f"DELETE FROM {self.table} WHERE [id] IN ({ph})", ids)
            n = cur.rowcount
            conn.commit()
            return n

    def delete_document(self, document_id: str) -> int:
        with self._connect() as conn:
            cur = conn.cursor()
            cur.execute(f"DELETE FROM {self.table} WHERE [document_id] = {self.placeholder}",
                        [document_id])
            n = cur.rowcount
            conn.commit()
            return n

    def identifier_exists(self, identifier: str) -> bool:
        with self._connect() as conn:
            cur = conn.cursor()
            cur.execute(
                f"SELECT 1 FROM {self.table} WHERE [identifier_name] = {self.placeholder} "
                f"LIMIT 1" if self._is_sqlite() else
                f"SELECT TOP 1 1 FROM {self.table} WHERE [identifier_name] = {self.placeholder}",
                [identifier])
            return cur.fetchone() is not None

    def document_id_for_row(self, row_id: int) -> Optional[str]:
        with self._connect() as conn:
            cur = conn.cursor()
            cur.execute(f"SELECT [document_id] FROM {self.table} WHERE [id] = {self.placeholder}",
                        [int(row_id)])
            r = cur.fetchone()
            return r[0] if r else None

    def file_location(self, row_id: int) -> Optional[tuple[str, str, str]]:
        with self._connect() as conn:
            cur = conn.cursor()
            cur.execute(
                f"SELECT [identifier_name], [uploading_person_name], [file_name] "
                f"FROM {self.table} WHERE [id] = {self.placeholder}", [int(row_id)])
            r = cur.fetchone()
            return (r[0], r[1], r[2]) if r else None

    def ping(self) -> bool:
        try:
            with self._connect() as conn:
                conn.cursor().execute("SELECT 1")
            return True
        except Exception:
            return False


# --------------------------------------------------------------------------- #
# Implementations
# --------------------------------------------------------------------------- #

class SqlServerReadStore(_BaseReadStore):
    """Azure SQL through the same connect() as the writer: Entra token, or the
    username/password from Key Vault when the infra provides one."""

    def __init__(self, table: str, connect):
        self.table = table
        self._connect_fn = connect

    def _connect(self):
        return self._connect_fn()


class SqliteReadStore(_BaseReadStore):
    """Reads the file the local write adapter creates."""

    def __init__(self, path, table: str = "folio_lines"):
        self.table = table
        self._path = str(path)
        self._ensure_id_column()

    def _is_sqlite(self) -> bool:
        return True

    def _connect(self):
        import sqlite3
        conn = sqlite3.connect(self._path)
        return conn

    def _ensure_id_column(self) -> None:
        """The local write adapter makes a bare table; the screens need a row
        id to delete by. SQLite's rowid serves, exposed as `id` through a view
        would be cleaner, but a generated column keeps the SQL identical."""
        import sqlite3
        with sqlite3.connect(self._path) as conn:
            cols = [r[1] for r in conn.execute(f"PRAGMA table_info({self.table})")]
            if not cols:
                return
            if "id" not in cols:
                # Rebuild with an INTEGER PRIMARY KEY so `id` is the rowid.
                quoted = ", ".join(f'"{c}" TEXT' for c in cols)
                conn.execute(f"ALTER TABLE {self.table} RENAME TO {self.table}__old")
                conn.execute(f"CREATE TABLE {self.table} (id INTEGER PRIMARY KEY AUTOINCREMENT, {quoted})")
                names = ", ".join(f'"{c}"' for c in cols)
                conn.execute(f"INSERT INTO {self.table} ({names}) SELECT {names} FROM {self.table}__old")
                conn.execute(f"DROP TABLE {self.table}__old")
                conn.commit()


# --------------------------------------------------------------------------- #
# Excel export
# --------------------------------------------------------------------------- #

def to_excel(rows: Iterable[dict[str, Any]]) -> bytes:
    """Two sheets, exactly as the legacy export: a 'Column Definitions' sheet
    first so the recipient can read the second, then 'FolioData'."""
    from openpyxl import Workbook
    from openpyxl.styles import Font
    from openpyxl.utils import get_column_letter

    wb = Workbook()
    defs = wb.active
    defs.title = "Column Definitions"
    defs.append(["Column Name", "Description"])
    for col in SQL_COLUMNS:
        header = EXCEL_HEADERS.get(col, col)
        defs.append([header, EXCEL_DESCRIPTIONS.get(header, "")])
    defs.column_dimensions["A"].width = 34
    defs.column_dimensions["B"].width = 100
    for cell in defs[1]:
        cell.font = Font(bold=True)

    data = wb.create_sheet("FolioData")
    headers = [EXCEL_HEADERS.get(c, c) for c in SQL_COLUMNS]
    data.append(headers)
    for cell in data[1]:
        cell.font = Font(bold=True)
    for r in rows:
        data.append([r.get(c) for c in SQL_COLUMNS])
    for i, h in enumerate(headers, start=1):
        data.column_dimensions[get_column_letter(i)].width = max(12, min(40, len(h) + 2))
    data.freeze_panes = "A2"

    out = io.BytesIO()
    wb.save(out)
    return out.getvalue()


def export_filename(filters: dict[str, Optional[str]]) -> str:
    parts = [v.replace(" ", "-") for v in (
        filters.get("identifier"), filters.get("country"), filters.get("hotel"),
        filters.get("year"), filters.get("year_quarter"), filters.get("year_month"),
    ) if v]
    return "Folio_data_" + ("_".join(parts) if parts else "complete_data") + ".xlsx"
