"""The Folio Management web app.

Same five tabs and the same route contract as the legacy Flask app, so the
people using it see the thing they know. Underneath, every call goes through
tfa_core: the validators, the content-addressed identity, the pipeline, the
column registry. The legacy app had its own copies of all of those and they
drifted; here there is one.

    create_app()                 the real thing — Entra sign-in, Azure resources
    create_app(local=True)       laptop — no sign-in, SQLite, folder for blobs

Composition is in `build_services()` and nowhere else.
"""

from __future__ import annotations

import logging
import os
from pathlib import Path
from typing import Any, Optional

from flask import Flask, Response, g, jsonify, redirect, render_template, request, session, url_for
from werkzeug.middleware.proxy_fix import ProxyFix

from tfa_core.domain.rules import validate_identifier

from . import auth as auth_mod
from .read_store import (FolioReadStore, SqliteReadStore, SqlServerReadStore,
                         export_filename, to_excel)
from .services import Processor, RateService, parse_rate_csv

log = logging.getLogger("tfa_web")

ROOT = Path(__file__).resolve().parents[2]


# --------------------------------------------------------------------------- #
# Composition
# --------------------------------------------------------------------------- #

class Services:
    read: FolioReadStore
    processor: Processor
    rates: RateService
    blobs: Any
    status: Any
    container: str
    mode: str
    sharepoint_source: Any = None
    sharepoint_state: Any = None


def build_services(local: bool) -> Services:
    svc = Services()
    if local:
        import sys
        sys.path.insert(0, str(ROOT))
        from local.adapters import (LocalBlobStore, LocalLayoutExtractor, LocalStructuredLLM,
                                    SqliteFolioStore, SqliteStatusStore)
        from local.run_local import DB, LocalSettings
        from tfa_core.extraction.llm_extractor import LLMExtractor
        from tfa_core.extraction.pipeline import FolioPipeline

        settings = LocalSettings()
        blobs = LocalBlobStore(ROOT / "local" / "blob")
        analyzer = LocalLayoutExtractor()
        store = SqliteFolioStore(DB, settings.sql_table)
        status = SqliteStatusStore(DB)
        pipeline = FolioPipeline(
            settings=settings, blobs=blobs, layout=analyzer,
            extractor=LLMExtractor(LocalStructuredLLM(), max_attempts=3, max_output_tokens=8000),
            sql=store, status=status)
        svc.read = SqliteReadStore(DB, settings.sql_table)
        svc.container = settings.raw_container
        svc.mode = "local — SQLite, folder storage, rule-based extraction"
    else:
        from tfa_core.config import get_credential, get_settings
        from tfa_core.extraction.pipeline import (FolioPipeline, build_extractor, build_layout,
                                                  build_status_store, build_verifier)
        from tfa_core.storage.repositories import BlobRepository, FolioSqlRepository, sql_connector

        s = get_settings()
        cred = get_credential()
        blobs = BlobRepository(s.storage_account_url, cred)
        status = build_status_store(s, cred)
        connect = sql_connector(s.sql_server, s.sql_database, cred, s.sql_username, s.sql_password)
        pipeline = FolioPipeline(
            settings=s, blobs=blobs, layout=build_layout(s, cred),
            extractor=build_extractor(s, cred),
            sql=FolioSqlRepository(s.sql_server, s.sql_database, s.sql_table, connect=connect),
            status=status, verifier=build_verifier(s, cred))
        svc.read = SqlServerReadStore(s.sql_table, connect)
        svc.container = s.raw_container
        verify = f" + verify {s.llm_verify_deployment}" if s.llm_verify_deployment else ""
        reading = "Document Intelligence" if s.use_docintel else "PDF text + page images"
        store = "Cosmos" if s.use_cosmos else "SQL"
        svc.mode = (f"{s.environment} — {s.llm_deployment}{verify} — {reading} — "
                    f"status in {store} — SQL via {getattr(connect, 'auth', '?')}")
        if s.sharepoint_enabled and s.sharepoint_site_id and s.sharepoint_drive_id:
            from tfa_core.ingestion.sharepoint import SharePointSource, SharePointSyncState
            svc.sharepoint_source = SharePointSource(cred, s.sharepoint_site_id, s.sharepoint_drive_id)
            svc.sharepoint_state = SharePointSyncState(status.container)
            svc.mode += " — SharePoint sync on"

    svc.blobs, svc.status = blobs, status
    svc.rates = RateService(blobs, svc.container)
    svc.processor = Processor(
        pipeline=pipeline, blobs=blobs, status=status, rates=svc.rates,
        container=svc.container,
        interval_s=int(os.environ.get("TFA_PROCESS_INTERVAL_SECONDS", "60")),
        sharepoint_source=svc.sharepoint_source, sharepoint_state=svc.sharepoint_state,
        sharepoint_interval_s=int(os.environ.get("TFA_SHAREPOINT_INTERVAL_SECONDS", "300")))
    return svc


# --------------------------------------------------------------------------- #
# App factory
# --------------------------------------------------------------------------- #

def create_app(local: Optional[bool] = None, services: Optional[Services] = None,
               start_processor: bool = True) -> Flask:
    if local is None:
        local = os.environ.get("TFA_ENVIRONMENT", "dev").lower() == "local"

    app = Flask(__name__, template_folder="templates", static_folder="static")
    # Flask sorts JSON keys by default, which would turn the registry's
    # column order into alphabetical order on every screen.
    app.json.sort_keys = False
    app.config["TFA_LOCAL"] = local
    app.config["MAX_CONTENT_LENGTH"] = int(os.environ.get("TFA_MAX_UPLOAD_MB", "50")) * 1024 * 1024

    # FLASK_SECRET_KEY is the legacy app's setting name; both are accepted.
    secret = os.environ.get("TFA_SESSION_SECRET") or os.environ.get("FLASK_SECRET_KEY")
    if not secret:
        if local:
            secret = "local-dev-only-not-a-secret"
        else:
            raise RuntimeError("TFA_SESSION_SECRET (or FLASK_SECRET_KEY) is not set; "
                               "the app will not start without it")
    app.secret_key = secret
    app.config.update(
        SESSION_COOKIE_SECURE=not local, SESSION_COOKIE_HTTPONLY=True,
        SESSION_COOKIE_SAMESITE="Lax", PREFERRED_URL_SCHEME="http" if local else "https")
    app.wsgi_app = ProxyFix(app.wsgi_app, x_proto=1, x_host=1)

    for noisy in ("azure", "msal", "urllib3"):
        logging.getLogger(noisy).setLevel(logging.WARNING)

    svc = services or build_services(local)
    app.extensions["tfa"] = svc
    auth_cfg = auth_mod.register(app)

    _register_routes(app, svc)
    _register_security(app, local)

    if start_processor and os.environ.get("TFA_PROCESSOR", "on").lower() != "off":
        svc.processor.start_background()

    log.info("tfa_web ready: %s", svc.mode)
    return app


def _register_security(app: Flask, local: bool) -> None:
    @app.before_request
    def enforce_https():
        if local or request.path == "/health" or request.is_secure:
            return None
        if os.environ.get("TFA_ENVIRONMENT", "dev") in ("test", "prod", "dev"):
            return redirect(request.url.replace("http://", "https://", 1), code=301)
        return None

    @app.after_request
    def headers(resp: Response):
        resp.headers.setdefault("X-Content-Type-Options", "nosniff")
        resp.headers.setdefault("X-Frame-Options", "DENY")
        resp.headers.setdefault("Referrer-Policy", "same-origin")
        resp.headers.setdefault(
            "Content-Security-Policy",
            "default-src 'self'; img-src 'self' data:; style-src 'self'; script-src 'self'; "
            "frame-ancestors 'none'; object-src 'self'")
        return resp


# --------------------------------------------------------------------------- #
# Routes
# --------------------------------------------------------------------------- #

def _user() -> dict:
    return session.get("user") or {"name": "User", "preferred_username": ""}


def _filters_from_args() -> dict[str, Optional[str]]:
    a = request.args
    return {k: a.get(k) for k in ("identifier", "country", "hotel", "year", "year_quarter", "year_month")}


def _register_routes(app: Flask, svc: Services) -> None:
    from flask import Blueprint
    ui = Blueprint("ui", __name__)
    api = Blueprint("api", __name__)
    guard = auth_mod.login_required

    # ---- pages -------------------------------------------------------------

    @ui.route("/health")
    def health():
        ok = svc.read.ping()
        return jsonify({"status": "ok" if ok else "degraded", "mode": svc.mode,
                        "pending": svc.processor.pending_count(),
                        "last_run": svc.processor.last_run}), (200 if ok else 503)

    @ui.route("/")
    def index():
        return redirect(url_for("ui.dashboard"))

    @ui.route("/dashboard")
    @guard
    def dashboard():
        u = _user()
        return render_template(
            "dashboard.html",
            user_name=u["name"], user_email=u["preferred_username"],
            access_denied=not session.get("authorised", False),
            mode=svc.mode, local=app.config["TFA_LOCAL"])

    # ---- upload ------------------------------------------------------------

    @api.route("/validate_identifier", methods=["POST"])
    @guard
    def validate_identifier_route():
        data = request.get_json(silent=True) or {}
        raw = (data.get("identifier") or "").strip()
        try:
            ident = validate_identifier(raw)
        except Exception as exc:
            return jsonify({"is_valid": False, "identifier": raw, "message": str(exc)}), 200
        if svc.read.identifier_exists(ident):
            return jsonify({"is_valid": False, "identifier": ident,
                            "message": "This identifier already exists. Use a new, unique one."}), 200
        return jsonify({"is_valid": True, "identifier": ident,
                        "message": "Identifier is new and available."}), 200

    @api.route("/upload_files", methods=["POST"])
    @guard
    def upload_files():
        ident_raw = (request.form.get("identifier") or "").strip()
        try:
            ident = validate_identifier(ident_raw)
        except Exception as exc:
            return jsonify({"success": False, "message": f"Invalid identifier: {exc}"}), 400
        if svc.read.identifier_exists(ident):
            return jsonify({"success": False, "message": "This identifier already exists."}), 400

        files = [f for f in request.files.getlist("filesToUpload[]") if f and f.filename]
        if not files:
            return jsonify({"success": False, "message": "No files selected for upload."}), 400

        person = _user()["name"]
        results, stored = [], 0
        for f in files:
            if not f.filename.lower().endswith((".pdf", ".png", ".jpg", ".jpeg", ".xlsx", ".xls", ".xlsm")):
                results.append({"file": f.filename, "stored": False,
                                "message": "Unsupported type — PDF, PNG, JPEG or Excel only"})
                continue
            r = svc.processor.store_upload(ident, person, f.filename, f.read())
            results.append({"file": r.filename, "stored": r.stored, "message": r.message,
                            "document_id": r.document_id})
            stored += r.stored

        return jsonify({
            "success": stored > 0, "uploaded_count": stored, "results": results,
            "message": f"{stored} of {len(files)} file(s) stored under '{ident}'. "
                       f"Processing runs in the background; check the Home tab for status.",
        }), (200 if stored else 400)

    @api.route("/process_now", methods=["POST"])
    @guard
    def process_now():
        return jsonify(svc.processor.process_pending())

    @api.route("/status")
    @guard
    def status():
        recent = getattr(svc.status, "recent", None)
        items = recent(50) if callable(recent) else svc.processor._pending()
        for it in items:
            it.setdefault("document_id", it.get("id"))
        p = svc.processor
        return jsonify({"items": items, "pending": p.pending_count(),
                        "last_run": p.last_run, "last_result": p.last_result,
                        "sharepoint": {"enabled": p.sharepoint_enabled, "last_sync": p.last_sync,
                                       "last_result": p.last_sync_result}})

    @api.route("/sync_now", methods=["POST"])
    @guard
    def sync_now():
        if not svc.processor.sharepoint_enabled:
            return jsonify({"error": "SharePoint sync is not configured on this deployment."}), 400
        try:
            return jsonify(svc.processor.sync_sharepoint())
        except Exception as exc:
            log.exception("sync_now")
            return jsonify({"error": f"Sync failed: {exc}"}), 500

    # ---- view / delete / download -------------------------------------------

    @api.route("/get_filter_options")
    @guard
    def filter_options():
        try:
            return jsonify(svc.read.filter_options())
        except Exception as exc:
            log.exception("filter options")
            return jsonify({"error": f"Could not read filter options: {exc}"}), 500

    @api.route("/get_folio_data_for_filters")
    @guard
    def folio_data():
        filters = _filters_from_args()
        if not any(filters.values()):
            return jsonify({"error": "Select at least one filter."}), 400
        try:
            return jsonify({"data": svc.read.query(filters)})
        except Exception as exc:
            log.exception("query")
            return jsonify({"error": f"Could not fetch data: {exc}"}), 500

    @api.route("/download_folio_data_for_filters")
    @guard
    def download_excel():
        filters = _filters_from_args()
        rows = svc.read.query(filters) if any(filters.values()) else svc.read.query({})
        if not rows:
            return "No data found for the selected filters.", 404
        body = to_excel(rows)
        return Response(
            body, mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            headers={"Content-Disposition": f'attachment; filename="{export_filename(filters)}"'})

    @api.route("/download_folio/<int:row_id>")
    @guard
    def download_folio(row_id: int):
        """By row id rather than by path segments: the legacy route took
        identifier/person/filename from the URL and joined them, which is a
        traversal surface. The row already knows where its file is."""
        loc = svc.read.file_location(row_id)
        if not loc:
            return "No such folio.", 404
        identifier, person, file_name = loc
        # Uploads live under <identifier>-<person>/, SharePoint syncs under
        # <identifier>/. The row does not say which, so try both.
        path = svc.processor._locate(identifier, person, file_name)
        if path is None:
            log.warning("download %s: not in storage under either layout", row_id)
            return "File not found in storage.", 404
        try:
            content = svc.blobs.download(svc.container, path)
        except Exception as exc:
            log.warning("download %s: %s", row_id, exc)
            return "File not found in storage.", 404
        mime = "application/pdf" if file_name.lower().endswith(".pdf") else "application/octet-stream"
        return Response(content, mimetype=mime,
                        headers={"Content-Disposition": f'inline; filename="{file_name}"'})

    @api.route("/delete_folios", methods=["POST"])
    @guard
    def delete_folios():
        data = request.get_json(silent=True) or {}
        ids = data.get("folio_ids")
        if not isinstance(ids, list) or not ids:
            return jsonify({"error": "No folio IDs provided for deletion."}), 400
        try:
            ids = [int(i) for i in ids]
        except (TypeError, ValueError):
            return jsonify({"error": "Folio IDs must be integers."}), 400

        # Deleting one line of a multi-line document leaves the others
        # orphaned and the totals wrong. Delete by document, always.
        doc_ids = {d for d in (svc.read.document_id_for_row(i) for i in ids) if d}
        deleted = sum(svc.read.delete_document(d) for d in doc_ids)
        log.info("%s deleted %d row(s) across %d document(s)",
                 _user()["preferred_username"], deleted, len(doc_ids))
        return jsonify({"success": True, "deleted_count": deleted, "documents": len(doc_ids),
                        "message": f"Deleted {deleted} line(s) from {len(doc_ids)} document(s)."})

    # ---- negotiated rates -----------------------------------------------------

    @api.route("/rates")
    @guard
    def rates_get():
        return jsonify({"rates": svc.rates.list_rates(), "fx": svc.rates.list_fx()})

    @api.route("/rates", methods=["POST"])
    @guard
    def rates_put():
        actor = _user()["preferred_username"] or _user()["name"]
        kind = request.form.get("kind") or (request.get_json(silent=True) or {}).get("kind") or "rates"
        try:
            if "file" in request.files:
                text = request.files["file"].read().decode("utf-8-sig")
                rows = parse_rate_csv(text)
            else:
                rows = (request.get_json(silent=True) or {}).get("rows") or []
            if not rows:
                return jsonify({"success": False, "message": "No rows found."}), 400
            n = svc.rates.replace_fx(rows, actor) if kind == "fx" else svc.rates.replace_rates(rows, actor)
            return jsonify({"success": True, "count": n,
                            "message": f"{n} {'FX' if kind == 'fx' else 'rate'} row(s) saved. "
                                       f"They apply to the next document processed."})
        except ValueError as exc:
            return jsonify({"success": False, "message": str(exc)}), 400
        except Exception as exc:
            log.exception("rates upload")
            return jsonify({"success": False, "message": f"Could not save: {exc}"}), 500

    app.register_blueprint(ui)
    app.register_blueprint(api)
