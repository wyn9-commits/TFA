"""Run the web app from a terminal.

    python -m tfa_web                 # local mode on http://127.0.0.1:8501
    python -m tfa_web --port 8000
    TFA_ENVIRONMENT=dev python -m tfa_web   # real resources; needs az login + .env

In a container, gunicorn serves `tfa_web.wsgi:app` instead — see Dockerfile.
"""

from __future__ import annotations

import argparse
import logging
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def _load_env() -> None:
    from tfa_core.envfile import load_env_file
    load_env_file(ROOT / ".env")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--host", default="127.0.0.1")
    ap.add_argument("--port", type=int, default=8501)
    ap.add_argument("--local", action="store_true", help="force local mode")
    ap.add_argument("--no-browser", action="store_true")
    args = ap.parse_args()

    _load_env()
    if args.local or not os.environ.get("TFA_ENVIRONMENT"):
        os.environ["TFA_ENVIRONMENT"] = "local"

    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)-7s %(name)s  %(message)s")
    from .app import create_app
    app = create_app()

    url = f"http://{args.host}:{args.port}"
    print(f"\n  Folio Management\n  mode  {app.extensions['tfa'].mode}\n  open  {url}\n")
    if not args.no_browser:
        import threading, webbrowser
        threading.Timer(1.2, lambda: webbrowser.open(url)).start()
    app.run(host=args.host, port=args.port, debug=False, use_reloader=False)
    return 0


if __name__ == "__main__":
    sys.exit(main())
