"""Gunicorn entry point: `gunicorn tfa_web.wsgi:app`."""
from .app import create_app

app = create_app()
