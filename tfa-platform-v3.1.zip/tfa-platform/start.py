#!/usr/bin/env python3
"""Start here on a client laptop.

    python start.py            # check the machine, then open the web app
    python start.py --local    # web app on SQLite + local rules, no Azure
    python start.py --azure    # web app on the real resources (needs az login + .env)
    python start.py --cli      # no browser: run the pipeline over local/inbox and print
    python start.py --check    # only report; change and run nothing

Two ways this project can run, and this script picks between them:

  Azure path   your Entra group identity, the real resources, Document
               Intelligence OCR and the model. Needs `az login` and a network
               route to the private endpoints (VPN or jump host).

  Local path   SQLite, a folder for blobs, PyMuPDF for text, rules for
               extraction. Needs nothing but Python. Output is for exercising
               the pipeline, not for trusting a variance.

It is safe to run repeatedly. It creates a virtual environment on first run,
installs into it, and re-executes itself inside it; it never installs into
the system Python and never writes outside this folder.
"""

from __future__ import annotations

import os
import platform
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
VENV = ROOT / ".venv"
WIN = platform.system() == "Windows"
PY_IN_VENV = VENV / ("Scripts/python.exe" if WIN else "bin/python")
MIN_PY = (3, 11)

BOLD, DIM, GREEN, RED, YELLOW, RESET = (
    ("", "", "", "", "", "") if WIN and not os.environ.get("WT_SESSION")
    else ("\033[1m", "\033[2m", "\033[32m", "\033[31m", "\033[33m", "\033[0m"))


def say(mark: str, text: str, note: str = "") -> None:
    print(f"  {mark} {text:<34} {DIM}{note}{RESET}")


# --------------------------------------------------------------------------- #
# 1. Bootstrap: get into a venv with the dependencies installed
# --------------------------------------------------------------------------- #

def in_venv() -> bool:
    return Path(sys.prefix).resolve() == VENV.resolve()


def bootstrap() -> None:
    if sys.version_info < MIN_PY:
        sys.exit(f"Python {MIN_PY[0]}.{MIN_PY[1]}+ is required; this is {platform.python_version()}.\n"
                 "Install from python.org (no admin needed with 'Install for me only').")
    if not PY_IN_VENV.exists():
        print(f"{BOLD}Creating virtual environment{RESET} in {VENV.name}/ ...")
        subprocess.check_call([sys.executable, "-m", "venv", str(VENV)])
    marker = VENV / ".deps-installed"
    req = ROOT / "requirements-dev.txt"
    if not marker.exists() or marker.stat().st_mtime < req.stat().st_mtime:
        print(f"{BOLD}Installing dependencies{RESET} (first run; a few minutes) ...")
        cmd = [str(PY_IN_VENV), "-m", "pip", "install", "-q", "--disable-pip-version-check",
               "-r", str(req)]
        try:
            subprocess.check_call(cmd)
        except subprocess.CalledProcessError:
            print(f"\n{RED}pip install failed.{RESET} On a corporate network this is usually the "
                  "proxy or a private package index. Try:\n"
                  "  - set HTTPS_PROXY to your proxy, or\n"
                  "  - pip config set global.index-url <your Azure Artifacts feed>\n"
                  "then run start.py again.")
            sys.exit(1)
        marker.touch()
    if not in_venv():
        os.execv(str(PY_IN_VENV), [str(PY_IN_VENV), str(ROOT / "start.py"), *sys.argv[1:]])


# --------------------------------------------------------------------------- #
# 2. Check the machine
# --------------------------------------------------------------------------- #

def module_ok(name: str) -> bool:
    try:
        __import__(name)
        return True
    except Exception:
        return False


def check_machine() -> dict:
    print(f"\n{BOLD}This machine{RESET}")
    say("·", "Python", f"{platform.python_version()} in {sys.prefix}")
    say("·", "OS", f"{platform.system()} {platform.release()}")

    state = {"azure_cli": False, "logged_in": False, "pyodbc": False, "odbc18": False,
             "env": False, "fitz": module_ok("fitz")}

    az = shutil.which("az") or shutil.which("az.cmd")
    state["azure_cli"] = bool(az)
    say(GREEN + "✓" + RESET if az else YELLOW + "–" + RESET, "Azure CLI",
        az if az else "not installed — needed for the Azure path only")

    if az:
        try:
            r = subprocess.run([az, "account", "show", "--query", "user.name", "-o", "tsv"],
                               capture_output=True, text=True, timeout=20)
            if r.returncode == 0 and r.stdout.strip():
                state["logged_in"] = True
                say(GREEN + "✓" + RESET, "az login", r.stdout.strip())
            else:
                say(YELLOW + "–" + RESET, "az login", "not signed in — run `az login` for the Azure path")
        except Exception as exc:
            say(YELLOW + "–" + RESET, "az login", f"could not check: {exc}")

    say(GREEN + "✓" + RESET if state["fitz"] else RED + "✗" + RESET, "PyMuPDF",
        "PDF text available" if state["fitz"] else "missing — pip install failed?")

    state["pyodbc"] = module_ok("pyodbc")
    if state["pyodbc"]:
        try:
            import pyodbc
            drivers = pyodbc.drivers()
            state["odbc18"] = any("ODBC Driver 18" in d for d in drivers)
            say(GREEN + "✓" + RESET if state["odbc18"] else YELLOW + "–" + RESET,
                "ODBC Driver 18", "present" if state["odbc18"] else
                f"not installed (have: {', '.join(drivers) or 'none'}) — SQL needs it; it is an MSI, may need IT")
        except Exception:
            say(YELLOW + "–" + RESET, "ODBC Driver 18", "could not enumerate drivers")
    else:
        say(YELLOW + "–" + RESET, "pyodbc", "not importable — SQL writes unavailable; local path unaffected")

    env = ROOT / ".env"
    state["env"] = env.exists()
    say(GREEN + "✓" + RESET if env.exists() else YELLOW + "–" + RESET, ".env",
        "present" if env.exists() else
        "absent — python scripts/map_terraform.py apply.log --write, or copy .env.template")
    return state


# --------------------------------------------------------------------------- #
# 3. Run
# --------------------------------------------------------------------------- #

def run_azure(state: dict) -> int:
    print(f"\n{BOLD}Azure path{RESET} — real resources, your identity")
    blockers = []
    if not state["azure_cli"]:
        blockers.append("Azure CLI is not installed (https://aka.ms/installazurecliwindows — no admin needed for the MSI per-user install)")
    elif not state["logged_in"]:
        blockers.append("run `az login` with the account that is in the TFA Entra group")
    if not state["env"]:
        blockers.append("no .env — see docs/MAPPING-FROM-ADO.md to derive it from the Terraform pipeline log")
    if blockers:
        print(f"{YELLOW}Cannot start the Azure path yet:{RESET}")
        for b in blockers:
            print(f"  · {b}")
        return 2

    print(f"{DIM}Running preflight. Every failure is classified so you know who fixes it.{RESET}\n")
    rc = subprocess.call([sys.executable, str(ROOT / "scripts" / "preflight.py")])
    if rc != 0:
        print(f"\n{YELLOW}Preflight is not green.{RESET} Fix what it names, then run start.py again.\n"
              f"If everything is NETWORK, you are not on the VPN — nothing else will change that.")
        return rc

    print(f"\n{GREEN}Preflight passed.{RESET} Starting the web app against the real resources.\n"
          f"  (To score the goldens against the real model instead:\n"
          f"   python -m evals.local_eval --azure)\n")
    return run_web(local=False)


def run_cli_local() -> int:
    print(f"\n{BOLD}Local pipeline (no browser){RESET} — SQLite and rules, no Azure")
    inbox = ROOT / "local" / "inbox"
    pdfs = sorted(inbox.glob("*.pdf")) if inbox.exists() else []
    if not pdfs:
        print(f"  No documents in local/inbox. Put PDFs there and run again.")
        return 1
    print(f"  {len(pdfs)} document(s) in local/inbox\n")
    return subprocess.call([sys.executable, str(ROOT / "local" / "run_local.py")])


def run_web(local: bool) -> int:
    """The five-tab app. Local mode needs nothing; live mode needs .env and az login."""
    env = dict(os.environ, PYTHONPATH=str(ROOT / "src"), TFA_ENVIRONMENT="local" if local else
               os.environ.get("TFA_ENVIRONMENT", "dev"))
    label = "SQLite + local rules, no sign-in" if local else "real resources, Entra sign-in"
    print(f"\n{BOLD}Web app{RESET} — {label}")
    print(f"  Upload the sample folios from local/inbox on the Upload tab, or your own.")
    print(f"  Ctrl+C stops it.\n")
    return subprocess.call([sys.executable, "-m", "tfa_web"], env=env, cwd=str(ROOT))


def main() -> int:
    bootstrap()
    args = set(sys.argv[1:])
    state = check_machine()
    if "--check" in args:
        return 0

    if "--cli" in args:
        return run_cli_local()
    if "--local" in args:
        return run_web(local=True)
    if "--azure" in args:
        return run_azure(state)

    # Auto: Azure if it can plausibly work, otherwise local, and say which.
    if state["azure_cli"] and state["logged_in"] and state["env"]:
        rc = run_azure(state)
        if rc == 0:
            return 0
        print(f"\n{DIM}The Azure path is not ready. Starting the local web app so you can still work.{RESET}")
    else:
        print(f"\n{DIM}Azure CLI, az login and .env are not all present — starting the local web app.\n"
              f"Run with --azure once they are, or see RUN.md.{RESET}")
    return run_web(local=True)


if __name__ == "__main__":
    raise SystemExit(main())
