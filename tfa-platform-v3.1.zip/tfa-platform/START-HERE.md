# Start here

Unzip, then:

| Windows | macOS / Linux |
|---|---|
| double-click `start.bat` | `./start.sh` |

Or from any terminal: `python start.py`

A browser opens on the app. The first run creates `.venv/` and installs into
it — a few minutes, and it needs to reach PyPI or your Azure Artifacts feed.
After that it is seconds. Nothing is installed outside this folder; no admin
rights are needed.

## What you get

The same five-tab application the team already uses, rebuilt on the new
pipeline:

| Tab | What it does |
|---|---|
| **Home** | Processing status: what is waiting, what ran, what each document came back as. A button to process now rather than wait for the background cycle. |
| **Upload Folios** | New identifier (checked for format and uniqueness as you leave the field), multiple PDFs, progress and per-file outcome. |
| **Negotiated Rates** | Was a placeholder. Now shows the rate card and FX table and replaces either from a CSV. Rates apply from the next document processed. |
| **View Folios** | Six filters (identifier, country, hotel, year, quarter, month), sortable table, key/all columns toggle, click a file name to open the source PDF, download the result as the two-sheet Excel the team is used to. |
| **Delete Folios** | Same filters, tick rows, confirm. Deleting any line of a document removes the whole document so totals stay consistent. |

## Two ways to run it

`start.py` checks the machine and picks one, saying which:

**Local** — needs nothing. SQLite, a folder for storage, rules instead of a
model, no sign-in. Six sample folios are in `local/inbox`; upload them on the
Upload tab. Good for seeing the whole flow in five minutes. Not good for
trusting a number: the rate card is invented and there is no OCR, so the
extraction is approximate (you will see it in the invoice numbers).

**Live** — the real resources from the infra Terraform: blob storage, Azure
SQL with the Key Vault login, and gpt-4o on Azure OpenAI. The model reads
the PDF's own text plus page images, because the infra has no Document
Intelligence. SharePoint sync starts once the site and drive ids are set.
Needs Azure CLI, `az login`, a `.env` (copy `.env.template`; it uses the
legacy app's setting names), and the VPN or jump host. `start.py` runs
`scripts/preflight.py` first and names anything that is missing. On a laptop
the app skips sign-in, even in live mode. When deployed, App Service signs
users in and `ALLOWED_EMAILS` decides who gets in.

Force either with `--local` or `--azure`. `--cli` runs the pipeline over
`local/inbox` with no browser; `--check` only reports.

## Getting the .env without portal access

The Terraform pipeline in Azure DevOps prints every resource name. Save its
apply-step raw log and run:

```
python scripts/map_terraform.py apply.log --write
```

`docs/MAPPING-FROM-ADO.md` shows where in ADO to find the log and which
Terraform blocks answer what a name cannot.

## Deploying

`azure-pipelines.yml` builds the container, pushes it to the same ACR the
legacy app used as `latest-dev` (the tag Terraform pins), and restarts the
same App Service. It uses the same agent pool and service connections, so
nothing has to be created on the ADO side and the app never drifts from
Terraform. `infra/README.md` maps every resource and setting to the
tfvars.

## Where things are

```
start.py / start.bat / start.sh   entry point
src/tfa_web/                      the web app: routes, sign-in, read store, UI
src/tfa_core/                     the pipeline: extraction, validation, reconciliation
Dockerfile, docker/, azure-pipelines.yml   the container and its deployment
scripts/preflight.py              can this identity reach and use every resource?
scripts/map_terraform.py          pipeline log → .env + checklist
local/                            the no-Azure adapters and the no-browser runner
infra/README.md                   what the app uses from the infra Terraform, and what it does without
docs/                             deployment, ADO mapping, security controls
tests/                            83, all passing
```

## Things that will go wrong, and what they mean

| You see | It means |
|---|---|
| `pip install failed` on first run | Corporate proxy or private index. Set `HTTPS_PROXY`, or point pip at your Azure Artifacts feed, then run again |
| ODBC Driver 18 not installed | SQL needs it on the live path. It is an MSI and may need IT. Local mode does not use it |
| Preflight: everything `NETWORK` | You are not on the VPN. No role or key changes this |
| Preflight: `AUTH` on one resource | The group is missing that one role; the report names it |
| Preflight: SQL login failed | `SQL_USERNAME` / `SQL_PASSWORD` do not match the Key Vault secrets (rotated?) |
| Local mode: odd invoice numbers, every stay flagged | Rule-based extraction and an invented rate card. The live path uses the model and your real rates |
| Status shows `needs_review` on most documents | The validators are strict on purpose. On rule-extracted sample data this is expected; on real documents through the model it is the signal to look at |

## What is not in this archive

- Terraform — owned elsewhere. This repo deploys code to resources that exist.
- Any key, password or connection string.
