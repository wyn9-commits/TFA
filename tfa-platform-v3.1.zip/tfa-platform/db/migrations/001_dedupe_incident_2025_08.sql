/* =============================================================================
   INCIDENT-2025-08 remediation for tfa_folio_lines.

   Defect: document identity was derived from blob metadata (content_md5 with
   an ETag fallback). content_md5 is never populated by our writer, so the ETag
   branch always ran, and an ETag changes on every write. Each re-sync or
   reprocess of the SAME file therefore inserted an ADDITIONAL set of rows
   under a NEW document_id, inflating reconciliation totals linearly with the
   reprocess count.

   Code fix (v3): identity is sha256(content); re-processing replaces rows.
   This script removes the historical duplicates the old code left behind.

   RUN ORDER: deploy v3 first (stops new duplicates), restore a copy of the
   database, run this against the COPY, compare totals, then run it for real.

   Rule: for each (identifier_name, file_name), keep the rows of the most
   recently ingested document_id and delete the rest. Deleted rows are
   snapshotted first so the decision is auditable and reversible.
   ========================================================================== */

SET XACT_ABORT ON;
BEGIN TRANSACTION;

IF OBJECT_ID('dbo.incident_2025_08_removed') IS NULL
CREATE TABLE dbo.incident_2025_08_removed (
    captured_at_utc DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME(),
    row_id          BIGINT,
    document_id     CHAR(32),
    identifier_name NVARCHAR(400),
    file_name       NVARCHAR(400),
    ingested_at_utc DATETIME2,
    usd_total_amount_differ DECIMAL(18,2)
);

/* 1. Which document_id to keep per (identifier, file): the latest. */
;WITH latest AS (
    SELECT identifier_name, file_name, document_id,
           ROW_NUMBER() OVER (PARTITION BY identifier_name, file_name
                              ORDER BY MAX(ingested_at_utc) DESC) AS rn
    FROM dbo.tfa_folio_lines
    GROUP BY identifier_name, file_name, document_id
),
victims AS (
    SELECT l.id, l.document_id, l.identifier_name, l.file_name, l.ingested_at_utc, l.usd_total_amount_differ
    FROM dbo.tfa_folio_lines l
    JOIN latest x ON x.identifier_name = l.identifier_name AND x.file_name = l.file_name
                 AND x.document_id = l.document_id
    WHERE x.rn > 1
)
/* 2. Snapshot, then delete. */
INSERT INTO dbo.incident_2025_08_removed (row_id, document_id, identifier_name, file_name, ingested_at_utc, usd_total_amount_differ)
SELECT id, document_id, identifier_name, file_name, ingested_at_utc, usd_total_amount_differ FROM victims;

DELETE l
FROM dbo.tfa_folio_lines l
WHERE l.id IN (SELECT row_id FROM dbo.incident_2025_08_removed WHERE captured_at_utc >= DATEADD(MINUTE, -5, SYSUTCDATETIME()));

/* 3. Report. */
SELECT COUNT(*) AS rows_removed,
       COUNT(DISTINCT document_id) AS duplicate_documents_removed,
       SUM(usd_total_amount_differ) AS usd_variance_that_was_double_counted
FROM dbo.incident_2025_08_removed
WHERE captured_at_utc >= DATEADD(MINUTE, -5, SYSUTCDATETIME());

COMMIT TRANSACTION;
