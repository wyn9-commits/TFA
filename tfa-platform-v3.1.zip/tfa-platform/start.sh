#!/usr/bin/env bash
# macOS / Linux equivalent of start.bat.
cd "$(dirname "$0")"
exec python3 start.py "$@"
