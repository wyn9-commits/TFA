@echo off
REM Double-click this on Windows. It finds Python, then hands off to start.py,
REM which creates a virtual environment, installs dependencies, checks the
REM machine and runs whichever path (Azure or local) can work right now.
setlocal
cd /d "%~dp0"

where py >nul 2>nul && (set PY=py -3) || (
  where python >nul 2>nul && (set PY=python) || (
    echo Python 3.11+ was not found on PATH.
    echo Install it from python.org and tick "Add python.exe to PATH" ^(no admin needed with "Install for me only"^).
    pause
    exit /b 1
  )
)

%PY% start.py %*
set RC=%ERRORLEVEL%
echo.
if %RC% NEQ 0 echo start.py exited with code %RC%. See the messages above.
pause
exit /b %RC%
