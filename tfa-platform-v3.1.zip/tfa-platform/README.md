# Travel Folio Analysis Platform — v3

A rebuild of `app-hds-ds-travel-folio-analysis` (RITM0607876). It keeps the
same five-tab web app the team uses (Home, Upload Folios, Negotiated Rates,
View Folios, Delete Folios), the same blob layout and the same two-sheet
Excel. Underneath is a new extraction pipeline built for accuracy, plus
SharePoint sync. **It runs on the resources the infra Terraform already
deploys and creates none.** `infra/README.md` maps every setting to the tfvars.

Start with `START-HERE.md`.

## Document types

The library holds more than hotel folios — e.g. Colombian DIAN e-invoices from
travel agencies for air tickets (validated against a real sample: fare + IVA
19% + tasa aeroportuaria + admin fee + its IVA = printed total). The model
classifies every document (`hotel_folio` | `air_ticket_invoice` |
`agency_fee_invoice` | `other_travel_invoice`) before extraction:

- Hotel folios: room nights → `nightly_charges`, per-night rate audit runs.
- Air/agency invoices: all lines → `ancillary_charges` with categories
  (`airfare`, `airport_tax`, `admin_fee`, `tax`); route, passenger, both NIT
  tax IDs, and the CUFE are captured; rate audit is skipped.
- When a total is also written in words ("SON: … PESOS"), the model converts
  it and a validator cross-checks it against the numeric total — mismatch
  triggers the repair loop.

Validated against real samples from four countries:
- **Colombia** — DIAN Factura Electrónica (air ticket, IVA 19%, CUFE).
- **Argentina** — Factura B with a *collapsed* 3-night line ("Habitación
  single durante tres noches", `nights=3` on one charge) and *included* IVA
  ("IVA Contenido", Ley 27.743) recorded in `informational_tax_amount`, never
  as an additive line.
- **Ecuador/US** — Wings TAX INVOICE in USD with English number format
  (1,056.00) and multi-leg routing.
- **Mexico** — Serrala/FS² internal AP cover pages classified as
  `ap_system_document` (G/L lines + additive tax; approval-history tables
  ignored).
The per-night rate audit expands collapsed lines (line total ÷ nights) so
negotiated-rate comparisons stay per-night.

**Unknown-sample strategy.** New document shapes will keep appearing, so the
design principle is: a never-seen-before document must degrade to *human
review*, never to silent bad data or a retry crash-loop. Escape hatches:
`credit_note` (negative amounts, links to the reversed invoice via
`references_invoice_number`; positive-total credit notes are flagged);
`other_travel_invoice` (generic-but-correct extraction: vendor, dates, tax
IDs, every amount line, the total — the prompt explicitly forbids forcing a
wrong specific type); `not_an_invoice` (boarding passes, email printouts,
blank scans — routed to review with a one-line `unreadable_reason`, no
arithmetic checks run); `contains_multiple_documents` (several invoices in
one scan: first one extracted, file flagged for splitting, amounts never
merged); symbol-only currencies inferred from country and confidence-flagged.
Excel workbooks (`.xlsx/.xlsm/.xls`) are rendered sheet-by-sheet to markdown
and flow through the same extraction, validators, and repair loop.

## How a document becomes rows

```
Upload tab ─┐                                   ┌─> tfa_folio_lines (Azure SQL)
            ├─> blob travel-folios ─> processor ─┤
SharePoint ─┘   (identity = sha256 of bytes)     └─> tfa_processing_status (SQL)
 (Graph delta,
  every 5 min)       processor = read PDF text layer of every page
                                 + 200-dpi images of up to 8 pages
                               → gpt-4o, strict JSON schema, temperature 0
                               → validators (sums, dates, nights, words-vs-digits)
                               → repair loop (max 3) with the validator's complaint
                               → optional second model if the first was unsure
                               → reconciliation in Python (rates, FX, over/undercharge)
```

Everything runs inside the App Service container (one gunicorn worker), so
the app needs no queue, Function App or Event Grid. The infra has none of
those.

## Ingestion: SharePoint → Blob

Folios also arrive through a SharePoint document library. The web app's
background processor runs a **Microsoft Graph delta query** every 5 minutes
(`TFA_SHAREPOINT_INTERVAL_SECONDS`), or on demand with *Check SharePoint now*
on Home. It copies new and changed PDF, PNG, JPG and XLSX files into the raw
container and queues them.

- **Auth:** the app's managed identity with Graph `Sites.Selected`, granted
  read on the TFA site only.
- **Layout:** `<library root>/<identifier>/<file>`. The first-level folder is
  the identifier, and the SharePoint uploader becomes `uploading_person_name`.
- **Incremental and idempotent:** the delta link and per-item eTags are kept
  in SQL (`tfa_kv`), or in Cosmos if one is configured. Content-addressed
  identity means the same bytes never produce a second set of rows.
- **Deletions** in SharePoint are flagged, never propagated.

## What the POC did, and what v3 does instead

| POC | v3 |
|---|---|
| Only **page 1**, one 150-dpi image | The **text layer of every page** plus **200-dpi images of up to 8 pages**. For born-digital e-invoices the text is exactly what the issuer printed. |
| One model call, no validation | **Strict structured outputs**, Pydantic types, **cross-field validators** (lines sum to total, checkout after checkin, nights against stay, amount in words against amount in digits), and a **repair loop** |
| Wrong values landed silently | Missing → `null`. Uncertain → `low_confidence_fields`, routed to **needs_review**. An optional **second model** must agree on the money fields. |
| LLM arithmetic | All arithmetic is **deterministic Python** and unit-tested |
| APScheduler and a shared tracking txt file | A processor with **per-document status rows** in SQL. One bad PDF never stalls the batch. |
| ETag-based identity, so duplicate rows on reprocess (INCIDENT-2025-08) | `document_id` = sha256(identifier/file/sha256(bytes)). The delete-then-insert on it is **idempotent**. |
| Three drifting column lists | One registry (`schemas.FOLIO_COLUMNS`) drives the SQL DDL, the Excel headers and the data dictionary |
| Its own sign-in code and an email list | **App Service Authentication** (already in the tfvars), plus the same `ALLOWED_EMAILS` allow-list, enforced on every route |

## Model

- **gpt-4o** on `travel-res` (Azure OpenAI): the only deployment the infra has.
- Reasoning-class deployments (o-series, gpt-5) work too. The provider
  switches to `max_completion_tokens` and drops `temperature` for them.
- `TFA_LLM_PROVIDER=anthropic_foundry` is also supported, for an
  Azure-hosted Claude deployment.
- Cross-model verification turns on when `TFA_LLM_VERIFY_DEPLOYMENT` names a
  second deployment.
- Any model change is a tfvars change in the infra repo. Measure it with
  `python -m evals.local_eval --azure` before promoting.

## Repository layout

```
start.py / start.bat / start.sh   entry point (local or live)
src/tfa_web/                      the five-tab web app, sign-in, processor, SharePoint loop
src/tfa_core/
  schemas.py                      models + the column registry
  config.py                       settings; accepts the legacy names
  llm/provider.py                 Azure OpenAI / Foundry structured outputs, strict schema
  extraction/pdf_layout.py        reading without Document Intelligence (text + images)
  extraction/llm_extractor.py     extraction + repair loop
  extraction/validators.py        consistency gates
  extraction/verify.py            cross-model verification
  extraction/reconciliation.py    rates, FX, over/undercharge
  extraction/pipeline.py          end to end; picks the paths the infra supports
  storage/repositories.py         SQL (Key Vault login or Entra), SQL status store, Blob
  ingestion/sharepoint.py         Graph delta sync
local/                            no-Azure adapters: SQLite, a folder, rules
evals/                            goldens + local_eval (CI gate on money_exact)
Dockerfile, docker/               the container
azure-pipelines.yml               test → eval gate → build/push latest-dev → restart app
scripts/preflight.py              can this laptop/identity use every resource?
scripts/map_terraform.py          infra pipeline log → .env
scripts/generate_sql_ddl.py       DDL from the registry
functions/                        optional Function App worker (not used by this infra)
infra/README.md                   what the app uses from the infra Terraform
docs/                             deployment, ADO mapping, security controls
```

## Configuration

Required, using either the legacy name or the TFA_ name:

- `AZURE_STORAGE_ACCOUNT_URL`
- `AZURE_OPENAI_STARTBURST_END_POINT`
- `SQL_SERVER`
- `SQL_DATABASE`

Defaults:

- `AZURE_OPENAI_STARTBURST_MODEL_NAME`: `gpt-4o`
- `AZURE_OPENAI_STARTBURST_API_VERSION`: `2024-10-21`

Optional:

- `AZURE_OPENAI_STARTBURST_API_KEY`, `SQL_USERNAME`, `SQL_PASSWORD`: when
  blank, the Entra token is used
- `TFA_SHAREPOINT_SITE_ID`, `TFA_SHAREPOINT_DRIVE_ID`
- `TFA_LLM_VERIFY_DEPLOYMENT`
- `TFA_DOCINTEL_ENDPOINT`, `TFA_COSMOS_ENDPOINT`: used only if they exist

The full list is in `.env.template`.

## Evaluation (LangSmith) & graph engine (LangGraph)

`evals/` is the model-bake-off harness. Label goldens as
`evals/golden/<name>.{pdf|xlsx|png}` + `<name>.expected.json` (five synthetic examples are included), push once with `python -m evals.run_eval push
--dataset tfa-goldens-v1`, then run one experiment per configuration
(provider × deployment × engine) and compare in the LangSmith UI on five
metrics defined in `evals/evaluators.py`:
`money_exact` (every cent exact — the metric that failed the POC),
`sum_check`, `doc_type_correct`, `field_accuracy`, and `review_routing`
(missing a needed review flag scores 0; over-flagging scores 0.5 — a
confident wrong answer is worse than a flagged one). Ship whichever config
wins `money_exact`; break ties on `review_routing`.

`TFA_EXTRACTION_ENGINE=graph` swaps the extract→validate→repair loop for a
LangGraph StateGraph (`src/tfa_core/graph/`) — functionally identical (same
prompt, schema, validators; proven by a scripted-LLM repair test), but every
attempt, verdict, and repair shows as a distinct traced node in LangSmith.

**Governance:** tracing is opt-in (`TFA_LANGSMITH_ENABLED=true`) and
redacting by default (`src/tfa_core/observability/tracing.py` — page images
never traced, long text hashed). Goldens contain Restricted data: point
`LANGSMITH_ENDPOINT` at a self-hosted LangSmith inside the VNet, or get
governance sign-off before any cloud endpoint.

## Running the tests

```bash
pip install -r requirements-dev.txt
PYTHONPATH=src:. pytest tests/ -q        # 83 passed
python -m evals.local_eval --min-money-exact 0.95
```
