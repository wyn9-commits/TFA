"""Gunicorn settings for the container.

One worker on purpose. The legacy app ran two, and because the document
processor lived inside the web process, the scheduled job ran twice and
raced itself on the tracking file. The processor still runs in-process here
(the Function App is the scaled-out path; this is the simple one), so there
is exactly one of it. Gunicorn threads give the UI concurrency instead.
"""
from os import environ

bind = f"0.0.0.0:{environ.get('PORT', '8501')}"
workers = 1
threads = int(environ.get("APP_THREADS", "8"))
worker_class = "gthread"
timeout = int(environ.get("APP_TIMEOUT", "300"))     # one document can take a minute
graceful_timeout = 30
keepalive = 5
worker_tmp_dir = "/dev/shm"
accesslog = "-"
errorlog = "-"
loglevel = environ.get("APP_LOGLEVEL", "info")
access_log_format = '%(h)s "%(r)s" %(s)s %(b)s %(L)ss'
