"""The two things that decide whether the money is right.

1. Identity. The same bytes re-uploaded must REPLACE rows, not add them.
   This is INCIDENT-2025-08: ETag-as-identity made three re-runs produce
   three rows and three times the overcharge.
2. Verification. A second model's disagreement must route to review; its
   agreement must not.
"""

from __future__ import annotations

import sys
from dataclasses import dataclass, field
from decimal import Decimal
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from tfa_core.domain.identity import compute_document_id, content_hash  # noqa: E402
from tfa_core.extraction.document_intelligence import DocumentLayout  # noqa: E402
from tfa_core.extraction.llm_extractor import ExtractionOutcome  # noqa: E402
from tfa_core.extraction.pipeline import FolioPipeline, RateContext, WorkItem  # noqa: E402
from tfa_core.extraction.reconciliation import FxRate, RateDirectory  # noqa: E402
from tfa_core.extraction.verify import CrossModelVerifier, should_verify  # noqa: E402
from tfa_core.schemas import DocumentType, FolioExtraction, NightlyCharge  # noqa: E402


# --------------------------------------------------------------------------- #
# Fakes
# --------------------------------------------------------------------------- #

class FakeBlobs:
    def __init__(self, files: dict[str, bytes]):
        self.files, self.etag_calls = files, 0

    def download(self, container, path):
        return self.files[path]


class FakeLayout:
    def analyze_pdf(self, content, name):
        return DocumentLayout(markdown_text="x", page_count=1)


def _extraction(total="300.00") -> FolioExtraction:
    return FolioExtraction(
        document_type=DocumentType.HOTEL_FOLIO, hotel_name="Hotel Prueba", country="Colombia",
        currency="COP", checkin_date="2026-02-01", checkout_date="2026-02-04",
        nightly_charges=[NightlyCharge(description="noche", english_description="night",
                                       amount=Decimal("100.00"), nights=3)],
        total_amount=Decimal(total),
    )


class FakeExtractor:
    def __init__(self, extraction=None):
        self.x = extraction or _extraction()

    def extract(self, layout, name):
        return ExtractionOutcome(extraction=self.x, attempts=1, warnings=[], needs_review=False)


class FakeSql:
    def __init__(self):
        self.rows: dict[str, list] = {}

    def upsert_document(self, document_id, records):
        self.rows[document_id] = list(records)       # delete-then-insert keyed on id
        return len(records)

    @property
    def total_rows(self):
        return sum(len(v) for v in self.rows.values())


class FakeStatus:
    def __init__(self):
        self.marks: list[dict] = []

    def mark(self, **kw):
        self.marks.append(kw)


def _pipeline(blobs, extractor=None, sql=None, status=None, verifier=None):
    return FolioPipeline(settings=object(), blobs=blobs, layout=FakeLayout(),
                         extractor=extractor or FakeExtractor(), sql=sql or FakeSql(),
                         status=status or FakeStatus(), verifier=verifier)


RATES = RateContext(directory=RateDirectory([]), fx_by_currency={"COP": FxRate("COP", Decimal("0.00025"))})


# --------------------------------------------------------------------------- #
# Identity
# --------------------------------------------------------------------------- #

def test_identity_is_the_bytes_not_the_name_or_metadata(tmp_path):
    a = content_hash(b"same bytes")
    assert a == content_hash(b"same bytes")
    assert a != content_hash(b"same bytes ")
    # Same bytes, same batch, same file name → same document, every time.
    assert compute_document_id("b1", "f.pdf", a) == compute_document_id("b1", "f.pdf", a)
    # Different batch or different name is a different document, by design.
    assert compute_document_id("b2", "f.pdf", a) != compute_document_id("b1", "f.pdf", a)
    assert len(compute_document_id("b1", "f.pdf", a)) == 32


def test_reprocessing_the_same_file_replaces_rows_instead_of_adding():
    """INCIDENT-2025-08. Three runs of one folio must leave one set of rows, not three."""
    blobs = FakeBlobs({"b1-ana/folio.pdf": b"%PDF same content"})
    sql, status = FakeSql(), FakeStatus()
    p = _pipeline(blobs, sql=sql, status=status)
    item = WorkItem(container="c", blob_path="b1-ana/folio.pdf", identifier="b1",
                    uploading_person_name="ana", file_name="folio.pdf")
    for _ in range(3):
        assert p.process(item, RATES) == "succeeded"
    assert len(sql.rows) == 1, "one document id across three runs"
    one_run = len(sql.rows[next(iter(sql.rows))])
    assert sql.total_rows == one_run, "rows after three runs equal rows after one"


def test_every_status_write_for_a_document_uses_one_id():
    """Previously the early marks used the bare content hash and the final
    mark used the derived id, leaving a second permanently-'processing' row."""
    blobs = FakeBlobs({"b1-ana/folio.pdf": b"%PDF"})
    status = FakeStatus()
    p = _pipeline(blobs, status=status)
    p.process(WorkItem("c", "b1-ana/folio.pdf", "b1", "ana", "folio.pdf"), RATES)
    ids = {m["document_id"] for m in status.marks}
    assert len(ids) == 1
    assert [m["status"] for m in status.marks] == ["processing", "succeeded"]


def test_byte_identical_resend_under_a_new_name_is_a_distinct_document():
    """A resend with a different file name is a different document on purpose:
    the row must say which file it came from. Content identity makes the two
    share a hash, not an id. Both outcomes are visible and auditable."""
    blobs = FakeBlobs({"b1-ana/a.pdf": b"%PDF", "b1-ana/a_resend.pdf": b"%PDF"})
    sql = FakeSql()
    p = _pipeline(blobs, sql=sql)
    p.process(WorkItem("c", "b1-ana/a.pdf", "b1", "ana", "a.pdf"), RATES)
    p.process(WorkItem("c", "b1-ana/a_resend.pdf", "b1", "ana", "a_resend.pdf"), RATES)
    assert len(sql.rows) == 2


# --------------------------------------------------------------------------- #
# Verification
# --------------------------------------------------------------------------- #

class SecondModel:
    def __init__(self, total):
        self.total = total

    def extract(self, **kw):
        return _extraction(total=self.total).model_dump(mode="json")


def _uncertain_outcome():
    x = _extraction(); x.low_confidence_fields = ["total_amount"]
    return ExtractionOutcome(extraction=x, attempts=1, warnings=[], needs_review=False)


def test_confident_extraction_is_not_verified_unless_always():
    layout = DocumentLayout(markdown_text="x", page_count=1, ocr_confidence_floor=0.99)
    sure = ExtractionOutcome(extraction=_extraction(), attempts=1, warnings=[], needs_review=False)
    assert should_verify(layout, sure, always=False) is None
    assert should_verify(layout, sure, always=True)
    assert should_verify(layout, _uncertain_outcome(), always=False)
    scan = DocumentLayout(markdown_text="x", page_count=1, ocr_confidence_floor=0.6)
    assert "OCR" in should_verify(scan, sure, always=False)


def test_second_model_agreement_clears_and_disagreement_routes_to_review():
    layout = DocumentLayout(markdown_text="x", page_count=1)
    agree = CrossModelVerifier(SecondModel("300.00")).verify(layout, "f.pdf", _uncertain_outcome())
    assert agree.agreed and not agree.needs_review

    within_tol = CrossModelVerifier(SecondModel("301.00"), tolerance=0.01).verify(layout, "f.pdf", _uncertain_outcome())
    assert within_tol.agreed

    disagree = CrossModelVerifier(SecondModel("3000.00")).verify(layout, "f.pdf", _uncertain_outcome())
    assert not disagree.agreed and disagree.needs_review
    assert "300.00 vs 3000.00" in disagree.warnings[0]


def test_verifier_failure_never_fails_the_document_but_routes_to_review():
    class Broken:
        def extract(self, **kw):
            raise RuntimeError("429")
    v = CrossModelVerifier(Broken()).verify(DocumentLayout("x", 1), "f.pdf", _uncertain_outcome())
    assert v.needs_review and "no usable reading" in v.warnings[0]


def test_pipeline_applies_the_verdict():
    blobs = FakeBlobs({"b1-ana/f.pdf": b"%PDF"})
    status = FakeStatus()
    x = _extraction(); x.low_confidence_fields = ["total_amount"]
    p = _pipeline(blobs, extractor=FakeExtractor(x), status=status,
                  verifier=CrossModelVerifier(SecondModel("9999.00")))
    assert p.process(WorkItem("c", "b1-ana/f.pdf", "b1", "ana", "f.pdf"), RATES) == "needs_review"
    assert "disagree" in status.marks[-1]["detail"]


# --------------------------------------------------------------------------- #
# The eval harness itself must keep working; a broken harness hides regressions
# --------------------------------------------------------------------------- #

def test_local_eval_scores_the_synthetic_goldens():
    import subprocess, sys as _sys
    root = Path(__file__).resolve().parents[1]
    r = subprocess.run([_sys.executable, "-m", "evals.local_eval", "--min-money-exact", "0.95"],
                       cwd=root, capture_output=True, text=True,
                       env={**__import__("os").environ, "PYTHONPATH": f"{root/'src'}:{root}"})
    assert r.returncode == 0, r.stdout + r.stderr
    assert "money_exact = 1.000" in r.stdout
