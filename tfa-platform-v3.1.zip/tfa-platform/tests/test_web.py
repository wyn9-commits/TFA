"""The web tier, against the local adapters. No Azure, no sign-in.

These are contract tests for the routes the UI calls. The legacy app had no
tests for any of this, which is how the Excel column map, the JS column
order and the SQL schema ended up as three different lists.
"""

from __future__ import annotations

import io
import os
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
sys.path.insert(0, str(ROOT))

os.environ["TFA_ENVIRONMENT"] = "local"
os.environ["TFA_PROCESSOR"] = "off"

from tfa_core.schemas import SQL_COLUMNS  # noqa: E402
from tfa_web.read_store import (export_filename, quarter_months,  # noqa: E402
                                year_quarter_of)
from tfa_web.services import blob_path_for, parse_rate_csv, person_slug  # noqa: E402

RATES = ("hotel_name,country,nightly_rate_usd\n"
         "Estelar Bogota,Colombia,115.20\nHilton Cartagena,Colombia,146.40\n"
         "Libertador Buenos Aires,Argentina,140.00\nCamino Real Villahermosa,Mexico,134.75\n")
FX = "currency,usd_per_unit\nARS,0.0008\nCOP,0.00024\nMXN,0.055\nUSD,1\n"


# --------------------------------------------------------------------------- #
# Pure functions
# --------------------------------------------------------------------------- #

def test_quarter_expands_to_three_months():
    assert quarter_months("2026-Q1") == ["2026-01", "2026-02", "2026-03"]
    assert quarter_months("2026-Q4") == ["2026-10", "2026-11", "2026-12"]
    with pytest.raises(ValueError):
        quarter_months("2026-Q5")
    with pytest.raises(ValueError):
        quarter_months("garbage")


def test_year_quarter_of_month():
    assert year_quarter_of("2026-02") == "2026-Q1"
    assert year_quarter_of("2026-12") == "2026-Q4"
    assert year_quarter_of(None) is None
    assert year_quarter_of("nope") is None


def test_export_filename_follows_filters():
    assert export_filename({}) == "Folio_data_complete_data.xlsx"
    assert export_filename({"identifier": "pilot_1", "country": "Costa Rica"}) == \
        "Folio_data_pilot_1_Costa-Rica.xlsx"


def test_blob_path_keeps_legacy_layout_and_rejects_traversal():
    assert blob_path_for("pilot_1", "Ana López", "folio.pdf") == "pilot_1-Ana_Lopez/folio.pdf"
    with pytest.raises(Exception):
        blob_path_for("../etc", "x", "folio.pdf")
    with pytest.raises(Exception):
        blob_path_for("pilot_1", "x", "../../passwd")
    assert person_slug("") == "unknown_user"


def test_rate_csv_headers_are_case_and_space_insensitive():
    rows = parse_rate_csv("Hotel Name,Country,Nightly Rate USD\nX,Y,1\n")
    assert rows == [{"hotel_name": "X", "country": "Y", "nightly_rate_usd": "1"}]


# --------------------------------------------------------------------------- #
# Routes
# --------------------------------------------------------------------------- #

@pytest.fixture
def client(tmp_path, monkeypatch):
    """A fresh app on a fresh SQLite file, with the inbox samples available."""
    import local.run_local as rl
    db = tmp_path / "t.db"
    monkeypatch.setattr(rl, "DB", db)
    import tfa_web.app as webapp
    monkeypatch.setattr(webapp, "ROOT", ROOT)

    # LocalBlobStore is rooted at local/blob; point it at tmp so tests never
    # touch the checked-in folder.
    from local import adapters
    real_init = adapters.LocalBlobStore.__init__

    def tmp_init(self, root):
        real_init(self, tmp_path / "blob")
    monkeypatch.setattr(adapters.LocalBlobStore, "__init__", tmp_init)

    app = webapp.create_app(local=True, start_processor=False)
    app.config["TESTING"] = True
    return app.test_client()


def _upload(client, identifier="pilot_2026", names=None):
    names = names or sorted(p.name for p in (ROOT / "local" / "inbox").glob("*.pdf"))
    files = [(open(ROOT / "local" / "inbox" / n, "rb"), n) for n in names]
    try:
        return client.post("/upload_files", data={"identifier": identifier, "filesToUpload[]": files},
                           content_type="multipart/form-data")
    finally:
        for f, _ in files:
            f.close()


def _rates(client):
    client.post("/rates", data={"kind": "rates", "file": (io.BytesIO(RATES.encode()), "r.csv")},
                content_type="multipart/form-data")
    client.post("/rates", data={"kind": "fx", "file": (io.BytesIO(FX.encode()), "f.csv")},
                content_type="multipart/form-data")


def test_health_and_dashboard(client):
    assert client.get("/health").status_code == 200
    r = client.get("/dashboard")
    assert r.status_code == 200
    for tab in (b"Upload Folios", b"Negotiated Rates", b"View Folios", b"Delete Folios"):
        assert tab in r.data


def test_identifier_validation_matches_core_rules(client):
    bad = client.post("/validate_identifier", json={"identifier": "Bad Name!"}).get_json()
    assert bad["is_valid"] is False
    ok = client.post("/validate_identifier", json={"identifier": "pilot_2026"}).get_json()
    assert ok["is_valid"] is True


def test_upload_rejects_bad_identifier_and_unsupported_type(client):
    r = client.post("/upload_files", data={"identifier": "Bad!",
                    "filesToUpload[]": [(io.BytesIO(b"x"), "a.pdf")]},
                    content_type="multipart/form-data")
    assert r.status_code == 400
    r = client.post("/upload_files", data={"identifier": "ok_1",
                    "filesToUpload[]": [(io.BytesIO(b"x"), "a.docx")]},
                    content_type="multipart/form-data")
    assert r.status_code == 400
    assert "Unsupported" in r.get_json()["results"][0]["message"]


def test_full_flow_upload_process_filter_export_delete(client):
    _rates(client)
    r = _upload(client)
    assert r.status_code == 200 and r.get_json()["uploaded_count"] == 6

    assert client.get("/status").get_json()["pending"] == 6
    res = client.post("/process_now").get_json()
    assert res["queued"] == 6 and res["failed"] == 0

    opts = client.get("/get_filter_options").get_json()
    assert "Colombia" in opts["countries"]
    assert "Estelar Bogota" in opts["hotels"]
    assert opts["year_quarters"] == ["2026-Q1"]

    # Every filter dimension must narrow the result.
    all_rows = client.get("/get_folio_data_for_filters?identifier=pilot_2026").get_json()["data"]
    assert len(all_rows) == 15
    assert set(all_rows[0]) >= set(SQL_COLUMNS) | {"id", "document_id"}
    by_country = client.get("/get_folio_data_for_filters?country=Colombia").get_json()["data"]
    assert 0 < len(by_country) < len(all_rows)
    by_month = client.get("/get_folio_data_for_filters?year_month=2026-02").get_json()["data"]
    assert 0 < len(by_month) < len(all_rows)
    assert client.get("/get_folio_data_for_filters").status_code == 400

    # Reconciliation happened: the rate card was matched and a variance found.
    matched = {r["matched_hotel_name"] for r in all_rows} - {None}
    assert "Estelar Bogota" in matched
    assert any(r["issue_found"] == "Yes" for r in all_rows)

    # Excel: two sheets, the registry's headers, one row per line.
    import openpyxl
    x = client.get("/download_folio_data_for_filters?identifier=pilot_2026")
    assert x.status_code == 200
    wb = openpyxl.load_workbook(io.BytesIO(x.data))
    assert wb.sheetnames == ["Column Definitions", "FolioData"]
    assert wb["FolioData"].max_row - 1 == 15
    assert wb["FolioData"]["A1"].value == "File Name"

    # Source file comes back by row id, not by path from the URL.
    pdf = client.get(f"/download_folio/{all_rows[0]['id']}")
    assert pdf.status_code == 200 and pdf.mimetype == "application/pdf"
    assert client.get("/download_folio/999999").status_code == 404

    # Deleting one line removes the whole document.
    first_doc = all_rows[0]["document_id"]
    lines_in_doc = sum(1 for r in all_rows if r["document_id"] == first_doc)
    d = client.post("/delete_folios", json={"folio_ids": [all_rows[0]["id"]]}).get_json()
    assert d["deleted_count"] == lines_in_doc and d["documents"] == 1
    left = client.get("/get_folio_data_for_filters?identifier=pilot_2026").get_json()["data"]
    assert len(left) == 15 - lines_in_doc
    assert all(r["document_id"] != first_doc for r in left)


def test_identifier_cannot_be_reused_once_data_exists(client):
    _upload(client, names=["co_hilton_cartagena_dian.pdf"])
    client.post("/process_now")
    r = client.post("/validate_identifier", json={"identifier": "pilot_2026"}).get_json()
    assert r["is_valid"] is False and "already exists" in r["message"]
    r = _upload(client, names=["co_hilton_cartagena_dian.pdf"])
    assert r.status_code == 400


def test_rates_round_trip_and_validation(client):
    assert client.get("/rates").get_json() == {"rates": [], "fx": []}
    _rates(client)
    got = client.get("/rates").get_json()
    assert len(got["rates"]) == 4 and got["rates"][0]["nightly_rate_usd"] == "115.20"
    assert {f["currency"] for f in got["fx"]} == {"ARS", "COP", "MXN", "USD"}

    bad = client.post("/rates", data={"kind": "rates",
                      "file": (io.BytesIO(b"hotel_name,nightly_rate_usd\nX,-1\n"), "r.csv")},
                      content_type="multipart/form-data")
    assert bad.status_code == 400 and "positive" in bad.get_json()["message"]
    # A rejected upload must not have replaced the card.
    assert len(client.get("/rates").get_json()["rates"]) == 4


def test_security_headers_present(client):
    r = client.get("/dashboard")
    assert r.headers["X-Frame-Options"] == "DENY"
    assert "frame-ancestors 'none'" in r.headers["Content-Security-Policy"]


# --------------------------------------------------------------------------- #
# SharePoint → blob → queue → rows, inside the web app, with no Function App
# --------------------------------------------------------------------------- #

class FakeGraph:
    """Stands in for SharePointSource: a library with two folders. The delta
    link advances so the second call returns nothing new, like Graph does."""

    def __init__(self, items):
        self.items, self.calls = items, 0

    def delta(self, delta_link):
        self.calls += 1
        return (self.items if delta_link is None else []), f"delta-{self.calls}"

    def download(self, item):
        return (ROOT / "local" / "inbox" / item.name).read_bytes()


def _sp_items():
    from tfa_core.ingestion.sharepoint import SharePointItem
    return [
        SharePointItem(item_id="i1", etag="e1", name="co_hilton_cartagena_dian.pdf",
                       identifier="colombia_2026", uploader="Maria Perez", size=1, download_url="x"),
        SharePointItem(item_id="i2", etag="e2", name="ar_libertador_facturab.pdf",
                       identifier="argentina_2026", uploader="Juan Gomez", size=1, download_url="x"),
    ]


@pytest.fixture
def sp_client(tmp_path, monkeypatch):
    import local.run_local as rl
    monkeypatch.setattr(rl, "DB", tmp_path / "t.db")
    import tfa_web.app as webapp
    monkeypatch.setattr(webapp, "ROOT", ROOT)
    from local import adapters
    real_init = adapters.LocalBlobStore.__init__
    monkeypatch.setattr(adapters.LocalBlobStore, "__init__", lambda self, root: real_init(self, tmp_path / "blob"))

    svc = webapp.build_services(local=True)
    from tfa_core.ingestion.sharepoint import SharePointSyncState
    svc.sharepoint_source = FakeGraph(_sp_items())
    svc.sharepoint_state = SharePointSyncState(adapters.SqliteKvContainer(tmp_path / "t.db"))
    svc.processor.sharepoint_source = svc.sharepoint_source
    svc.processor.sharepoint_state = svc.sharepoint_state
    app = webapp.create_app(local=True, services=svc, start_processor=False)
    app.config["TESTING"] = True
    return app.test_client(), svc


def test_sharepoint_sync_queues_and_processes_without_event_grid(sp_client):
    client, svc = sp_client
    _rates(client)
    assert client.get("/status").get_json()["sharepoint"]["enabled"] is True

    first = client.post("/sync_now").get_json()
    assert first == {"ingested": 2, "queued": 2, "skipped": 0, "deleted_flagged": 0, "errors": 0}
    assert client.get("/status").get_json()["pending"] == 2

    # A second pass is a no-op: the delta link moved on and the eTags are known.
    second = client.post("/sync_now").get_json()
    assert second["ingested"] == 0 and second["queued"] == 0

    done = client.post("/process_now").get_json()
    assert done["queued"] == 2 and done["failed"] == 0

    opts = client.get("/get_filter_options").get_json()
    assert set(opts["identifiers"]) == {"colombia_2026", "argentina_2026"}
    rows = client.get("/get_folio_data_for_filters?identifier=argentina_2026").get_json()["data"]
    assert rows and rows[0]["uploading_person_name"] == "Juan Gomez"
    assert rows[0]["matched_hotel_name"] == "Libertador Buenos Aires"

    # The file is reachable from the row even though it lives under the
    # SharePoint layout (<identifier>/<file>), not the upload layout.
    assert client.get(f"/download_folio/{rows[0]['id']}").status_code == 200


def test_sync_now_refuses_when_not_configured(client):
    r = client.post("/sync_now")
    assert r.status_code == 400 and "not configured" in r.get_json()["error"]
