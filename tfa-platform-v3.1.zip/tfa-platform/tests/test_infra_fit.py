"""The pieces that make the app fit the infra Terraform actually provides.

The infra has: gpt-4o on Azure OpenAI, blob storage, Azure SQL with the
SQLAdmin login in Key Vault, App Service with App Service Authentication,
and the legacy app's setting names. It has no Document Intelligence, no
storage queue and (in dev) no Cosmos. Each test below pins one of those.
"""

from __future__ import annotations

import base64
import json
import sqlite3
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from tfa_core.schemas import FolioExtraction  # noqa: E402

LEGACY_ENV = {
    "AZURE_STORAGE_ACCOUNT_URL": "https://acct.blob.core.windows.net",
    "AZURE_OPENAI_STARTBURST_END_POINT": "https://travel-res.openai.azure.com/",
    "AZURE_OPENAI_STARTBURST_MODEL_NAME": "gpt-4o",
    "AZURE_OPENAI_STARTBURST_API_VERSION": "2024-10-21",
    "AZURE_OPENAI_STARTBURST_API_KEY": "k-123",
    "SQL_SERVER": "srv.database.windows.net",
    "SQL_DATABASE": "tfa",
    "SQL_USERNAME": "SQLAdmin",
    "SQL_PASSWORD": "p}w",
    "USER_ASSIGNED_CLIENT_ID": "00000000-0000-0000-0000-000000000001",
}


def _clear_tfa(monkeypatch):
    import os
    for k in list(os.environ):
        if k.startswith("TFA_") or k in LEGACY_ENV:
            monkeypatch.delenv(k, raising=False)


# --------------------------------------------------------------------------- #
# Settings: the legacy names resolve, and absent resources switch paths
# --------------------------------------------------------------------------- #

def test_legacy_setting_names_resolve(monkeypatch):
    _clear_tfa(monkeypatch)
    for k, v in LEGACY_ENV.items():
        monkeypatch.setenv(k, v)
    from tfa_core.config import Settings
    s = Settings(_env_file=None)
    assert s.storage_account_url == LEGACY_ENV["AZURE_STORAGE_ACCOUNT_URL"]
    assert s.llm_endpoint.startswith("https://travel-res")
    assert s.llm_deployment == "gpt-4o"
    assert s.llm_api_key == "k-123"
    assert (s.sql_username, s.sql_password) == ("SQLAdmin", "p}w")
    assert s.user_assigned_client_id.endswith("01")
    # The infra has none of these, so the app must take the other paths.
    assert not s.use_docintel and not s.use_cosmos
    assert s.queue_account_url is None


def test_tfa_names_win_over_nothing_and_default_model_is_gpt4o(monkeypatch):
    _clear_tfa(monkeypatch)
    monkeypatch.setenv("TFA_STORAGE_ACCOUNT_URL", "https://a.blob.core.windows.net")
    monkeypatch.setenv("TFA_LLM_ENDPOINT", "https://x.openai.azure.com")
    monkeypatch.setenv("TFA_SQL_SERVER", "s")
    monkeypatch.setenv("TFA_SQL_DATABASE", "d")
    from tfa_core.config import Settings
    s = Settings(_env_file=None)
    assert s.llm_deployment == "gpt-4o"
    assert s.llm_api_key is None


# --------------------------------------------------------------------------- #
# Strict structured outputs: Azure rejects a schema that breaks strict rules
# --------------------------------------------------------------------------- #

def _walk(node, fn, path="$"):
    if isinstance(node, dict):
        fn(node, path)
        for k, v in node.items():
            _walk(v, fn, f"{path}.{k}")
    elif isinstance(node, list):
        for i, v in enumerate(node):
            _walk(v, fn, f"{path}[{i}]")


def test_strict_schema_meets_azure_openai_strict_mode_rules():
    from tfa_core.llm.provider import to_strict_schema
    strict = to_strict_schema(FolioExtraction.model_json_schema())
    problems: list[str] = []

    def check(node, path):
        if path.endswith(".properties"):
            return                                    # field names, not keywords
        if "$ref" in node or "$defs" in node:
            problems.append(f"{path}: $ref/$defs left in")
        for banned in ("default", "minimum", "maximum", "pattern", "format",
                       "minLength", "maxLength", "minItems", "maxItems"):
            if banned in node:
                problems.append(f"{path}: '{banned}' not allowed")
        if node.get("type") == "object" or "properties" in node:
            props = set(node.get("properties", {}))
            if set(node.get("required", [])) != props:
                problems.append(f"{path}: required != properties")
            if node.get("additionalProperties") is not False:
                problems.append(f"{path}: additionalProperties must be false")

    _walk(strict, check)
    assert not problems, "\n".join(problems[:20])
    # Nothing the model must return was dropped on the way.
    assert set(strict["properties"]) == set(FolioExtraction.model_fields)


# --------------------------------------------------------------------------- #
# The request the app sends to the infra's gpt-4o deployment
# --------------------------------------------------------------------------- #

class _Resp:
    def __init__(self, status=200, body=None, text=""):
        self.status_code, self._body, self.text = status, body, text

    def json(self):
        return self._body


def _capture(monkeypatch, resp):
    sent = {}

    class Client:
        def __init__(self, **kw): pass
        def __enter__(self): return self
        def __exit__(self, *a): return False

        def post(self, url, headers, json):
            sent.update(url=url, headers=headers, body=json)
            return resp

    import tfa_core.llm.provider as prov
    monkeypatch.setattr(prov.httpx, "Client", Client)
    return sent


def _ok(content='{"a": 1}', finish="stop"):
    return _Resp(200, {"choices": [{"finish_reason": finish, "message": {"content": content}}]})


def test_gpt4o_request_uses_key_max_tokens_and_zero_temperature(monkeypatch):
    from tfa_core.llm.provider import AzureOpenAIStructuredLLM
    sent = _capture(monkeypatch, _ok())
    llm = AzureOpenAIStructuredLLM("https://travel-res.openai.azure.com/", "gpt-4o", "2024-10-21",
                                   credential=None, api_key="k-123")
    assert llm.extract("sys", [{"type": "text", "text": "x"}], {"type": "object", "properties": {}},
                       "s", 32000) == {"a": 1}
    assert sent["headers"] == {"api-key": "k-123"}
    assert "/deployments/gpt-4o/" in sent["url"] and "api-version=2024-10-21" in sent["url"]
    assert sent["body"]["max_tokens"] == 16384          # capped at gpt-4o's ceiling
    assert sent["body"]["temperature"] == 0
    assert "max_completion_tokens" not in sent["body"]
    assert sent["body"]["response_format"]["json_schema"]["strict"] is True


def test_reasoning_model_request_uses_max_completion_tokens(monkeypatch):
    from tfa_core.llm.provider import AzureOpenAIStructuredLLM

    class Cred:
        def get_token(self, scope):
            return type("T", (), {"token": "tok"})()
    sent = _capture(monkeypatch, _ok())
    AzureOpenAIStructuredLLM("https://x", "gpt-5.1", "2025-04-01-preview", Cred()).extract(
        "s", [], {"type": "object", "properties": {}}, "n", 20000)
    assert sent["headers"]["Authorization"] == "Bearer tok"
    assert sent["body"]["max_completion_tokens"] == 20000
    assert "temperature" not in sent["body"] and "max_tokens" not in sent["body"]


@pytest.mark.parametrize("resp, needle", [
    (_Resp(404, text='{"error":{"code":"DeploymentNotFound"}}'), "DeploymentNotFound"),
    (_ok(finish="length"), "token limit"),
    (_Resp(200, {"choices": [{"finish_reason": "stop", "message": {"content": None, "refusal": "no"}}]}), "no content"),
])
def test_azure_errors_surface_with_their_reason(monkeypatch, resp, needle):
    from tfa_core.llm.provider import AzureOpenAIStructuredLLM
    _capture(monkeypatch, resp)
    with pytest.raises(RuntimeError, match=needle):
        AzureOpenAIStructuredLLM("https://x", "gpt-4o", "v", None, api_key="k").extract(
            "s", [], {"type": "object", "properties": {}}, "n", 100)


# --------------------------------------------------------------------------- #
# Reading without Document Intelligence
# --------------------------------------------------------------------------- #

def test_pdf_vision_layout_reads_text_and_renders_pages():
    pytest.importorskip("fitz")
    from tfa_core.extraction.pdf_layout import PdfVisionLayout
    pdf = ROOT / "local" / "inbox" / "co_estelar_bogota_dian.pdf"
    layout = PdfVisionLayout(render_dpi=100).analyze_pdf(pdf.read_bytes(), pdf.name)
    assert layout.page_count >= 1
    assert "--- page 1 ---" in layout.markdown_text
    assert len(layout.markdown_text) > 200, "born-digital PDF must yield its text layer"
    assert layout.ocr_confidence_floor == 1.0
    png = base64.b64decode(layout.page_images_b64[0])
    assert png[:8] == b"\x89PNG\r\n\x1a\n"


def test_pdf_vision_layout_caps_images_but_keeps_all_text():
    fitz = pytest.importorskip("fitz")
    from tfa_core.extraction.pdf_layout import PdfVisionLayout
    doc = fitz.open()
    for i in range(5):
        doc.new_page().insert_text((72, 72), f"Hotel line page {i + 1} " + "x" * 60)
    doc.new_page()                                     # a blank "scanned" page
    layout = PdfVisionLayout(render_dpi=50, max_images=2).analyze_pdf(doc.tobytes(), "t.pdf")
    assert layout.page_count == 6
    assert all(f"--- page {i} ---" in layout.markdown_text for i in range(1, 7))
    assert len(layout.page_images_b64) == 2
    assert layout.ocr_confidence_floor == round(5 / 6, 2)   # < 0.85 → verifier would run


def test_build_layout_picks_pdf_vision_when_no_docintel(monkeypatch):
    _clear_tfa(monkeypatch)
    for k, v in LEGACY_ENV.items():
        monkeypatch.setenv(k, v)
    from tfa_core.config import Settings
    from tfa_core.extraction.pdf_layout import PdfVisionLayout
    from tfa_core.extraction.pipeline import build_layout
    assert isinstance(build_layout(Settings(_env_file=None), None), PdfVisionLayout)


# --------------------------------------------------------------------------- #
# Status + SharePoint state in SQL when there is no Cosmos
# --------------------------------------------------------------------------- #

def _sqlite(tmp_path):
    db = tmp_path / "s.db"
    return lambda: sqlite3.connect(db)


def test_sql_status_store_upserts_one_row_per_document(tmp_path):
    from tfa_core.storage.repositories import SqlStatusRepository
    st = SqlStatusRepository(_sqlite(tmp_path), dialect="sqlite")
    st.mark(document_id="d1", identifier="b1", file_name="f.pdf", status="queued")
    st.mark(document_id="d1", identifier="b1", file_name="f.pdf", status="processing", attempts=1)
    st.mark(document_id="d2", identifier="b1", file_name="g.pdf", status="queued")
    assert st.get("d1")["status"] == "processing"
    assert {r["document_id"] for r in st.pending_all()} == {"d1", "d2"}
    st.mark(document_id="d1", identifier="b1", file_name="f.pdf", status="succeeded", detail="ok")
    assert [r["document_id"] for r in st.pending_all()] == ["d2"]
    assert len(st.recent(10)) == 2
    # Re-opening must not fail on existing tables.
    SqlStatusRepository(_sqlite(tmp_path), dialect="sqlite")


def test_sharepoint_sync_state_works_on_the_sql_container(tmp_path):
    from tfa_core.ingestion.sharepoint import SharePointSyncState
    from tfa_core.storage.repositories import SqlStatusRepository
    state = SharePointSyncState(SqlStatusRepository(_sqlite(tmp_path), dialect="sqlite").container)
    assert state.get_delta_link() is None
    state.save_delta_link("https://graph/delta?token=1")
    state.save_delta_link("https://graph/delta?token=2")
    assert state.get_delta_link() == "https://graph/delta?token=2"


def test_sql_connector_uses_the_key_vault_login_when_given():
    from tfa_core.storage.repositories import sql_connector
    assert sql_connector("s", "d", None, "SQLAdmin", "pw").auth == "sql-login"
    assert sql_connector("s", "d", object()).auth == "entra-token"


def test_ddl_script_emits_status_tables():
    import subprocess
    r = subprocess.run([sys.executable, "scripts/generate_sql_ddl.py"], cwd=ROOT,
                       capture_output=True, text=True)
    assert r.returncode == 0, r.stderr
    assert "tfa_processing_status" in r.stdout and "tfa_kv" in r.stdout


# --------------------------------------------------------------------------- #
# App Service Authentication (configured in the infra's auth_settings)
# --------------------------------------------------------------------------- #

def _principal(email, groups=()):
    claims = [{"typ": "name", "val": "Ana López"},
              {"typ": "preferred_username", "val": email}]
    claims += [{"typ": "groups", "val": g} for g in groups]
    return base64.b64encode(json.dumps({"claims": claims}).encode()).decode()


def _easy_auth_app(monkeypatch, tmp_path, **env):
    """The real app with local storage behind it, but sign-in NOT in local
    mode — exactly what App Service runs, minus Azure."""
    import local.run_local as rl
    import tfa_web.app as webapp
    from local import adapters
    monkeypatch.setattr(rl, "DB", tmp_path / "t.db")
    real_init = adapters.LocalBlobStore.__init__
    monkeypatch.setattr(adapters.LocalBlobStore, "__init__",
                        lambda self, root: real_init(self, tmp_path / "blob"))
    services = webapp.build_services(local=True)
    for k in ("TFA_AUTH_MODE", "WEBSITE_AUTH_ENABLED", "TFA_ALLOWED_EMAILS", "ALLOWED_EMAILS",
              "TFA_ALLOWED_GROUP_ID", "TFA_SESSION_SECRET", "FLASK_SECRET_KEY"):
        monkeypatch.delenv(k, raising=False)
    for k, v in env.items():
        monkeypatch.setenv(k, v)
    return webapp.create_app(local=False, services=services, start_processor=False)


def test_easy_auth_admits_allow_listed_user(monkeypatch, tmp_path):
    app = _easy_auth_app(monkeypatch, tmp_path, WEBSITE_AUTH_ENABLED="True",
                         ALLOWED_EMAILS="ana@corp.com; bo@corp.com", FLASK_SECRET_KEY="s")
    c = app.test_client()
    r = c.get("/status", headers={"X-MS-CLIENT-PRINCIPAL-NAME": "Ana@corp.com",
                                  "X-MS-CLIENT-PRINCIPAL": _principal("ana@corp.com")})
    assert r.status_code == 200


def test_easy_auth_denies_user_not_on_the_list(monkeypatch, tmp_path):
    app = _easy_auth_app(monkeypatch, tmp_path, WEBSITE_AUTH_ENABLED="True",
                         ALLOWED_EMAILS="ana@corp.com", FLASK_SECRET_KEY="s")
    c = app.test_client()
    eve = {"X-MS-CLIENT-PRINCIPAL-NAME": "eve@corp.com"}
    assert c.get("/status", headers=eve).status_code == 403
    # Form posts and downloads are refused too, not only JSON routes.
    assert c.post("/validate_identifier", data={"identifier": "x"}, headers=eve).status_code == 403
    page = c.get("/dashboard", headers=eve)
    assert page.status_code == 200 and b"ccess denied" in page.data


def test_easy_auth_admits_by_group(monkeypatch, tmp_path):
    app = _easy_auth_app(monkeypatch, tmp_path, TFA_AUTH_MODE="appservice", TFA_ALLOWED_GROUP_ID="g-1",
                         TFA_SESSION_SECRET="s")
    r = app.test_client().get("/status", headers={
        "X-MS-CLIENT-PRINCIPAL-NAME": "zoe@corp.com",
        "X-MS-CLIENT-PRINCIPAL": _principal("zoe@corp.com", groups=["g-0", "g-1"])})
    assert r.status_code == 200


def test_principal_headers_are_ignored_when_app_service_auth_is_off(monkeypatch, tmp_path):
    """Off App Service nothing strips client-sent X-MS-* headers, so a
    request carrying them must not be signed in by them."""
    app = _easy_auth_app(monkeypatch, tmp_path, ALLOWED_EMAILS="ana@corp.com", FLASK_SECRET_KEY="s",
                         CLIENT_ID="c", CLIENT_SECRET="x", TENANT_ID="t")
    r = app.test_client().get("/status", headers={"X-MS-CLIENT-PRINCIPAL-NAME": "ana@corp.com"})
    assert r.status_code == 302 and "/login" in r.headers["Location"]   # sent to sign in, not admitted


def test_app_refuses_to_start_without_an_allow_list(monkeypatch, tmp_path):
    with pytest.raises(RuntimeError, match="allow-list"):
        _easy_auth_app(monkeypatch, tmp_path, WEBSITE_AUTH_ENABLED="True", FLASK_SECRET_KEY="s")


def test_app_refuses_to_start_without_a_session_secret(monkeypatch, tmp_path):
    with pytest.raises(RuntimeError, match="FLASK_SECRET_KEY"):
        _easy_auth_app(monkeypatch, tmp_path, WEBSITE_AUTH_ENABLED="True", ALLOWED_EMAILS="a@b.c")


# --------------------------------------------------------------------------- #
# .env reading must not damage secrets
# --------------------------------------------------------------------------- #

def test_env_file_keeps_hashes_in_secrets_and_drops_comments(tmp_path, monkeypatch):
    from tfa_core.envfile import load_env_file
    for k in ("A_PW", "A_MODEL", "A_Q", "A_BLANK"):
        monkeypatch.delenv(k, raising=False)
    f = tmp_path / ".env"
    f.write_text("A_PW=p#ss=w0rd\nA_MODEL=gpt-4o   # deployment\nA_Q=\"x # y\"\nA_BLANK=\n# c=1\n",
                 encoding="utf-8")
    load_env_file(f)
    import os
    assert os.environ["A_PW"] == "p#ss=w0rd"
    assert os.environ["A_MODEL"] == "gpt-4o"
    assert os.environ["A_Q"] == "x # y"
    assert "A_BLANK" not in os.environ


# --------------------------------------------------------------------------- #
# The live wiring, built from the infra's settings (no network needed)
# --------------------------------------------------------------------------- #

def test_live_services_wire_to_what_the_infra_has(monkeypatch):
    pytest.importorskip("azure.storage.blob")
    pytest.importorskip("azure.identity")
    _clear_tfa(monkeypatch)
    for k, v in LEGACY_ENV.items():
        monkeypatch.setenv(k, v)
    monkeypatch.setenv("TFA_ENVIRONMENT", "dev")
    from tfa_core.config import get_settings
    get_settings.cache_clear() if hasattr(get_settings, "cache_clear") else None
    import tfa_web.app as webapp
    from tfa_web.read_store import SqlServerReadStore
    try:
        svc = webapp.build_services(local=False)
    finally:
        get_settings.cache_clear() if hasattr(get_settings, "cache_clear") else None
    assert isinstance(svc.read, SqlServerReadStore)
    assert "gpt-4o" in svc.mode and "PDF text + page images" in svc.mode
    assert "status in SQL" in svc.mode and "sql-login" in svc.mode


def test_status_tables_are_created_once_sql_becomes_reachable(tmp_path):
    from tfa_core.storage.repositories import SqlStatusRepository
    up = {"ok": False}
    real = _sqlite(tmp_path)

    def flaky():
        if not up["ok"]:
            raise ConnectionError("SQL not reachable yet")
        return real()
    st = SqlStatusRepository(flaky, dialect="sqlite")     # boot: SQL down, must not raise
    up["ok"] = True
    st.mark(document_id="d", identifier="b", file_name="f", status="queued")
    assert st.get("d")["status"] == "queued"
