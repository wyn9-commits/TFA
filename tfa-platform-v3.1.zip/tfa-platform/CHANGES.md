# What changed

## 21 October 2026 — v3.1: fitted to the infra Terraform as it actually is

Checked against the infra repo's tfvars and templates. The app now runs on
exactly what is deployed and asks for nothing new.

| The infra has / lacks | v3.1 does |
|---|---|
| **No Document Intelligence** | `extraction/pdf_layout.py`: the PDF's own text layer for every page, plus 200-dpi images of up to 8 pages, all sent to gpt-4o. This is more than the POC's single 150-dpi image of page 1. Document Intelligence is still used automatically if an endpoint is ever configured. |
| **gpt-4o only** (2024-11-20) | Default deployment is `gpt-4o`. The request uses `max_tokens` (capped at 16384) and `temperature` 0. Reasoning models get `max_completion_tokens`. |
| Strict structured outputs | `to_strict_schema()`. **The schema as Pydantic emits it would have been refused with a 400 on the first real call:** optional fields not required, `$ref`, `default`, `format`. Now every object is closed, every property required (nullable where optional), and unsupported keywords are stripped without dropping any field. A test checks it against Azure's rules. |
| **No Cosmos** (dev) | Status and SharePoint sync state live in two SQL tables (`tfa_processing_status`, `tfa_kv`). The app creates them, retrying if SQL isn't reachable at boot. |
| **No queue, Event Grid or Function App** | Unchanged from v3: the web app processes and syncs in-process. `functions/` is marked optional and no longer needs Cosmos. |
| **SQL login in Key Vault** (`mssql_server_username` / `_password`) | `sql_connector()`: uses the login when one is set, otherwise the Entra token. Writer, reader, status store and preflight all share it. |
| **Legacy setting names** on the App Service | Accepted everywhere: `AZURE_OPENAI_STARTBURST_*`, `SQL_*`, `AZURE_STORAGE_ACCOUNT_URL`, `USER_ASSIGNED_CLIENT_ID`, `ALLOWED_EMAILS`, `FLASK_SECRET_KEY`, `CLIENT_ID` / `CLIENT_SECRET` / `TENANT_ID`. |
| **App Service Authentication** on | App Service signs users in, and the app enforces `ALLOWED_EMAILS` or the group. It trusts the identity headers only when App Service says auth is on. Otherwise sign-in goes through MSAL, as before. |
| Image pinned to `latest-dev` by Terraform | The pipeline pushes `latest-dev` and restarts the app. It no longer sets a new image tag, which Terraform would revert. |

### Bugs found and fixed while doing this

- **Allow-list gap (security).** A user who was signed in but not on the
  allow-list could still call every route not under `/api/`. That covered
  `/status`, uploads, exports, rates and deletes, which all sit at the root
  in this app. Now every route except the access-denied page returns 403.
  This gap was inherited from the legacy design. Tests cover form posts, not
  only JSON.
- **Live path crashed at start:** `BlobRepository` used `BlobServiceClient`
  without importing it. Local mode and the tests never reached it. A test now
  builds the live wiring from the infra's settings.
- `.env` reading cut values at the first `#`, which would truncate a password
  containing one. Now only ` #` after whitespace starts a comment, and quoted
  values are literal (`tfa_core/envfile.py`).
- `local/run_local.py` referenced an undefined `api_version` in hybrid mode.
- Preflight required Document Intelligence, the queue and Cosmos, and warned
  that a SQL password was "unused". It now checks only what is configured and
  reports which paths the app will take.
- `map_terraform.py` treated the missing Document Intelligence, Cosmos, queue
  and Event Grid as gaps. It now recognises the OpenAI account by its
  deployments (`travel-res`) and writes `.env` in the legacy names.

Tests: 59 → **83**, all passing. The new ones are in `tests/test_infra_fit.py`.

## 21 October 2026 — v3: one package, Terraform-owned infrastructure, the web app, SharePoint in-process, cross-model verification

Built on the **v2 Rebuild** — the tree that has been running on the client
laptop — because it was green (36/36) and trusted. Everything below is
additive to it except one correction that changes stored data.

### The correction: document identity (INCIDENT-2025-08)

`storage/repositories.py` keyed a document's identity on the blob's
`content_md5` and fell back to its ETag. The SDK only sets `content_md5` when
the uploader supplies it, and ours did not, so the ETag branch was the only
branch ever taken. An ETag changes on every write, including an overwrite
with identical bytes. The delete-then-insert that was supposed to make
re-processing safe was therefore keyed on a value that changed every time:
three re-runs produced three sets of rows and three times the overcharge.

Identity now comes from the bytes (`domain/identity.py`). `download()`
returns content only; metadata is not offered to callers. Every status write
for a document uses the one id. `tests/test_identity_and_verify.py` proves
three runs leave one set of rows.

**Existing rows written by v2 may be duplicated.** Before trusting any
total from a v2 database, run `db/migrations/001_dedupe_incident_2025_08.sql`
(or dedupe on `(identifier_name, file_name)` keeping the latest
`ingested_at_utc`) against a restored copy first.

### Added

- **`src/tfa_web/`** — the five-tab web application the team uses (Home,
  Upload, Negotiated Rates, View, Delete), with Entra sign-in and a group
  allow-list, on top of `tfa_core`. Same routes, blob layout and two-sheet
  Excel as the POC. Negotiated Rates is real (upload a CSV); View/Delete
  have the six filters; delete is by document. 14 tests.
- **SharePoint sync inside the web app.** The processor checks the library
  every 5 minutes (configurable, or *Check SharePoint now* on Home) using the
  existing `ingestion/sharepoint.py`, writes new files to the raw container,
  queues and processes them. No Function App and no Event Grid are needed
  for a library drop to become a row. The Function App path still exists
  and still works for scale-out. `SyncResult` now reports what it ingested.
- **Cross-model verification** (`extraction/verify.py`). When the primary
  model flags low confidence on money or date fields, needed more than one
  attempt, the validators warned about totals, or the OCR floor is low, a
  second model from a different family re-reads the document cold. Money
  fields must agree within `TFA_LLM_VERIFY_TOLERANCE` (1%); disagreement
  routes to review with both readings. `TFA_LLM_VERIFY_ALWAYS=true` verifies
  everything. Off unless `TFA_LLM_VERIFY_DEPLOYMENT` is set. The verifier can
  never fail a document; if it cannot read, the document goes to review.
- **`evals/local_eval.py`** — scores goldens with no LangSmith; `--azure`
  runs the real stack; `--min-money-exact` is a CI gate. Five synthetic
  goldens (ground truth by construction) exercise the harness on every
  build and already caught one regression (invoice numbers read as
  "ELECTRONICA"). They say nothing about accuracy on real folios; label
  20–50 real documents and run `--azure` for the number that matters.
- **`local/`** — SQLite, a folder, PyMuPDF and rules, so the whole platform
  runs with no Azure. `start.py` / `start.bat` / `start.sh` create a venv,
  check the machine, and open the web app in whichever mode can work.
- **`infra/README.md`** — the contract the Terraform must satisfy (resources,
  roles for the UAMI and the Entra group, app settings, security properties).
  The Bicep modules are gone: the organisation's Terraform owns provisioning
  and two IaC tools on one resource group is how drift happens.
- **`Dockerfile`, `docker/`, `azure-pipelines.yml`** — the container, built
  and deployed on the legacy app's path: same ACR, App Service, agent pool
  and service connections, so nothing in ADO is created. pytest and the eval
  gate run before the build.
- **`scripts/preflight.py`** — classifies every failure as NETWORK / LOGIN /
  AUTH / CONFIG / SCHEMA and says who fixes it. **`scripts/map_terraform.py`**
  — derives `.env` and a contract checklist from the Terraform pipeline log
  in ADO, for people with no portal access.
- `FolioPipeline` takes its collaborators by injection; `from_settings()` is
  the production wiring. `functions/function_app.py` uses it.
- `domain/rules.py` — identifier and filename validation shared by the web
  app and the pipeline.

### Not done, on purpose

- No Terraform was written; the resources exist and are owned elsewhere.
- The container has not been built here (no Docker in this environment);
  the Dockerfile is reviewed, not run. The first pipeline run is the test.
- Search-by-Prompt (a placeholder in the POC) was not built.
- The "better model" is a configuration choice, not a code change: set
  `TFA_LLM_DEPLOYMENT` to the strongest deployment you have and
  `TFA_LLM_VERIFY_DEPLOYMENT` to one from another family. The code does not
  pick a model for you, because the deployments that exist are the
  Terraform's decision.
