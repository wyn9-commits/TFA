#!/usr/bin/env python3
"""Preflight — can this identity, from this network, do what the pipeline does?

    az login
    python scripts/preflight.py

Exit code 0 = every required resource is reachable and authorised.
Exit code 1 = something is missing, and the report says what and who fixes it.

This is the check for someone whose access comes through an Entra group rather
than a subscription role. It never calls the ARM management plane except for
one optional read, so it works with data-plane roles alone.

Every failure is classified, because the fix depends on the class:

    NETWORK   the endpoint could not be reached at all — a timeout, DNS
              resolving to a private address, a connection refusal. Public
              access is disabled on these resources; you are not on the VNet,
              VPN or jump host. No role change will fix this.

    LOGIN     no Entra token at all: `az login` has not been run or has
              expired. Nothing else can be checked until this passes.

    AUTH      the endpoint answered 401 or 403. You reached it; the group is
              missing a data-plane role, and the report names which one.

    CONFIG    a setting is absent, or names something that does not exist
              (a wrong deployment name, a missing container).

    SCHEMA    the resource exists and you can reach it, but it has not been
              prepared: the table is missing, or the rate seed is absent.

Deliberately independent of the application's own startup: a check that shares
code with the thing it validates fails for the same reasons and tells you
nothing new.
"""
from __future__ import annotations

import logging
import os
import socket
import sys
from pathlib import Path
from typing import Callable, Optional

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

# The SDKs narrate every credential they try and every HTTP retry. The report
# below is the output; the narration is noise that hides it.
for noisy in ("azure", "azure.identity", "azure.core.pipeline.policies.http_logging_policy",
              "httpx", "urllib3"):
    logging.getLogger(noisy).setLevel(logging.CRITICAL)

GREEN, RED, YELLOW, DIM, BOLD, RESET = (
    "\033[32m", "\033[31m", "\033[33m", "\033[2m", "\033[1m", "\033[0m")

CONTAINER = "travel-folios"
STATUS_CONTAINER = "processing_status"
COSMOS_DB = "tfa"

Result = tuple[str, str, str, str]   # (status, class, label, detail)
results: list[Result] = []


def ok(label: str, detail: str = "") -> None:
    results.append(("ok", "", label, detail))


def fail(cls: str, label: str, detail: str) -> None:
    results.append(("fail", cls, label, detail))


def warn(label: str, detail: str) -> None:
    results.append(("warn", "", label, detail))


def skip(label: str, detail: str) -> None:
    results.append(("skip", "", label, detail))


# --------------------------------------------------------------------------- #
# Classification
# --------------------------------------------------------------------------- #

NETWORK_MARKERS = (
    "timed out", "timeout", "name or service not known", "nodename nor servname",
    "connection refused", "no route to host", "network is unreachable",
    "failed to establish a new connection", "getaddrinfo", "connecterror",
    "serviceRequestError".lower(), "unable to connect", "login timeout expired",
    "tcp provider", "could not open a connection",
)


def classify(exc: BaseException) -> tuple[str, str]:
    """Return (class, one-line detail) for an exception."""
    text = f"{type(exc).__name__}: {exc}".splitlines()[0]
    low = str(exc).lower()

    if "failed to retrieve a token" in low or "clientauthenticationerror" in type(exc).__name__.lower():
        return "LOGIN", text[:170]
    # A proxy refusing the tunnel says "403", but that is the proxy, not the
    # resource. It means the corporate egress will not carry this traffic.
    if "proxyerror" in type(exc).__name__.lower() or "tunnel connection failed" in low \
            or "unable to connect to proxy" in low:
        return "NETWORK", text[:170]

    status = getattr(exc, "status_code", None) or getattr(
        getattr(exc, "response", None), "status_code", None)
    if status in (401, 403) or " 403" in low or " 401" in low or "forbidden" in low \
            or "authorizationfailure" in low or "authorizationpermissionmismatch" in low \
            or "login failed for user" in low:
        return "AUTH", text[:170]
    if status == 404 or "resourcenotfound" in low or "containernotfound" in low \
            or "deploymentnotfound" in low or "queuenotfound" in low:
        return "CONFIG", text[:170]
    if any(m in low for m in NETWORK_MARKERS):
        return "NETWORK", text[:170]
    return "UNKNOWN", text[:170]


def resolves_private(hostname: str) -> Optional[bool]:
    """True if DNS gives a private address: a private endpoint is in play."""
    try:
        addr = socket.gethostbyname(hostname)
    except OSError:
        return None
    first, second = (int(x) for x in addr.split(".")[:2])
    return first == 10 or (first == 172 and 16 <= second <= 31) or (first == 192 and second == 168)


def host_of(url: str) -> str:
    return url.replace("https://", "").replace("http://", "").split("/")[0].split(",")[0]


# --------------------------------------------------------------------------- #
# Config
# --------------------------------------------------------------------------- #

def load_env() -> None:
    env_file = ROOT / ".env"
    if not env_file.exists():
        warn(".env", "not found — using the process environment only")
        return
    sys.path.insert(0, str(ROOT / "src"))
    from tfa_core.envfile import load_env_file
    load_env_file(env_file)
    ok(".env", "loaded")


REQUIRED = [
    ("storage_account_url", "AZURE_STORAGE_ACCOUNT_URL / TFA_STORAGE_ACCOUNT_URL", "blob endpoint"),
    ("llm_endpoint", "AZURE_OPENAI_STARTBURST_END_POINT / TFA_LLM_ENDPOINT", "Azure OpenAI endpoint"),
    ("sql_server", "SQL_SERVER / TFA_SQL_SERVER", "SQL server FQDN"),
    ("sql_database", "SQL_DATABASE / TFA_SQL_DATABASE", "SQL database"),
]
# Exported under the TFA_ names so every check below reads one spelling,
# whichever spelling (legacy or TFA_) the .env used.
EXPORT = {
    "storage_account_url": "TFA_STORAGE_ACCOUNT_URL", "raw_container": "TFA_RAW_CONTAINER",
    "llm_endpoint": "TFA_LLM_ENDPOINT", "llm_deployment": "TFA_LLM_DEPLOYMENT",
    "llm_api_version": "TFA_LLM_API_VERSION", "llm_api_key": "TFA_LLM_API_KEY",
    "sql_server": "TFA_SQL_SERVER", "sql_database": "TFA_SQL_DATABASE", "sql_table": "TFA_SQL_TABLE",
    "sql_username": "TFA_SQL_USERNAME", "sql_password": "TFA_SQL_PASSWORD",
    "queue_account_url": "TFA_QUEUE_ACCOUNT_URL", "docintel_endpoint": "TFA_DOCINTEL_ENDPOINT",
    "cosmos_endpoint": "TFA_COSMOS_ENDPOINT",
}
SETTINGS = None


def check_config() -> bool:
    global SETTINGS
    sys.path.insert(0, str(ROOT / "src"))
    try:
        from tfa_core.config import Settings
        SETTINGS = Settings()
    except Exception as exc:
        errors = exc.errors() if hasattr(exc, "errors") else []
        missing = {str(e["loc"][0]) for e in errors if e.get("type") == "missing"}
        for field, names, what in REQUIRED:
            if names.split(" / ")[1] in missing:
                fail("CONFIG", names.split(" / ")[0], f"not set — {what} (either name works: {names})")
        for e in errors:
            if e.get("type") != "missing":
                fail("CONFIG", str(e["loc"][0]), e.get("msg", "invalid"))
        if not errors:
            fail("CONFIG", "settings", str(exc).splitlines()[0][:200])
        return False
    for field, env in EXPORT.items():
        v = getattr(SETTINGS, field, None)
        if v:
            os.environ[env] = str(v)
    for field, names, _ in REQUIRED:
        v = str(getattr(SETTINGS, field))
        if "<" in v or ">" in v:
            fail("CONFIG", names.split(" / ")[0], "still holds a template placeholder")
            return False
    s = SETTINGS
    ok("Configuration", f"required settings present; model deployment '{s.llm_deployment}'")
    ok("Reading path", "Document Intelligence" if s.use_docintel
       else "PDF text layer + page images to the model (no Document Intelligence in the infra)")
    ok("Status store", "Cosmos" if s.use_cosmos else "SQL tables tfa_processing_status / tfa_kv")
    ok("SQL sign-in", "username/password (Key Vault secret)" if (s.sql_username and s.sql_password)
       else "Entra token (az login / managed identity)")
    ok("Model sign-in", "API key" if s.llm_api_key else "Entra token")
    if not s.llm_verify_deployment:
        skip("Cross-model verification", "no second deployment configured — the infra has gpt-4o only")
    return True


# --------------------------------------------------------------------------- #
# Checks
# --------------------------------------------------------------------------- #

def check_credential():
    try:
        from azure.identity import DefaultAzureCredential
        cred = DefaultAzureCredential(exclude_interactive_browser_credential=True)
        # Data-plane scope on purpose: a group with no ARM access still passes.
        cred.get_token("https://storage.azure.com/.default")
        ok("Entra token", "DefaultAzureCredential resolved (az login or managed identity)")
        return cred
    except Exception as exc:
        fail("LOGIN", "Entra token", "run `az login` and sign in with the account that is in the Entra group")
        return None


def check_network(label: str, url: str) -> bool:
    """DNS first. If the name does not resolve there is nothing to connect to,
    and reporting a second failure for the same cause only muddies the summary."""
    host = host_of(url)
    private = resolves_private(host)
    if private is None:
        fail("NETWORK", f"{label} DNS", f"{host} does not resolve — not on the VNet DNS, or wrong hostname")
        return False
    if private:
        ok(f"{label} DNS", f"{host} → private address (private endpoint path)")
    else:
        warn(f"{label} DNS", f"{host} → public address — either public access is on, or you are "
                             "off-network and will time out")
    return True


def check_blob(cred) -> None:
    url = os.environ["TFA_STORAGE_ACCOUNT_URL"]
    if not check_network("Blob", url):
        return
    try:
        from azure.storage.blob import BlobServiceClient
        # retry_total=0: a preflight should report "unreachable" in seconds,
        # not after the SDK's exponential backoff has run its course.
        svc = BlobServiceClient(account_url=url, credential=cred, retry_total=0,
                                connection_timeout=8, read_timeout=15)
        container = svc.get_container_client(CONTAINER)
        container.get_container_properties()
        ok("Blob container", f"{CONTAINER} readable")

        names = {b.name for b in container.list_blobs(name_starts_with="rates/")}
        for required in ("rates/negotiated_rates.json", "rates/fx.json"):
            if required in names:
                ok(f"Rate seed {required}")
            else:
                fail("SCHEMA", f"Rate seed {required}",
                     "absent — extraction runs but every overcharge column stays empty. "
                     "Upload seed/*.json to the container under rates/")
    except Exception as exc:
        cls, detail = classify(exc)
        hint = {"AUTH": "needs Storage Blob Data Contributor on the storage account",
                "CONFIG": f"container '{CONTAINER}' does not exist on this account",
                "NETWORK": "public access is disabled; connect to the VNet / VPN / jump host"}.get(cls, "")
        fail(cls, "Blob container", f"{detail}  {hint}")


def check_queue(cred) -> None:
    url = os.environ["TFA_QUEUE_ACCOUNT_URL"]
    name = os.environ.get("TFA_WORK_QUEUE", "folio-extract")
    if not check_network("Queue", url):
        return
    try:
        from azure.storage.queue import QueueClient
        q = QueueClient(account_url=url, queue_name=name, credential=cred, retry_total=0,
                        connection_timeout=8, read_timeout=15)
        props = q.get_queue_properties()
        ok("Work queue", f"{name} reachable, ~{props.approximate_message_count} message(s) waiting")
    except Exception as exc:
        cls, detail = classify(exc)
        hint = {"AUTH": "needs Storage Queue Data Contributor on the storage account",
                "CONFIG": f"queue '{name}' does not exist — TFA_WORK_QUEUE may be wrong",
                "NETWORK": "connect to the VNet / VPN / jump host"}.get(cls, "")
        fail(cls, "Work queue", f"{detail}  {hint}")


def check_docintel(cred) -> None:
    endpoint = os.environ["TFA_DOCINTEL_ENDPOINT"]
    if not check_network("Document Intelligence", endpoint):
        return
    try:
        import httpx
        token = cred.get_token("https://cognitiveservices.azure.com/.default").token
        r = httpx.get(f"{endpoint.rstrip('/')}/documentintelligence/info",
                      params={"api-version": "2024-11-30"},
                      headers={"Authorization": f"Bearer {token}"}, timeout=15)
        if r.status_code == 200:
            ok("Document Intelligence", "reachable and authorised")
        elif r.status_code in (401, 403):
            fail("AUTH", "Document Intelligence",
                 f"HTTP {r.status_code} — needs Cognitive Services User on the Document Intelligence account")
        else:
            warn("Document Intelligence", f"HTTP {r.status_code}: {r.text[:100]}")
    except Exception as exc:
        cls, detail = classify(exc)
        fail(cls, "Document Intelligence", detail)


def check_llm(cred) -> None:
    endpoint = os.environ["TFA_LLM_ENDPOINT"]
    deployment = os.environ["TFA_LLM_DEPLOYMENT"]
    provider = os.environ.get("TFA_LLM_PROVIDER", "azure_openai")
    if not check_network("LLM", endpoint):
        return
    if provider != "azure_openai":
        skip("LLM deployment", f"provider '{provider}' — ping not implemented, run the web app and watch /status")
        return
    try:
        import httpx
        key = os.environ.get("TFA_LLM_API_KEY")
        if key:
            headers = {"api-key": key}
        else:
            token = cred.get_token("https://cognitiveservices.azure.com/.default").token
            headers = {"Authorization": f"Bearer {token}"}
        from tfa_core.llm.provider import _uses_completion_tokens
        limit = "max_completion_tokens" if _uses_completion_tokens(deployment) else "max_tokens"
        r = httpx.post(
            f"{endpoint.rstrip('/')}/openai/deployments/{deployment}/chat/completions",
            params={"api-version": os.environ.get("TFA_LLM_API_VERSION", "2024-10-21")},
            headers=headers,
            json={"messages": [{"role": "user", "content": "ping"}], limit: 5},
            timeout=30)
        if r.status_code == 200:
            ok("LLM deployment", f"'{deployment}' responded")
        elif r.status_code == 404:
            fail("CONFIG", "LLM deployment",
                 f"'{deployment}' not found — TFA_LLM_DEPLOYMENT is the deployment name, "
                 "not the model name; check Foundry → Deployments")
        elif r.status_code in (401, 403):
            fail("AUTH", "LLM deployment",
                 f"HTTP {r.status_code} — with a key: the key is wrong or rotated; with a token: "
                 "needs Cognitive Services OpenAI User on the OpenAI account")
        elif r.status_code == 429:
            warn("LLM deployment", "HTTP 429 — reachable and authorised, but no quota right now")
        else:
            warn("LLM deployment", f"HTTP {r.status_code}: {r.text[:100]}")
    except Exception as exc:
        cls, detail = classify(exc)
        fail(cls, "LLM deployment", detail)


def check_sql(cred) -> None:
    server = os.environ["TFA_SQL_SERVER"]
    database = os.environ["TFA_SQL_DATABASE"]
    table = os.environ.get("TFA_SQL_TABLE", "tfa_folio_lines")
    if not check_network("SQL", server):
        return
    try:
        import struct
        import pyodbc
    except ImportError:
        fail("CONFIG", "SQL driver",
             "pyodbc is not importable — pip install pyodbc, and install Microsoft ODBC Driver 18")
        return
    try:
        from tfa_core.storage.repositories import sql_connector
        connect = sql_connector(server, database, cred,
                                os.environ.get("TFA_SQL_USERNAME"), os.environ.get("TFA_SQL_PASSWORD"))
        conn = connect()
        cur = conn.cursor()
        cur.execute("SELECT SUSER_SNAME(), IS_ROLEMEMBER('db_datawriter')")
        who, writer = cur.fetchone()
        ok("SQL connection", f"as {who}, {connect.auth}")
        if writer != 1:
            fail("AUTH", "SQL write access",
                 f"{who} is not in db_datawriter — fine for the SQLAdmin login (it is the owner); "
                 "for a managed identity, run the ALTER ROLE statements from scripts/generate_sql_ddl.py")
        cur.execute("SELECT COUNT(*) FROM sys.tables WHERE name = ?", table)
        if cur.fetchone()[0] == 1:
            cur.execute(f"SELECT COUNT(DISTINCT document_id) FROM {table}")
            ok("SQL schema", f"{table} present, {cur.fetchone()[0]} document(s)")
        else:
            fail("SCHEMA", "SQL schema",
                 f"table {table} is missing — apply the output of scripts/generate_sql_ddl.py")
        conn.close()
    except Exception as exc:
        cls, detail = classify(exc)
        hint = {"AUTH": "no contained user for this identity — see infra/README.md §2",
                "NETWORK": "SQL is private-endpoint only; connect to the VNet / VPN / jump host"}.get(cls, "")
        fail(cls, "SQL connection", f"{detail}  {hint}")


def check_cosmos(cred) -> None:
    endpoint = os.environ["TFA_COSMOS_ENDPOINT"]
    if not check_network("Cosmos", endpoint):
        return
    try:
        from azure.cosmos import CosmosClient
        client = CosmosClient(endpoint, credential=cred, connection_timeout=8,
                              retry_total=0, connection_retry_policy=None)
        db = client.get_database_client(os.environ.get("TFA_COSMOS_DATABASE", COSMOS_DB))
        db.read()
        try:
            db.get_container_client(STATUS_CONTAINER).read()
            ok("Cosmos status", f"{STATUS_CONTAINER} present")
        except Exception as inner:
            cls, _ = classify(inner)
            if cls == "CONFIG":
                warn("Cosmos status",
                     f"{STATUS_CONTAINER} absent — the app creates it on first run if the role allows")
            else:
                raise
    except Exception as exc:
        cls, detail = classify(exc)
        hint = {"AUTH": "needs Cosmos DB Built-in Data Contributor — a Cosmos-native sqlRoleAssignment, "
                        "NOT an IAM-blade role",
                "CONFIG": "database 'tfa' does not exist on this account",
                "NETWORK": "connect to the VNet / VPN / jump host"}.get(cls, "")
        fail(cls, "Cosmos", f"{detail}  {hint}")


def check_event_grid(cred) -> None:
    """Optional: needs ARM read on the storage account. Skips cleanly without it."""
    sub = os.environ.get("TFA_SUBSCRIPTION_ID")
    rg = os.environ.get("TFA_RESOURCE_GROUP")
    account = host_of(os.environ["TFA_STORAGE_ACCOUNT_URL"]).split(".")[0]
    if not (sub and rg):
        skip("Event Grid subscription",
             "set TFA_SUBSCRIPTION_ID and TFA_RESOURCE_GROUP to check (needs ARM read)")
        return
    try:
        import httpx
        token = cred.get_token("https://management.azure.com/.default").token
        url = (f"https://management.azure.com/subscriptions/{sub}/resourceGroups/{rg}"
               f"/providers/Microsoft.Storage/storageAccounts/{account}"
               f"/providers/Microsoft.EventGrid/eventSubscriptions")
        r = httpx.get(url, params={"api-version": "2022-06-15"},
                      headers={"Authorization": f"Bearer {token}"}, timeout=20)
        if r.status_code in (401, 403):
            skip("Event Grid subscription", "no ARM read on the storage account — cannot verify from here")
            return
        r.raise_for_status()
        subs = r.json().get("value", [])
        good = [s for s in subs
                if "Microsoft.Storage.BlobCreated" in (s["properties"].get("filter", {}).get("includedEventTypes") or [])
                and CONTAINER in (s["properties"].get("filter", {}).get("subjectBeginsWith") or "")]
        if good:
            ok("Event Grid subscription", f"{good[0]['name']} → BlobCreated on {CONTAINER}")
        else:
            fail("SCHEMA", "Event Grid subscription",
                 f"none of {len(subs)} subscription(s) targets BlobCreated on {CONTAINER} — "
                 "documents will sync and never process. See infra/README.md §4")
    except Exception as exc:
        cls, detail = classify(exc)
        warn("Event Grid subscription", f"could not check: {detail}")


# --------------------------------------------------------------------------- #
# Report
# --------------------------------------------------------------------------- #

WHO_FIXES = {
    "LOGIN": "you — run `az login`, then re-run",
    "NETWORK": "you — connect to the VNet, VPN or jump host, then re-run",
    "AUTH": "whoever administers the Entra group / resource roles — ask for the role named above",
    "CONFIG": "you — fix the .env value, or confirm the name with whoever ran the Terraform",
    "SCHEMA": "whoever prepares the environment — DDL, seed upload, Event Grid",
    "UNKNOWN": "look at the error; re-run with the same settings before escalating",
}


def main() -> int:
    print(f"\n{BOLD}TFA preflight{RESET} — Entra-group access, data plane only\n")
    load_env()
    if not check_config():
        _report()
        return 1
    cred = check_credential()
    if cred is None:
        _report()
        return 1

    checks: list[Callable] = [check_blob, check_llm, check_sql]
    st = SETTINGS
    for present, fn, name in ((st.queue_account_url, check_queue, "Work queue"),
                              (st.docintel_endpoint, check_docintel, "Document Intelligence"),
                              (st.cosmos_endpoint, check_cosmos, "Cosmos"),
                              (st.queue_account_url, check_event_grid, "Event Grid subscription")):
        if present:
            checks.append(fn)
        else:
            skip(name, "not configured — not part of this deployment")
    for c in checks:
        try:
            c(cred)
        except Exception as exc:          # a check must never take the others down
            cls, detail = classify(exc)
            fail(cls, c.__name__, detail)
    return _report()


def _report() -> int:
    marks = {"ok": f"{GREEN}✓{RESET}", "fail": f"{RED}✗{RESET}",
             "warn": f"{YELLOW}!{RESET}", "skip": f"{DIM}–{RESET}"}
    for status, cls, label, detail in results:
        tag = f"{RED}{cls:<8}{RESET}" if status == "fail" else " " * 8
        print(f"  {marks[status]} {tag} {label:<30} {DIM}{detail}{RESET}")

    failures = [r for r in results if r[0] == "fail"]
    print()
    if not failures:
        warns = sum(1 for r in results if r[0] == "warn")
        print(f"{GREEN}READY{RESET} — {warns} warning(s), nothing blocking.")
        print(f"Next:  python start.py --azure   (web app on the real resources)\n")
        return 0

    by_class: dict[str, list[Result]] = {}
    for r in failures:
        by_class.setdefault(r[1], []).append(r)
    print(f"{RED}NOT READY{RESET} — {len(failures)} blocking issue(s)\n")
    for cls, items in by_class.items():
        print(f"  {BOLD}{cls}{RESET}  fixed by: {WHO_FIXES[cls]}")
        for _, _, label, _ in items:
            print(f"      · {label}")
        print()
    if "NETWORK" in by_class and len(by_class) > 1:
        print(f"{DIM}Resolve NETWORK first. Until you can reach the endpoints, the AUTH and "
              f"SCHEMA results above may be incomplete.{RESET}\n")
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
