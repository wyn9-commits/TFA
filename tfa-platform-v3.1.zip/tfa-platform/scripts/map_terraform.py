#!/usr/bin/env python3
"""Map the Terraform-provisioned resources to this application's settings.

For people who cannot see the Azure portal and whose only view of the
infrastructure is the Terraform pipeline in Azure DevOps. Copy the pipeline's
log text into a file and point this at it:

    python scripts/map_terraform.py apply.log                 # one log
    python scripts/map_terraform.py apply.log outputs.json    # several
    python scripts/map_terraform.py apply.log --write         # also write .env

It accepts, in any mix:
  - the console log of a `terraform apply` or `terraform plan` step
    (resource ids appear as [id=/subscriptions/...])
  - the console output of `terraform output` (key = "value" lines)
  - the file from `terraform output -json`

It produces three things:
  1. a proposed .env, derived from resource names by Azure's own naming rules
  2. a checklist against infra/README.md — found / missing / ambiguous
  3. the values other steps need: App Service name for azure-pipelines.yml,
     UAMI name for generate_sql_ddl.py

It cannot tell you what it cannot see. A missing role assignment in the
report means none appeared in the text you gave it, which is not the same as
none existing — give it the apply log, not just the outputs, for the full
picture. And it never writes .env over an existing one without --force.
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from collections import defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BOLD, DIM, GREEN, RED, YELLOW, RESET = (
    "\033[1m", "\033[2m", "\033[32m", "\033[31m", "\033[33m", "\033[0m")

# Azure resource id → (provider/type, name). Nested resources keep their parent.
ID_RE = re.compile(
    r"/subscriptions/[0-9a-f-]{36}/resourceGroups/(?P<rg>[^/\s\]\"']+)"
    r"/providers/(?P<path>Microsoft\.[A-Za-z]+/[A-Za-z]+(?:/[^/\s\]\"']+)"
    r"(?:/[A-Za-z]+/[^/\s\]\"']+)*)",
    re.I)

# Terraform resource address on the same line, so we can tell two storage
# accounts apart by what the module author called them.
ADDR_RE = re.compile(r"((?:module\.[\w\-]+\.)*azurerm_[a-z0-9_]+\.[\w\-]+(?:\[[^\]]+\])?)")

# `terraform output` console form:   name = "value"
OUT_RE = re.compile(r'^\s*(?P<k>[A-Za-z_][\w]*)\s*=\s*"?(?P<v>[^"\n]+?)"?\s*$', re.M)

ROLE_IDS = {
    "ba92f5b4-2d11-453d-a403-e96b0029c9fe": "Storage Blob Data Contributor",
    "974c5e8b-45b9-4653-ba55-5f855dd0fb88": "Storage Queue Data Contributor",
    "a97b65f3-24c7-4388-baec-2e87135dc908": "Cognitive Services User",
}


def parse(texts: list[str]) -> dict:
    found: dict[str, list[dict]] = defaultdict(list)
    outputs: dict[str, str] = {}
    seen_ids: set[str] = set()

    for text in texts:
        # terraform output -json
        try:
            j = json.loads(text)
            if isinstance(j, dict):
                for k, v in j.items():
                    val = v.get("value") if isinstance(v, dict) and "value" in v else v
                    if isinstance(val, (str, int, float, bool)):
                        outputs[k] = str(val)
                continue
        except (json.JSONDecodeError, AttributeError):
            pass

        # console `Outputs:` block, if present — only parse after that marker
        if "Outputs:" in text:
            for m in OUT_RE.finditer(text.split("Outputs:", 1)[1]):
                outputs[m.group("k")] = m.group("v").strip()

        for line in text.splitlines():
            for m in ID_RE.finditer(line):
                rid = m.group(0)
                if rid in seen_ids:
                    continue
                seen_ids.add(rid)
                parts = m.group("path").split("/")
                rtype = f"{parts[0]}/{parts[1]}"
                entry = {"name": parts[2], "rg": m.group("rg"), "id": rid,
                         "sub": parts[3:], "addr": None, "line": line}
                a = ADDR_RE.search(line)
                if a:
                    entry["addr"] = a.group(1)
                found[rtype].append(entry)
    return {"resources": found, "outputs": outputs, "raw": texts}


def classify_storage(entries: list[dict]) -> tuple[dict | None, list[dict]]:
    """The data account vs the Function App's own account. Terraform address
    and name both carry hints; when neither does, report the ambiguity."""
    if not entries:
        return None, []
    if len(entries) == 1:
        return entries[0], []
    func_hints = ("func", "fa", "webjobs", "fn", "app")
    data_hints = ("data", "raw", "folio", "doc", "ingest")
    scored = []
    for e in entries:
        hay = f"{e['addr'] or ''} {e['name']}".lower()
        score = sum(h in hay for h in data_hints) - sum(h in hay for h in func_hints)
        scored.append((score, e))
    scored.sort(key=lambda s: -s[0])
    if scored[0][0] > scored[1][0]:
        return scored[0][1], [e for _, e in scored[1:]]
    return None, entries


def classify_cognitive(entries: list[dict]) -> tuple[dict | None, dict | None, list[dict]]:
    """Document Intelligence vs Foundry/OpenAI. `kind` is not in the id, so we
    go by the Terraform address and the name, which module authors almost
    always make descriptive."""
    di = ai = None
    unsure = []
    for e in entries:
        hay = f"{e['addr'] or ''} {e['name']}".lower()
        if any(h in hay for h in ("docintel", "di-", "formrec", "document", "ocr", "layout")):
            di = di or e
        elif any(h in hay for h in ("openai", "oai", "aif", "foundry", "llm", "gpt", "ai-", "aiservices")):
            ai = ai or e
        else:
            unsure.append(e)
    return di, ai, unsure


def derive(parsed: dict) -> tuple[dict, list[tuple[str, str, str]], dict]:
    """Return (env, checklist, extras). checklist rows are (status, item, note)."""
    R, O = parsed["resources"], parsed["outputs"]
    env: dict[str, str] = {}
    rows: list[tuple[str, str, str]] = []
    extras: dict[str, str] = {}

    def row(status: str, item: str, note: str = "") -> None:
        rows.append((status, item, note))

    # ---- Storage -----------------------------------------------------------
    # Top-level accounts only: a role assignment scoped to an account parses
    # as a nested child of it, and must not count as a second account.
    data_sa, others = classify_storage(
        [e for e in R.get("Microsoft.Storage/storageAccounts", []) if not e["sub"]])
    if data_sa:
        env["TFA_STORAGE_ACCOUNT_URL"] = f"https://{data_sa['name']}.blob.core.windows.net"
        row("ok", "Storage account (data)", f"{data_sa['name']}  {DIM}{data_sa['addr'] or ''}{RESET}")
        if others:
            row("info", "Other storage account(s)",
                ", ".join(o["name"] for o in others) + "  — assumed to be the Function App's own")
    elif others:
        row("ask", "Storage account",
            "two or more found and none is obviously the data account: "
            + ", ".join(o["name"] for o in others) + ". Pick the one the raw container lives in.")
    else:
        row("missing", "Storage account", "no Microsoft.Storage/storageAccounts in the text")

    # Containers and queues appear as https ids rather than ARM ids, and role
    # assignments nest under their scope, so several checks scan the raw text.
    joined = "\n".join(parsed["raw"])
    if re.search(r"blob\.core\.windows\.net/travel-folios\b", joined):
        row("ok", "Container travel-folios")
    else:
        row("check", "Container travel-folios", "not seen in the text; the app expects this exact name")
    qm = re.search(r"queue\.core\.windows\.net/([\w\-]+)", joined)
    if qm and data_sa:
        env["TFA_QUEUE_ACCOUNT_URL"] = f"https://{data_sa['name']}.queue.core.windows.net"
        env["TFA_WORK_QUEUE"] = qm.group(1)
        row("info", "Work queue", qm.group(1) + "  — only the optional Function App uses it")
    else:
        row("info", "Work queue", "none — not needed; the web app processes in the background itself")

    # ---- SQL ---------------------------------------------------------------
    servers = [s for s in R.get("Microsoft.Sql/servers", []) if not s["sub"]]
    dbs = [s for s in R.get("Microsoft.Sql/servers", []) if s["sub"][:1] == ["databases"]]
    fqdn = O.get("sql_server_fqdn") or O.get("sql_fqdn")
    if servers or fqdn:
        env["TFA_SQL_SERVER"] = fqdn or f"{servers[0]['name']}.database.windows.net"
        row("ok", "SQL server", env["TFA_SQL_SERVER"])
    else:
        row("missing", "SQL server", "no Microsoft.Sql/servers in the text")
    if dbs:
        names = [d["sub"][1] for d in dbs if len(d["sub"]) > 1 and d["sub"][1].lower() != "master"]
        if len(names) == 1:
            env["TFA_SQL_DATABASE"] = names[0]
            row("ok", "SQL database", names[0])
        elif names:
            env["TFA_SQL_DATABASE"] = names[0]
            row("ask", "SQL database", f"several: {', '.join(names)} — using the first; confirm")
    else:
        row("missing", "SQL database", "no databases/<name> under the server in the text")

    # ---- Cosmos ------------------------------------------------------------
    cos = [c for c in R.get("Microsoft.DocumentDB/databaseAccounts", []) if not c["sub"]]
    if cos:
        env["TFA_COSMOS_ENDPOINT"] = f"https://{cos[0]['name']}.documents.azure.com"
        row("ok", "Cosmos account", cos[0]["name"])
    else:
        row("info", "Cosmos account", "none — not needed; status is kept in SQL")

    # ---- Cognitive: Document Intelligence + Foundry/OpenAI -----------------
    all_cog = R.get("Microsoft.CognitiveServices/accounts", [])
    accts = [a for a in all_cog if not a["sub"]]
    di, ai, unsure = classify_cognitive(accts)
    # An account with model deployments under it is the OpenAI account,
    # whatever its name (the infra's is called travel-res).
    with_deps = {a["name"] for a in all_cog if a["sub"][:1] == ["deployments"]}
    for u in list(unsure):
        if u["name"] in with_deps and ai is None:
            ai = u
            unsure.remove(u)
    if di:
        env["TFA_DOCINTEL_ENDPOINT"] = f"https://{di['name']}.cognitiveservices.azure.com"
        row("ok", "Document Intelligence", f"{di['name']}  {DIM}{di['addr'] or ''}{RESET}")
    else:
        row("info", "Document Intelligence", "none — not needed; the model reads the PDF text layer + page images")
    if ai:
        env["TFA_LLM_ENDPOINT"] = f"https://{ai['name']}.openai.azure.com"
        row("ok", "Foundry / OpenAI", f"{ai['name']}  {DIM}{ai['addr'] or ''}{RESET}")
        row("check", "LLM endpoint host",
            "assumed <name>.openai.azure.com; if the account uses a custom subdomain or is an "
            "AIServices kind, the host may be <name>.cognitiveservices.azure.com — preflight will say")
    else:
        row("missing", "Foundry / OpenAI", "no cognitive account that looks like OpenAI / Foundry")
    for u in unsure:
        row("ask", "Cognitive account", f"{u['name']} — cannot tell DI from OpenAI by name; check its kind")

    deps = [a for a in R.get("Microsoft.CognitiveServices/accounts", []) if a["sub"][:1] == ["deployments"]]
    if deps:
        names = [d["sub"][1] for d in deps if len(d["sub"]) > 1]
        env["TFA_LLM_DEPLOYMENT"] = names[0]
        row("ok" if len(names) == 1 else "ask", "LLM deployment",
            names[0] + ("" if len(names) == 1 else f"  — also: {', '.join(names[1:])}; confirm"))
    else:
        row("check", "LLM deployment",
            "no deployments/<name> in the text — the code default is gpt-4o, which is what the tfvars deploy")

    # ---- Identity, Function App ------------------------------------------
    uami = R.get("Microsoft.ManagedIdentity/userAssignedIdentities", [])
    if uami:
        extras["uami_name"] = uami[0]["name"]
        row("ok", "User-assigned identity", uami[0]["name"] + "  → pass to generate_sql_ddl.py")
    else:
        row("missing", "User-assigned identity", "no userAssignedIdentities in the text")
    cid = O.get("uami_client_id") or O.get("identity_client_id")
    if cid:
        extras["uami_client_id"] = cid
        row("ok", "UAMI client id", cid + "  → USER_ASSIGNED_CLIENT_ID on the App Service only")

    sites = R.get("Microsoft.Web/sites", [])
    fa = O.get("function_app_name") or (sites[0]["name"] if sites else None)
    if fa:
        extras["app_service_name"] = fa
        row("ok", "App Service", fa + "  → appServiceName in azure-pipelines.yml")
    else:
        row("missing", "App Service", "no Microsoft.Web/sites in the text")

    # ---- Roles, Event Grid, private endpoints ------------------------------
    ras = R.get("Microsoft.Authorization/roleAssignments", [])
    # role assignment ids are nested under their scope, so they land under the scope's type
    ra_lines = [l for l in joined.splitlines() if "roleAssignments" in l or "azurerm_role_assignment" in l]
    cosmos_ra = [l for l in joined.splitlines() if "sqlRoleAssignments" in l or "cosmosdb_sql_role_assignment" in l]
    row("ok" if ra_lines else "check", "ARM role assignments",
        f"{len(ra_lines)} seen" if ra_lines else "none seen — the app needs Storage Blob Data Contributor (and Cognitive Services OpenAI User if no key)")
    for rid, rname in ROLE_IDS.items():
        if rid in joined:
            row("ok", f"  role {rname}", "role definition id present in text")
    if cosmos_ra:
        row("info", "Cosmos SQL role assignment", f"{len(cosmos_ra)} seen (only used if TFA_COSMOS_ENDPOINT is set)")
    grp = [l for l in ra_lines if re.search(r'\["?group"?\]|group|entra', l, re.I)]
    row("ok" if grp else "check", "Role assignments for the Entra group",
        f"{len(grp)} line(s) mention a group" if grp else
        "nothing mentions a group — if the Terraform only assigns roles to the UAMI, "
        "people cannot run locally; see infra/README.md §2")

    eg = [l for l in joined.splitlines() if "EventGrid" in l or "eventgrid" in l]
    row("info", "Event Grid subscription",
        f"{len(eg)} line(s) — not needed by the web app" if eg else "none — not needed; the web app processes itself")
    pes = R.get("Microsoft.Network/privateEndpoints", [])
    row("ok" if pes else "check", "Private endpoints",
        f"{len(pes)} — you need the VPN to reach these" if pes else "none seen; if public access is "
        "also disabled, nothing is reachable")

    return env, rows, extras


def render_env(env: dict, extras: dict) -> str:
    """Write the legacy app's setting names, which the infra already uses."""
    legacy = {"TFA_STORAGE_ACCOUNT_URL": "AZURE_STORAGE_ACCOUNT_URL",
              "TFA_LLM_ENDPOINT": "AZURE_OPENAI_STARTBURST_END_POINT",
              "TFA_LLM_DEPLOYMENT": "AZURE_OPENAI_STARTBURST_MODEL_NAME",
              "TFA_SQL_SERVER": "SQL_SERVER", "TFA_SQL_DATABASE": "SQL_DATABASE"}
    lines = ["# Generated by scripts/map_terraform.py from the infra pipeline log.",
             "# Never commit this file. Verify with: python scripts/preflight.py",
             "", "TFA_ENVIRONMENT=dev", ""]
    env.setdefault("TFA_LLM_DEPLOYMENT", "gpt-4o")
    for k, name in legacy.items():
        lines.append(f"{name}={env[k]}" if k in env else f"{name}=   # NOT FOUND in the log — fill in")
    lines += ["AZURE_OPENAI_STARTBURST_API_VERSION=2024-10-21",
              "AZURE_OPENAI_STARTBURST_API_KEY=   # optional; blank = your az login",
              "", "# From Key Vault (mssql_server_username / mssql_server_password);",
              "# blank = sign in to SQL with your az login.",
              "SQL_USERNAME=", "SQL_PASSWORD=", ""]
    for k in ("TFA_DOCINTEL_ENDPOINT", "TFA_COSMOS_ENDPOINT", "TFA_QUEUE_ACCOUNT_URL", "TFA_WORK_QUEUE"):
        if k in env:
            lines.append(f"{k}={env[k]}")
    lines += ["", "TFA_SHAREPOINT_ENABLED=false", "TFA_SHAREPOINT_SITE_ID=", "TFA_SHAREPOINT_DRIVE_ID=", "",
              "# Deployed app only — do not set locally:",
              f"# USER_ASSIGNED_CLIENT_ID={extras.get('uami_client_id', '')}", ""]
    return "\n".join(lines)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("files", nargs="+", type=Path)
    ap.add_argument("--write", action="store_true", help="write .env at the repo root")
    ap.add_argument("--force", action="store_true", help="overwrite an existing .env")
    args = ap.parse_args()

    texts = []
    for f in args.files:
        if not f.exists():
            print(f"{RED}not found:{RESET} {f}")
            return 1
        texts.append(f.read_text(encoding="utf-8", errors="replace"))

    parsed = parse(texts)
    env, rows, extras = derive(parsed)

    print(f"\n{BOLD}Resources seen{RESET}")
    for rtype, es in sorted(parsed["resources"].items()):
        top = [e for e in es if not e["sub"]]
        if top:
            print(f"  {rtype:<48} {', '.join(e['name'] for e in top)}")

    print(f"\n{BOLD}Contract checklist{RESET}  (infra/README.md)")
    marks = {"ok": f"{GREEN}✓{RESET}", "missing": f"{RED}✗{RESET}", "check": f"{YELLOW}?{RESET}",
             "ask": f"{YELLOW}?{RESET}", "info": f"{DIM}·{RESET}"}
    for status, item, note in rows:
        print(f"  {marks[status]} {item:<36} {DIM}{note}{RESET}")

    print(f"\n{BOLD}Proposed .env{RESET}")
    text = render_env(env, extras)
    print("\n".join("  " + l for l in text.splitlines()))

    if extras:
        print(f"\n{BOLD}For other steps{RESET}")
        if "app_service_name" in extras:
            print(f"  azure-pipelines.yml  appServiceName: '{extras['app_service_name']}'")
        if "uami_name" in extras:
            print(f"  python scripts/generate_sql_ddl.py {extras['uami_name']}")

    if args.write:
        target = ROOT / ".env"
        if target.exists() and not args.force:
            print(f"\n{YELLOW}.env exists — not overwritten. Use --force, or merge by hand.{RESET}")
        else:
            target.write_text(text, encoding="utf-8")
            print(f"\n{GREEN}wrote{RESET} {target}")

    missing = sum(1 for s, _, _ in rows if s == "missing")
    print(f"\nNext: connect to the VPN, `az login`, then `python scripts/preflight.py`.")
    if missing:
        print(f"{YELLOW}{missing} item(s) not found in the text you gave me — the apply log shows more "
              f"than the outputs do.{RESET}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
